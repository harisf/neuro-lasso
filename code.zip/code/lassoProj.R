library(hdi)
library(parallel)

for(neuron in seq(13,13)){
  setwd("/global/work/harisf/modelMatrix10ms")
  fileName = paste("n",neuron,"_b10ms.rds",sep="")
  
  modelMatrix = readRDS(fileName)
  
  y = modelMatrix[,1]
  y[which(y > 1)] = 1
  
  x = modelMatrix[,-1]
  
  startTime = Sys.time()
  fit <- lasso.proj(x, y, suppress.grouptesting = TRUE, family = "binomial",
                    betainit = "cv lasso", # cv lasso uses lambda.1se instead of lambda.min... See lasso.proj -> initial.estiamtor -> do.initial.fit in hdi/R/helpers.R on github
                    parallel = TRUE, ncores = 10)
  endTime = Sys.time() - startTime
  
  setwd("/global/work/harisf/lassoproj10ms")
  saveRDS(fit,fileName)
  
  cat("Lassoproj done for neuron ",neuron,". Time used: ",endTime," ",attr(endTime,"units"),". \n",sep="")
}
