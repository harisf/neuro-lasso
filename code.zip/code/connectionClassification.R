library(glmnet)

# edge is a vector of length 2, describing the relation edge[1] -> edge[2]

edge = c(13,1) # i.e. from neuron 13 to neuron 1. n1 <- n13

neuronFrom = edge[1]
neuronTo = edge[2]

session = 2
setwd(paste("/Volumes/work/harisf/session",session,"/lassoFit",sep=""))
fit = readRDS(paste("n",neuronTo,"_b1ms.rds",sep = ""))

nBases_history = 10
nBases_connectivity = 4
deg = 5

getBasis2 = function(nBases,binSize){
  #b = binSize*5
  #peaks = c(binSize,binSize*50)
  b = binSize*nBases
  peaks = c(binSize,binSize*10*nBases)
  #peaks = c(binSize,binSize*5*nBases)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  #str(ihbasis)
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}
bas_connect = getBasis2(nBases_connectivity,binSize = 0.001)$bas_orth

namesOfNeighbouringCoefs = dimnames(coef(fit, s = "lambda.min"))[[1]][(nBases_history+2):(length(coef(fit, s = "lambda.min"))-deg)]
indexOfNeuronFrom = which(as.numeric(unname(sapply(namesOfNeighbouringCoefs,function(x){substr(x,start = 2,stop = regexpr("k",x) - 2)}))) == neuronFrom) + (nBases_history+1)
coeff_neuronFrom = coef(fit, s = "lambda.min")[indexOfNeuronFrom]

connectivityEffect = bas_connect %*% coeff_neuronFrom
connectivityEffect_first = connectivityEffect[1] # BEN: is this OK?

connectivityEffect_intercept = bas_connect %*% coeff_neuronFrom

plot(connectivityEffect,type="b")
abline(h = 0)
abline(v = 3)
abline(v = 15)

# calculate area of under this curve:
# plot(abs(connectivityEffect[3:10]))

trapezoid = function(y){
  s  = 0
  if(length(y) == 1 || length(y) == 0)
    s
  else {
    for(i in seq(2,length(y))){
      s = s + (y[i] + y[i-1]) / 2
    }
    s
  }
}

# seq(0,3): common input
# seq(3,15): direct input
# seq(15,100): indirect input
connectivityInterval = seq(3,15) # ms

overBaseline.curve = connectivityEffect[connectivityInterval][which(connectivityEffect[connectivityInterval] >= 0)]
underBaseline.curve = connectivityEffect[connectivityInterval][which(connectivityEffect[connectivityInterval] <= 0)]

overBaseline.area = trapezoid(overBaseline.curve)
underBaseline.area = trapezoid(abs(underBaseline.curve))




connection = sign(overBaseline.area-underBaseline.area)
connection

# trapezoid(abs(connectivityEffect[5:10]))
# 
# 
# # implementation of composite simpson's rule
# simpson = function(x,y,n){ # n is the number of subintervals. Need to be an even number
#   h = (x[length(x)] - x[1]) / n
#   s = y[1] + y[length(y)]
#   
#   for(i in seq(1,n,by = 2))
#     s = s + 4*y[1+i*h]
#   for(i in seq(2,n-1,by = 2))
#     s = s + 2*y[1+i*h]
#   
#   return(s*h / 3)
#   
# }
# 
# simpson(x = seq(1,10),y = abs(connectivityEffect[5:10]),n = 6)
# 
# # if(connectivityEffect_first < 0)
# #   connection = -1
# # else if(connectivityEffect_first > 0)
# #   connection = 1
# # else
# #   connection = 0
#   
# #  return(connection)
