library(Matrix)
# get model matrix
#setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
setwd("/Volumes/harisf/master/data/variables/modelMatrix")
modelMatrix = readRDS("n1_b1ms.rds")

# get good trials
#setwd("/home/shomea/h/harisf/master/data/variables")
setwd("/Volumes/harisf/master/data/variables")
trials.good = readRDS("trials.good_session20130701.rds")

#b1ms: indexes 1:4999 are the first trial, 5000:9999 the second trials, etc
#b10ms: indexes 1:499 are the first trial, 500:999 the second trials, etc

rowIndex2 = foreach(i = 2:length(trials.good)) %do% {
  5000:9999 + 5000*(i-2)
}
  

rowIndex = c(list(1:4999),rowIndex2)
#for(i in seq(1,length(rowIndex))){
  i = 10
  pdf(file = paste("/Volumes/harisf/master/figures/modelMatrix/image2/n1_b1ms_trial",trials.good[[i]],".pdf",sep=""),
      width = dev.size()[1], height = dev.size()[2])
  image(modelMatrix[rowIndex[[i]],],aspect = 1, # aspect = y / x
        main = paste("Trial: ",trials.good[[i]],sep=""),colorkey = F)
  dev.off()
#}
