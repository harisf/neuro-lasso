# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
trials_correctR = which(data$obj[[8]][1,] == 1)
trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# get trials where there was a correct LEFT lick 
trials_correctL = which(data$obj[[8]][2,] == 1)
trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]

# plot tuning curves
plotTuningCurve = function(neuron,RIGHTLEFT = TRUE){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  
  getFiringRate = function(TRIALS){
    binSize = 0.1
    timeInterval = seq(0,5.4,binSize)
    spikeCount = vector(mode="numeric",length=length(timeInterval)-1)
    
    for(trial_j in TRIALS){
      trialStartTime_j = data$obj[[7]][1,trial_j]
      eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
      
      spikeCount = spikeCount + as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
      
    }
    firingRate = spikeCount/(binSize*length(spikeCount))
  }
  
  binSize = 0.1
  timeInterval = seq(0,5.4,binSize)
  
  if(RIGHTLEFT){
    firingRate_R = getFiringRate(trials_correctR)
    firingRate_L = getFiringRate(trials_correctL)
    
    lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials_correctL],data$obj[[9]][[3]][[3]][[1]][trials_correctR]),na.rm=TRUE)
    
    plot(timeInterval[-length(timeInterval)]-lickOnset,firingRate_R,type="l",col="blue",main=paste("Neuron",neuron,sep = " "),
         xlab = "Time (s)", ylab = "Firing Rate (Hz)",
         ylim = c(min(firingRate_R,firingRate_L),max(firingRate_R,firingRate_L)),lwd=0.3)
    lines(timeInterval[-length(timeInterval)]-lickOnset,firingRate_L,col="red",lwd=0.3)
    
    points(timeInterval[-length(timeInterval)]-lickOnset,firingRate_R,col="blue")
    points(timeInterval[-length(timeInterval)]-lickOnset,firingRate_L,col="red")
    
    startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials_correctL],data$obj[[9]][[3]][[1]][[1]][trials_correctR]),na.rm=TRUE)
    startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials_correctL],data$obj[[9]][[3]][[2]][[1]][trials_correctR]),na.rm=TRUE)
    startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials_correctL],data$obj[[9]][[3]][[3]][[1]][trials_correctR]),na.rm=TRUE)
    abline(v=startOfSampleEpoch-lickOnset,lty=2)
    abline(v=startOfDelayEpoch-lickOnset,lty=2)
    abline(v=startOfResponseEpoch-lickOnset,lty=2)
    legend("top", c("Lick R", "Lick L"), lty=c(1,1),col=c("blue","red"))
    
  } else {
    firingRate = getFiringRate(trials.good)
    
    lickOnset = mean(data$obj[[9]][[3]][[3]][[1]][trials.good],na.rm = TRUE)
    
    plot(timeInterval[-length(timeInterval)]-lickOnset,firingRate,type="l",main=paste("Neuron",neuron,sep = " "),
         xlab = "Time (s)", ylab = "Firing Rate (Hz)",
         lwd=0.3)
    
    points(timeInterval[-length(timeInterval)]-lickOnset,firingRate)
    
    startOfSampleEpoch = mean(data$obj[[9]][[3]][[1]][[1]][trials.good],na.rm=TRUE)
    startOfDelayEpoch = mean(data$obj[[9]][[3]][[2]][[1]][trials.good],na.rm=TRUE)
    startOfResponseEpoch = mean(data$obj[[9]][[3]][[3]][[1]][trials.good],na.rm=TRUE)
    abline(v=startOfSampleEpoch-lickOnset,lty=2)
    abline(v=startOfDelayEpoch-lickOnset,lty=2)
    abline(v=startOfResponseEpoch-lickOnset,lty=2)
  }
  
  
  
  # binSize = 0.1
  # timeInterval = seq(0,5.4,binSize)
  
  # plot(timeInterval[-length(timeInterval)],firingRate_R,type="l",col="blue",main=paste("Neuron",neuron,sep = " "),
  #      xlab = "Trial time (s)", ylab = "Firing Rate (Hz)",
  #      ylim = c(min(firingRate_R,firingRate_L),max(firingRate_R,firingRate_L)),lwd=0.3)
  # lines(timeInterval[-length(timeInterval)],firingRate_L,col="red",lwd=0.3)
  # 
  # points(timeInterval[-length(timeInterval)],firingRate_R,col="blue")
  # points(timeInterval[-length(timeInterval)],firingRate_L,col="red")
  # 
  # startOfSampleEpoch = mean(data$obj[[9]][[3]][[1]][[1]][trials_correctL],na.rm=TRUE)
  # startOfDelayEpoch = mean(data$obj[[9]][[3]][[2]][[1]][trials_correctL],na.rm=TRUE)
  # startOfResponseEpoch = mean(data$obj[[9]][[3]][[3]][[1]][trials_correctL],na.rm=TRUE)
  # abline(v=startOfSampleEpoch,lty=2)
  # abline(v=startOfDelayEpoch,lty=2)
  # abline(v=startOfResponseEpoch,lty=2)
  # legend("top", c("Lick R", "Lick L"), lty=c(1,1),col=c("blue","red"))
  
  # lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials_correctL],data$obj[[9]][[3]][[3]][[1]][trials_correctR]),na.rm=TRUE)
  # 
  # plot(timeInterval[-length(timeInterval)]-lickOnset,firingRate_R,type="l",col="blue",main=paste("Neuron",neuron,sep = " "),
  #      xlab = "Time (s)", ylab = "Firing Rate (Hz)",
  #      ylim = c(min(firingRate_R,firingRate_L),max(firingRate_R,firingRate_L)),lwd=0.3)
  # lines(timeInterval[-length(timeInterval)]-lickOnset,firingRate_L,col="red",lwd=0.3)
  # 
  # points(timeInterval[-length(timeInterval)]-lickOnset,firingRate_R,col="blue")
  # points(timeInterval[-length(timeInterval)]-lickOnset,firingRate_L,col="red")
  # 
  # startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials_correctL],data$obj[[9]][[3]][[1]][[1]][trials_correctR]),na.rm=TRUE)
  # startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials_correctL],data$obj[[9]][[3]][[2]][[1]][trials_correctR]),na.rm=TRUE)
  # startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials_correctL],data$obj[[9]][[3]][[3]][[1]][trials_correctR]),na.rm=TRUE)
  # abline(v=startOfSampleEpoch-lickOnset,lty=2)
  # abline(v=startOfDelayEpoch-lickOnset,lty=2)
  # abline(v=startOfResponseEpoch-lickOnset,lty=2)
  # legend("top", c("Lick R", "Lick L"), lty=c(1,1),col=c("blue","red"))
  
}

plotTuningCurve(8,RIGHTLEFT = F)

plotTuningCurve(8)
plotTuningCurve(11)
plotTuningCurve(12)
plotTuningCurve(14)
plotTuningCurve(16)
plotTuningCurve(17)
plotTuningCurve(19)
plotTuningCurve(20)
plotTuningCurve(21)


# tuning curve pr trial (not summed up)

TRIALS = trials_correctR

binSize = 0.1
timeInterval = seq(0,5.4,binSize)


spikes = matrix(0,nrow = length(timeInterval)-1, ncol = length(TRIALS))
i = 1
maxSpikeCount = 0
for(trial_j in TRIALS){
  trialStartTime_j = data$obj[[7]][1,trial_j]
  eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
  
  spikes[,i] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
  
  maxSpikeCount = max(maxSpikeCount,max(spikes[,i]))
  i = i + 1
  
}

par(mfrow=c(1,1))
plot.gam(model_R,se=T,trans=exp,rug = F)
plot(timeInterval[-1],spikes[,1],ylim=c(0,maxSpikeCount),col="darkgray")
for(i in seq(1,dim(spikes)[2]))
  points(timeInterval[-1],spikes[,i],col="darkgray")



