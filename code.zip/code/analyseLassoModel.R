setwd("/Volumes/harisf/master/data")
library(R.matlab)
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

pdiscretizeSpikeData = function(neuron,TRIALS,binSize){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  #mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  no_cores = detectCores()-1
  registerDoParallel(no_cores)
  mat = foreach(trial_j = TRIALS,.combine = rbind) %dopar% {
    #mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
    
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]-lickOnset
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    mat_j
  }
  stopImplicitCluster()
  
  colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""))
  mat = as.data.frame(mat)
  return(mat)
}

spikeData = pdiscretizeSpikeData(neuron = 1,TRIALS = trials.good,binSize = 0.001)


setwd("/Volumes/harisf/master/data/variables/modelFit")
fit = readRDS("fitLasso_n1_b1ms.rds")
library(glmnet)

coef(fit,s="lambda.min")

getBasis2 = function(nBases,binSize){
  b = binSize*5
  peaks = c(binSize,binSize*50)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}

plotAndSaveEffects = function(cvfit,filePathName,mainNeuron,nBases_history,nBases_connectivity,binSize = 0.001,family){
  bas_list_hist = getBasis2(nBases_history,binSize)
  bas_hist = bas_list_hist$bas_orth
  tau_N_hist = bas_list_hist$tau_N
  bas_list_connect = getBasis2(nBases_connectivity,binSize)
  bas_connect = bas_list_connect$bas_orth
  tau_N_connect = bas_list_connect$tau_N
  
  deg = 5
  coeff_intercept = coef(cvfit, s = "lambda.min")[1]
  coeff_history = coef(cvfit, s = "lambda.min")[2:(nBases_history+1)]
  #coeff_connectivity = coef(cvfit, s = "lambda.min")[-seq(1,(nBases_history+1))]
  coeff_connectivity = coef(cvfit, s = "lambda.min")[(nBases_history+2):(length(coef(cvfit, s = "lambda.min"))-deg)]
  coeff_lickOnset = coef(cvfit, s = "lambda.min")[(length(coef(cvfit, s = "lambda.min"))-deg+1):length(coef(cvfit, s = "lambda.min"))]
  
  
  if(family == "poisson"){
    invLink = function(x){exp(x)}
    txtylab = paste("firing rate n",mainNeuron,sep="")
  }
  if(family == "binomial"){
    invLink = function(x){exp(x)/(1+exp(x))}
    txtylab = paste("firing prob. n",mainNeuron,sep="")
  }
  
  # save history plot
  pdf(file=paste(filePathName,"history.pdf",sep=""),width=dev.size()[1],height=dev.size()[2])
  
  plot(seq(binSize,tau_N_hist,binSize),invLink(bas_hist %*% coeff_history+coeff_intercept),type="l",
       xlab="lag (s)",ylab = txtylab,main=paste("history n",mainNeuron,sep=""),
       ylim = c(0,max(invLink(bas_hist %*% coeff_history + coeff_intercept))))
  
  
  # plot(c(0,seq(binSize,tau_N_hist,binSize)),exp(c(coeff_intercept,bas_hist %*% coeff_history)),type="l",
  #      xlab="lag (s)",ylab = paste("firing rate n",mainNeuron,sep=""),main=paste("history n",mainNeuron,sep=""))
  #abline(h=1,lty=2)
  abline(h=invLink(coeff_intercept),lty=2)
  dev.off()
  
  # save connectivity plots
  otherNeurons = dimnames(coef(cvfit, s = "lambda.min"))[[1]][-seq(1,(nBases_history+1))]
  for(j in seq(1,29*nBases_connectivity,nBases_connectivity)){
    currentNeuron = substring(otherNeurons[j],2,gregexpr("k",otherNeurons[j])[[1]][1]-2)
    pdf(file=paste(filePathName,"connectivity_n",currentNeuron,".pdf",sep=""),width=dev.size()[1],height=dev.size()[2])
    plot(seq(binSize,tau_N_connect,binSize),invLink(bas_connect %*% coeff_connectivity[seq(j,j+nBases_connectivity-1)]+coeff_intercept),type="l",
         xlab="lag (s)",ylab = txtylab,main=paste("n",mainNeuron," <- n",currentNeuron,sep=""),
         ylim = c(0,max(invLink(bas_hist %*% coeff_history+coeff_intercept))),xlim=c(0,tau_N_hist))
    #abline(h=1,lty=2)
    abline(h=invLink(coeff_intercept),lty=2)
    dev.off()
  }
  
  # save lick onset plot
  startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials.good]),na.rm=TRUE)
  startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials.good]),na.rm=TRUE)
  startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE) # aka lickOnset
  
  #if(family == "binomial"){
  invLink = function(x){exp(x)/(1+exp(x))}
  #}
  lickOnsetPoly_full = poly(spikeData$lickOnset,deg) %*% coef(cvfit,s="lambda.min")[seq(length(coef(cvfit,s="lambda.min"))-deg+1,length(coef(cvfit,s="lambda.min")))]
  pdf(file=paste(filePathName,"lickOnset.pdf",sep=""),width=dev.size()[1],height=dev.size()[2])
  plot(spikeData$lickOnset[1:4999],invLink(lickOnsetPoly_full[1:4999]+coef(cvfit, s = "lambda.min")[1]),type="l",xlab="lickOnset (s)",ylab=paste("firing prob. n",mainNeuron,sep=""),
       main=paste("n",mainNeuron," poly(lO) deg.",deg,sep=""))
  abline(h=invLink(coef(cvfit, s = "lambda.min")[1]),lty=2)#,col="gray")
  abline(v=startOfSampleEpoch-startOfResponseEpoch,lty=3,col="gray")
  abline(v=startOfDelayEpoch-startOfResponseEpoch,lty=3,col="gray")
  abline(v=startOfResponseEpoch-startOfResponseEpoch,lty=3,col="gray")
  dev.off()
  
}

plotAndSaveEffects(fit,
                   filePathName = "/Volumes/harisf/master/figures/bases/neuron1_b1ms/",
                   mainNeuron = 1,nBases_history = 10, nBases_connectivity = 4,
                   family = "binomial")