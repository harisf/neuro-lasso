library(R.matlab)
library(glmnet)

#setwd("/Volumes/harisf/master/data")
setwd("/home/shomea/h/harisf/master/data")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130702.mat")
totalNumberOfNeurons = length(data$obj[[12]][[1]])

getBasis2 = function(nBases,binSize){
  #b = binSize*5
  #peaks = c(binSize,binSize*50)
  b = binSize*nBases
  peaks = c(binSize,binSize*10*nBases)
  #peaks = c(binSize,binSize*5*nBases)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  #str(ihbasis)
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}
invLink = function(x){exp(x)/(1+exp(x))}
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
trials_correctR = which(data$obj[[8]][1,] == 1)
trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# # get trials where there was a correct LEFT lick 
trials_correctL = which(data$obj[[8]][2,] == 1)
trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]

#trials.good = trials_correctR

binSize = 0.001
nBases_history = 10
nBases_connectivity = 4
deg = 5 # degree of lickonset polynomial

bas_list_hist = getBasis2(nBases_history,binSize)
bas_hist = bas_list_hist$bas_orth
tau_N_hist = bas_list_hist$tau_N
bas_list_connect = getBasis2(nBases_connectivity,binSize)
bas_connect = bas_list_connect$bas_orth
tau_N_connect = bas_list_connect$tau_N

# plotWidth = dev.size()[1]
# plotHeight = dev.size()[2]
plotWidth = 12.093750 
plotHeight = 4.614583
# plotWidth = 8.403509
# plotHeight = 4.885965
tau_N_xlim = c(tau_N_hist,tau_N_connect)[as.numeric(tau_N_connect > tau_N_hist) + 1]

startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials.good]),na.rm=TRUE)
startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials.good]),na.rm=TRUE)
startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE) # aka lickOnset
lickOnset = rep(seq(binSize,5,binSize) - startOfResponseEpoch,length(trials.good))

startOfSampleEpoch.left = mean(c(data$obj[[9]][[3]][[1]][[1]][trials_correctL]),na.rm=TRUE)
startOfDelayEpoch.left = mean(c(data$obj[[9]][[3]][[2]][[1]][trials_correctL]),na.rm=TRUE)
startOfResponseEpoch.left = mean(c(data$obj[[9]][[3]][[3]][[1]][trials_correctL]),na.rm=TRUE) # aka lickOnset
lickOnset.left = rep(seq(binSize,5,binSize) - startOfResponseEpoch.left,length(trials_correctL))

startOfSampleEpoch.right = mean(c(data$obj[[9]][[3]][[1]][[1]][trials_correctR]),na.rm=TRUE)
startOfDelayEpoch.right = mean(c(data$obj[[9]][[3]][[2]][[1]][trials_correctR]),na.rm=TRUE)
startOfResponseEpoch.right = mean(c(data$obj[[9]][[3]][[3]][[1]][trials_correctR]),na.rm=TRUE) # aka lickOnset
lickOnset.right = rep(seq(binSize,5,binSize) - startOfResponseEpoch.right,length(trials_correctR))



# setwd("/Volumes/work/harisf/session2")
setwd("/global/work/harisf/session2")
# setwd("/Volumes/work/harisf/session2/lassoFit_rightTrials")
# setwd("/Volumes/work/harisf/session2/lassoFit_leftTrials")

#responseNeuron = 3
for(responseNeuron in seq(1,totalNumberOfNeurons)){
  #for(responseNeuron in seq(5,5)){
  fit = readRDS(paste("lassoFit/","n",responseNeuron,"_b1ms.rds",sep=""))
  fit.left = readRDS(paste("lassoFit_leftTrials/","n",responseNeuron,"_b1ms.rds",sep=""))
  fit.right = readRDS(paste("lassoFit_rightTrials/","n",responseNeuron,"_b1ms.rds",sep=""))
  
  mainDir = "/global/work/harisf/figures/session 2 lickOnset L&R and both"
  # mainDir = "/Volumes/work/harisf/figures/session 2 lickOnset L&R and both"
  # subDir = paste("n",responseNeuron,sep="")
  # if(!dir.exists(file.path(mainDir, subDir)))
  #   dir.create(file.path(mainDir, subDir))
  # filePathName = paste(file.path(mainDir, subDir),"/",sep="")
  filePathName = paste(mainDir,"/n",responseNeuron,sep="")
  
  coeff_intercept = coef(fit, s = "lambda.min")[1]
  coeff_lickOnset = coef(fit,s="lambda.min")[seq(-deg+1,0)+length(coef(fit,s="lambda.min"))]
  
  coeff_intercept.left = coef(fit.left, s = "lambda.min")[1]
  # coeff_history = coef(fit, s = "lambda.min")[2:(nBases_history+1)]
  # coeff_connectivity = coef(fit, s = "lambda.min")[(nBases_history+2):(length(coef(fit, s = "lambda.min"))-deg)]
  coeff_lickOnset.left = coef(fit.left,s="lambda.min")[seq(-deg+1,0)+length(coef(fit.left,s="lambda.min"))]
  
  coeff_intercept.right = coef(fit.right, s = "lambda.min")[1]
  coeff_lickOnset.right = coef(fit.right,s="lambda.min")[seq(-deg+1,0)+length(coef(fit.right,s="lambda.min"))]

  
  ######################
  # save lick onset plot
  ######################
  lickOnsetPoly_full = poly(lickOnset,deg) %*% coeff_lickOnset
  lickOnsetPoly_full_left = poly(lickOnset.left,deg) %*% coeff_lickOnset.left
  lickOnsetPoly_full_right = poly(lickOnset.right,deg) %*% coeff_lickOnset.right
  
  pdf(file=paste(filePathName,".pdf",sep=""),width=plotWidth,height=plotHeight)
  # plot(lickOnset[seq(1,5/binSize)],invLink(lickOnsetPoly_full[seq(1,5/binSize)]+coeff_intercept),type="l",xlab="lickOnset (s)",ylab=paste("firing prob. n",responseNeuron,sep=""),
  #      main=paste("n",responseNeuron," poly(lickOnset)",sep=""))
  # abline(h=invLink(coeff_intercept),lty=2)
  # abline(v=startOfSampleEpoch-startOfResponseEpoch,lty=3,col="gray")
  # abline(v=startOfDelayEpoch-startOfResponseEpoch,lty=3,col="gray")
  # abline(v=startOfResponseEpoch-startOfResponseEpoch,lty=3,col="gray")
  
  par(mfrow=c(1,3))
  plot(lickOnset[seq(1,5/binSize)],invLink(lickOnsetPoly_full[seq(1,5/binSize)]+coeff_intercept),type="l",xlab="lickOnset (s)",ylab=paste("firing prob. n",responseNeuron,sep=""),
       main=paste("n",responseNeuron," poly(lickOnset)",sep=""))
  mtext("All trials")
  abline(h=invLink(coeff_intercept),lty=2)
  abline(v=startOfSampleEpoch-startOfResponseEpoch,lty=3,col="gray")
  abline(v=startOfDelayEpoch-startOfResponseEpoch,lty=3,col="gray")
  abline(v=startOfResponseEpoch-startOfResponseEpoch,lty=3,col="gray")
  
  plot(lickOnset.left[seq(1,5/binSize)],invLink(lickOnsetPoly_full_left[seq(1,5/binSize)]+coeff_intercept.left),type="l",xlab="lickOnset (s)",ylab=paste("firing prob. n",responseNeuron,sep=""),
       main=paste("n",responseNeuron," poly(lickOnset)",sep=""),col="red")
  mtext("Left trials")
  abline(h=invLink(coeff_intercept.left),lty=2)
  abline(v=startOfSampleEpoch.left-startOfResponseEpoch.left,lty=3,col="gray")
  abline(v=startOfDelayEpoch.left-startOfResponseEpoch.left,lty=3,col="gray")
  abline(v=startOfResponseEpoch.left-startOfResponseEpoch.left,lty=3,col="gray")
  
  plot(lickOnset.right[seq(1,5/binSize)],invLink(lickOnsetPoly_full_right[seq(1,5/binSize)]+coeff_intercept.right),type="l",xlab="lickOnset (s)",ylab=paste("firing prob. n",responseNeuron,sep=""),
       main=paste("n",responseNeuron," poly(lickOnset)",sep=""),col="blue")
  mtext("Right trials")
  abline(h=invLink(coeff_intercept.right),lty=2)
  abline(v=startOfSampleEpoch.right-startOfResponseEpoch.right,lty=3,col="gray")
  abline(v=startOfDelayEpoch.right-startOfResponseEpoch.right,lty=3,col="gray")
  abline(v=startOfResponseEpoch.right-startOfResponseEpoch.right,lty=3,col="gray")
  dev.off()
}




