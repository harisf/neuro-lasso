library(glmnet)

session = 2
neuron = 1
modelMatrix = readRDS(paste("/global/work/harisf/session",session,"/modelMatrix/n",neuron,"_b1ms.rds",sep=""))

y = modelMatrix[,1]
x = modelMatrix[,(dim(modelMatrix)[2]-4):dim(modelMatrix)[2]]


library(hdi)
library(parallel)

lasso.cv.lambda.min = function (x, y, nfolds = 10, grouped = nrow(x) > 3 * nfolds, 
                                ...){
  suppressMessages(library(doMC))
  registerDoMC(cores=10)
  fit.cv <- cv.glmnet(x, y, nfolds = nfolds, grouped = grouped, parallel = TRUE,
                      ...)
  sel <- predict(fit.cv, type = "nonzero", s = "lambda.min")
  sel[[1]]
}

glm.pval.x.as.matrix = function (x, y, family = "binomial", verbose = FALSE, ...){
  fit.glm <- glm(y ~ as.matrix(x), family = family, ...)
  fit.summary <- summary(fit.glm)
  if (!fit.glm$converged & verbose) {
    #print(fit.summary)
  }
  pval.sel <- coef(fit.summary)[-1, 4]
  names(pval.sel) <- colnames(x)
  pval.sel
}

fit.multiSplit <- multi.split(x,y, ci = FALSE, B = 50,
                              classical.fit = glm.pval.x.as.matrix,
                              model.selector = lasso.cv.lambda.min, args.model.selector = list(family = "binomial"),
                              #parallel = TRUE, ncores = 10,
                              return.selmodels = FALSE, verbose = FALSE)

#fit.multiSplit$pval.corr
saveRDS(fit.multiSplit,file = "/home/shomea/h/harisf/master/data/variables/thesis/multisplit_s2n1.rds")

