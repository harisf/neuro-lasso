
binSize = 0.01
trialTime = seq(0,5,binSize)

deg = 5
polynom.legendre = poly(trialTime,degree = deg)
polynom = matrix(0,nrow = length(trialTime),ncol=deg)
for(d in seq(1,deg)){
  polynom[,d] = trialTime^d
}

pdf(file="/Volumes/harisf/master/figures/thesis/polynomialBasis.pdf",
    width = dev.size()[1], height = dev.size()[2])
par(mfrow=c(1,2))
matplot(trialTime,polynom,type="l",lty=1,xlab="Trial time (s)",ylab="",
        main="polynomial")
mtext("D = 5")
matplot(trialTime,polynom.legendre,type="l",lty=1,xlab="Trial time (s)",ylab="",
        main="orthogonal polynomial")
mtext("D = 5")
dev.off()