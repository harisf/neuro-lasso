library(glmnet)
library(doMC)

session = 2

for(neuron in c(2,3)){
  #modelMatrix = readRDS(paste("/Volumes/work/harisf/session",session,"/modelMatrix/n",neuron,"_b1ms.rds",sep=""))
  modelMatrix = readRDS(paste("/global/work/harisf/session",session,"/modelMatrix10ms/n",neuron,"_b10ms.rds",sep=""))
  y = modelMatrix[,1]
  y[which(y > 1)] = 1
  x = modelMatrix[,-1]
  
  startTime = Sys.time()
  registerDoMC(cores = 10)
  fitcv = cv.glmnet(x,y,family = "binomial",alpha = 1, nfolds = 10,parallel = TRUE)
  
  endTime = Sys.time() - startTime
  cat("Lasso model fitted for neuron ",neuron,". Time used: ",endTime," ",attr(endTime,"units"),". \n",sep="")
  
  saveRDS(fitcv,file = paste("/global/work/harisf/session",session,"/lassoFit10ms/n",neuron,"_b10ms.rds",sep=""))
}




