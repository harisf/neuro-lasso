library(foreach)
library(doParallel)

binSize = 0.001
session = 2
trialType = c("goodTrials","correctL","correctR")[3]

eventData = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/eventData_s",session,".rds",sep=""))
trialTypeData = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/trialTypeData_s",session,".rds",sep=""))
trialStartTime = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/trialStartTime_LIST_s",session,".rds",sep=""))

TRIALS = trialTypeData[[trialType]]

pdiscretizeSpikeData = function(neuron,binSize){
  eventTrials = eventData[[2]][[neuron]]
  eventTimes = eventData[[1]][[neuron]]
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  #mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  #no_cores = detectCores()-1
  #no_cores = 10
  registerDoParallel(cores = detectCores()-1)
  mat = foreach(trial_j = TRIALS,.combine = rbind) %dopar% {
    #mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
    
    trialStartTime_j = trialStartTime[[trial_j]]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    mat_j
  }
  stopImplicitCluster()
  
  colnames(mat) = c("trialId","trialTime",paste("spikeCountj",neuron,sep=""))
  mat = as.data.frame(mat)
  return(mat)
}


neuron = 2
spikeData = pdiscretizeSpikeData(neuron,binSize)
head(spikeData)

deg = 5
predMat = cbind(spikeData[,3],poly(spikeData[,2],degree = deg))
txtPolyname = NULL
for(i in seq(1,deg))
  txtPolyname = c(txtPolyname,paste("poly(lickOnset)",i,sep = ""))
colnames(predMat)[seq(dim(predMat)[2]-deg+1,dim(predMat)[2])] = txtPolyname

head(predMat)

# fitting lasso model with ONLY stimulus effects
library(glmnet)
library(doMC)
y = predMat[,1]
x = predMat[,-1]

startTime = Sys.time()
registerDoMC(cores = 10)
model_lasso_cv = cv.glmnet(x,y,
                           family = "binomial",alpha = 1, nfolds = 10,
                           parallel = TRUE)
Sys.time() - startTime

#str(model_lasso_cv)
modelCoefs = coef(model_lasso_cv,s="lambda.min")

model_glm = glm(y ~x, family = "binomial")
modelCoefs = matrix(coefficients(model_glm),ncol = 1)

#binSize = 0.001
#x[seq(1,5/binSize),]
tuningCurve = x[1:4999,] %*% modelCoefs[-1,1] + modelCoefs[1,1]
#tuningCurve = x[1:4999,] %*% modelCoefs[-1,1]
tuningCurve = exp(tuningCurve) / (1 + exp(tuningCurve))
baselineFR = exp(modelCoefs[1,1]) / (1 + exp(modelCoefs[1,1]))
plot(seq(0.001,5-0.001,0.001),tuningCurve,xlab="trial time (s)",ylab="prob. of firing",type="l")
abline(h = baselineFR,lty=2)

plot(tuningCurve)


tuningCurve_goodTrials = list(tuningCurve = tuningCurve, baselineFR = baselineFR)
tuningCurve_correctL = list(tuningCurve = tuningCurve, baselineFR = baselineFR)
tuningCurve_correctR = list(tuningCurve = tuningCurve, baselineFR = baselineFR)

plot(seq(0.001,5-0.001,0.001),tuningCurve_goodTrials$tuningCurve,type="l",ylim=c(0,0.003),col="darkgray")
lines(seq(0.001,5-0.001,0.001),tuningCurve_correctL$tuningCurve,col="red")
lines(seq(0.001,5-0.001,0.001),tuningCurve_correctR$tuningCurve,col="blue")
abline(v=0.5723196,lty=2)
abline(v=2.5776134,lty=2)
abline(v=4.0881849,lty=2)


neuron = 1
barplot(meanFR_LIST[[neuron]][,trialType])



str(spikeData)
TRIALS = unique(spikeData$trialId)
spikeCount = 0
for(trial_j in TRIALS){
  spikes_j = spikeData[which(spikeData$trialId == trial_j),3]
  spikeCount = spikeCount + spikes_j
}
plot(spikeCount)

plot(spikeCount/binSize/length(TRIALS),type="l")

library(R.matlab)
session = 3
data = readMat(paste("/home/shomea/h/harisf/master/data/data_structure_ANM210861/data_structure_ANM210861_2013070",session,".mat",sep=""))
trialTypeData = readRDS(paste("/home/shomea/h/harisf/master/data/variables/thesis/trialTypeData_s",session,".rds",sep=""))

TRIALTYPES = c("goodTrials","correctL","correctR")
epochStartTimes_mean = matrix(0,nrow=3,ncol=3)
rownames(epochStartTimes_mean) = c(TRIALTYPES)
for(k in seq(1,3)){
  trialType = TRIALTYPES[k]
  epochStartTimes = matrix(0,ncol=3,nrow = length(trialTypeData[[trialType]]))
  for(j in seq(1,length(trialTypeData[[trialType]]))){
    trial_j = trialTypeData[[trialType]][j]
    startOfSampleEpoch = data$obj[[9]][[3]][[1]][[1]][trial_j]
    startOfDelayEpoch = data$obj[[9]][[3]][[2]][[1]][trial_j]
    startOfResponseEpoch = data$obj[[9]][[3]][[3]][[1]][trial_j]
    
    epochStartTimes[j,1] = startOfSampleEpoch
    epochStartTimes[j,2] = startOfDelayEpoch
    epochStartTimes[j,3] = startOfResponseEpoch
    # trialEpochs = list(startOfSampleEpoch = startOfSampleEpoch,
    #                    startOfDelayEpoch  = startOfDelayEpoch ,
    #                    startOfResponseEpoch = startOfResponseEpoch)
  }
  epochStartTimes_mean[k,] = colMeans(epochStartTimes)
}
saveRDS(epochStartTimes_mean,paste("/home/shomea/h/harisf/master/data/variables/thesis/epochStartTimes_mean_s",session,".rds",sep=""))


library(R.matlab)
session = 3
data = readMat(paste("/home/shomea/h/harisf/master/data/data_structure_ANM210861/data_structure_ANM210861_2013070",session,".mat",sep=""))
totalNumberOfNeurons = length(data$obj[[12]][[1]])

eventTrials_LIST = list()
eventTimes_LIST = list()
for(neuron in seq(1,totalNumberOfNeurons)){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  
  eventTimes_LIST[[neuron]] = eventTimes
  eventTrials_LIST[[neuron]] = eventTrials
}
eventData = list(eventTimes_LIST=eventTimes_LIST,
                 eventTrials_LIST=eventTrials_LIST)
saveRDS(eventData,paste("/home/shomea/h/harisf/master/data/variables/thesis/eventData_s",session,".rds",sep=""))





