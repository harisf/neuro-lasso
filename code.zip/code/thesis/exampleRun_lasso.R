library(glmnet)



library("mlbench")
data("BreastCancer")




library("AppliedPredictiveModeling")
data("abalone")
str(abalone)
y = abalone$Rings
x = abalone[,-9]
x = data.matrix(x)
str(x)

fit = glmnet(x,y)
cvfit = cv.glmnet(x,y)

pdf(file="/Volumes/harisf/master/figures/thesis/exampleRunLassoAbalone3.pdf",
    width = 8.464912, height = 4.719298)
    #width = 9.543860, height = 5.324561)
par(mfrow=c(1,2))
plot(fit,label=F,xvar = "lambda",col=seq(1,dim(x)[2]),xlab=expression(paste("log(",nu,")",sep="")))
legend("bottomright",
       c("x1","x2","x3","x4","x5","x6","x7","x8"), lty=1, col=seq(1,dim(x)[2]),bty="n",cex=0.75)
       #colnames(x), lty=1, col=seq(1,dim(x)[2]),bty="n",cex=0.55)

plot(cvfit,xlab=expression(paste("log(",nu,")",sep="")))
text(log(cvfit$lambda.min)+0.4,6,"min",cex = 0.8)
text(log(cvfit$lambda.1se)+0.4,6,"1se",cex = 0.8)
#text(log(cvfit$lambda.min)+0.5,6,expression(nu["min"]))
#text(log(cvfit$lambda.1se)+0.5,6,expression(nu["1se"]))
dev.off()

#library(plotmo)
#plot_glmnet(fit,xvar = "lambda")

dim(abalone)
