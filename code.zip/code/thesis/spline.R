library(R.matlab)

data = readMat("/Volumes/harisf/master/data/data_structure_ANM210861/data_structure_ANM210861_20130702.mat")

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
trials_correctR = which(data$obj[[8]][1,] == 1)
trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# get trials where there was a correct LEFT lick 
trials_correctL = which(data$obj[[8]][2,] == 1)
trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]

# startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials.good]),na.rm=TRUE)
# startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials.good]),na.rm=TRUE)
# startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE) # aka lickOnset
# 

discretizeSpikeData = function(neuron,TRIALS,binSize=0.001){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  data_lick = NULL
  data_lick_j = matrix(0,ncol=3,nrow=length(timeInterval)-1)
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    data_lick_j[,1] = timeInterval[2:length(timeInterval)]
    data_lick_j[,2] =  as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    data_lick_j[,3] = rep(trial_j,length(timeInterval)-1)
    
    data_lick = rbind(data_lick,data_lick_j)
  }
  
  colnames(data_lick) = c("trialTime","spikeCount","trialId")
  dataFrame_lick = as.data.frame(data_lick)
  return(dataFrame_lick)
}

neuron = 1


# spikes_lickL = discretizeSpikeData(neuron,TRIALS = trials_correctL)
# spikes_lickR = discretizeSpikeData(neuron,TRIALS = trials_correctR)
spikes_goodTrials = discretizeSpikeData(neuron,TRIALS = trials.good)



# gam_L = gam(spikeCount~as.factor(trialId) + s(trialTime),data = spikes_lickL,family = "poisson")
#library(gam)
gam_goodTrials = gam(spikeCount~s(trialTime),data = spikes_goodTrials,family = "binomial")
#plot(gam_goodTrials,se=T)

invLogit = function(x)
  1 / (exp(-x) + 1)
library(mgcv)
pdf(file="/Volumes/harisf/master/figures/thesis/spline_n1s2.pdf",
    width = 4.377193, height = 4.798246)
plot(gam_goodTrials,se=T,rug = F,xlab="trial time (s)",shift = coefficients(gam_goodTrials)[1],ylim=c(-0.5,1)+coefficients(gam_goodTrials)[1],trans = invLogit,
     main = "Neuron 1",ylab="prob. firing n1")
abline(h = invLogit(coefficients(gam_goodTrials)[1]),lty=1)
mtext("Smoothing spline. edf = 4.15")
dev.off()

