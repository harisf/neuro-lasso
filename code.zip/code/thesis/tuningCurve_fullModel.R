library(glmnet)

session = 1
trialTypeData = readRDS(paste("/home/shomea/h/harisf/master/data/variables/thesis/trialTypeData_s",session,".rds",sep=""))

binSize = 0.001
trialTimeInterval = seq(binSize,5,binSize)
deg = 5

totalNumberOfNeurons = c(30,16,12)[session]

getTuningCurveData = function(trialType){
  TRIALS = trialTypeData[[trialType]]
  tuningCurve_LIST = list()
  for(neuron in seq(1,totalNumberOfNeurons)){
    trialTime = rep(trialTimeInterval,length(TRIALS))
    trialTime_poly = poly(trialTime,degree = deg)
    
    if(trialType == "goodTrials")
      fullmodel = readRDS(paste("/global/work/harisf/session",session,"/lassoFit/n",neuron,"_b1ms.rds",sep=""))
    if(trialType == "correctL")
      fullmodel = readRDS(paste("/global/work/harisf/session",session,"/lassoFit_leftTrials/n",neuron,"_b1ms.rds",sep=""))
    if(trialType == "correctR")
      fullmodel = readRDS(paste("/global/work/harisf/session",session,"/lassoFit_rightTrials/n",neuron,"_b1ms.rds",sep=""))
    
    # tuning curve full model
    intercept = coef(fullmodel,s="lambda.min")[1]
    coefs = coef(fullmodel,s="lambda.min")[(length(coef(fullmodel,s="lambda.min"))-4):length(coef(fullmodel,s="lambda.min"))]
    
    tuningCurve = trialTime_poly %*% coefs + intercept
    tuningCurve = exp(tuningCurve) / (1 + exp(tuningCurve))
    baselineFR = exp(intercept) / (1 + exp(intercept))
    
    tuningCurve_LIST[[neuron]] = list(tuningCurve = tuningCurve, baselineFR = baselineFR)
  }
  return(tuningCurve_LIST)
}

TuningCurveData = list()
for(trialType in c("goodTrials","correctL","correctR")){
  TuningCurveData[[trialType]] = getTuningCurveData(trialType)
}

saveRDS(TuningCurveData,file = paste("/home/shomea/h/harisf/master/data/variables/thesis/TuningCurveData_fullmodel_s",session,".rds",sep=""))

# FIX STRUCTURE OF TUNINCURVEDATA-OBJECT. 
# RIGHT NOW ITS: TuningCurveData[[neuron]][[trialType]]
# TO MAKE THE PLOTTING WORK BELOW, FIX TO: TuningCurveData[[trialType]][[neuron]]
######### !!!!!!!!!!!!!!!!!
# MAKE SURE THIS IS FIXED






###################
# plot tuningCurves
###################
#s1: width = 9.22807, height = (10.10526+0.8)*2
#s2: width = 9.22807, height = 10.10526+0.8
#s3: width = 9.22807, height = 7.587719+0.8

binSize = 0.001
session = 2
TuningCurveData = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/TuningCurveData_fullmodel_s",session,".rds",sep=""))
epochStartTimes_mean = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/epochStartTimes_mean_s",session,".rds",sep=""))

# pdf(file = paste("/Volumes/harisf/master/figures/thesis/tuningCurves_onlyCovariateTrialTime_s",session,"_withBaselineFR.pdf",sep=""),
pdf(file = paste("/Volumes/harisf/master/figures/thesis/tuningCurves_fullmodel_s",session,".pdf",sep=""),
    width = 9.22807, height = 10.10526+0.8)
layout(matrix(seq(1,16),ncol=4,nrow=4,byrow = T))
for(neuron in seq(1,16)){
  trialNames = names(TuningCurveData)
  maxValue = 0
  #baselineFR_mean = 0
  #baselineFR = NULL
  for(trialType in trialNames){
    maxValue = max(maxValue,TuningCurveData[[trialType]][[neuron]]$tuningCurve)
    #baselineFR_mean = baselineFR_mean + TuningCurveData[[trialType]][[neuron]]$baselineFR
    #baselineFR = c(baselineFR,TuningCurveData[[trialType]][[neuron]]$baselineFR)
  }
  #baselineFR_mean = baselineFR_mean/3
  plot(1,type="n",xlim=c(binSize,5-binSize),ylim=c(0,maxValue),
       xlab="trial time (s)",ylab=paste("prob. firing n",neuron,sep=""),main=paste("Neuron",neuron))
  for(k in seq(1,3)){
    trialType = trialNames[k]
    lines(seq(binSize,5,binSize),TuningCurveData[[trialType]][[neuron]]$tuningCurve[seq(1,5/binSize)],
          col=c("darkgray","red","blue")[k])
  }
  abline(v=colMeans(epochStartTimes_mean),lty=2)
  #abline(h=baselineFR_mean)
  #abline(h=baselineFR,col=c("darkgray","red","blue"),lty=2)
}
dev.off()





