library(glmnet)

session = 2
neuron = 1
modelMatrix = readRDS(paste("/Volumes/work/harisf/session",session,"/modelMatrix/n",neuron,"_b1ms.rds",sep=""))
#modelMatrix = readRDS(paste("/global/work/harisf/session",session,"/modelMatrix/n",neuron,"_b1ms.rds",sep=""))
y = modelMatrix[,1]
x = modelMatrix[,-1]

fit = glmnet(x,y,family = "binomial",alpha = 1)
saveRDS(fit,file = paste("/global/work/harisf/session",session,"/lassoFit/n",neuron,"_b1ms_NOTcv.rds",sep=""))
#registerDoMC(cores = 10)
#fit.cv = cv.glmnet(x,y,family = "binomial",alpha = 1, nfolds = 10,parallel = TRUE)




# plot

fit = readRDS(paste("/Volumes/work/harisf/session",session,"/lassoFit/n",neuron,"_b1ms_NOTcv.rds",sep=""))
fit.cv = readRDS(paste("/Volumes/work/harisf/session",session,"/lassoFit/n",neuron,"_b1ms.rds",sep=""))

# dim(x) = c(1424999,75)

pdf(file="/Volumes/harisf/master/figures/thesis/lassoFullmodel_s2n1.pdf",
    width = 9.114035, height = 4.666667)
par(mfrow=c(1,2))
plot(fit,label = F,xvar="lambda",col=rev(seq(1,dim(x)[2])),xlab=expression(paste("log(",nu,")",sep="")))
#legend("bottomright",colnames(x)[1:5], lty=1, col=rev(seq(1,dim(x)[2])),bty="n",cex=0.75)


#is.element(fit.cv$lambda.min,fit$lambda) # this is TRUE
# meaning fit$lamda is the x-axis in the coefficient path plot
#
# there are 75 coefficients (excluding the intercept)
# as.matrix(fit$beta) is 75 x 70 dimension. That is, each row of fit$beta is a coefficient, and each column is its value as nu decreases (?)

#dimnames(fit$beta)[[1]] # these are the coefficients on each row
#plot(log(fit$lambda),fit$beta[1,])

# log.lambda = -7
# fit.lambda.index = which.min(abs(fit$lambda-exp(log.lambda)))
# 
# sort(abs(fit$beta[,fit.lambda.index]), decreasing = T)
# 
# pos = locator(1)
# text(pos,"P2")
# text(pos,"P3")
# text(pos,"P1")
# text(pos,"P5")
# text(pos,"P4")
# text(pos,"hist.l1")
log.lambda = -12.5
fit.lambda.index = which.min(abs(fit$lambda-exp(log.lambda)))
text(log.lambda,fit$beta["poly(lickOnset)2",fit.lambda.index]-10,"P2",cex = 0.8)
text(log.lambda,fit$beta["poly(lickOnset)3",fit.lambda.index]+10,"P3",cex = 0.8)
text(log.lambda,fit$beta["poly(lickOnset)1",fit.lambda.index]+10,"P1",cex = 0.8)
text(log.lambda,fit$beta["poly(lickOnset)5",fit.lambda.index]+10,"P5",cex = 0.8)
text(log.lambda,fit$beta["poly(lickOnset)4",fit.lambda.index]-10,"P4",cex = 0.8)
log.lambda = -7
fit.lambda.index = which.min(abs(fit$lambda-exp(log.lambda)))
text(log.lambda,fit$beta["j1.k1",fit.lambda.index]-10,"hist.l1",cex = 0.8)

plot(fit.cv,xlab=expression(paste("log(",nu,")",sep="")))
text(log(fit.cv$lambda.min)-0.25,0.0211,"min",cex=0.8)
text(log(fit.cv$lambda.1se)-0.25,0.0211,"1se",cex=0.8)
dev.off()


fit.cv$lambda.min


length(which(coef(fit.cv,s="lambda.min") != 0))
