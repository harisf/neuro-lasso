library(glmnet)
library(doMC)

session = 2
trialTypeData = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/trialTypeData_s",session,".rds",sep=""))

binSize = 0.001
trialTimeInterval = seq(binSize,5,binSize)
deg = 5

neuron = 1

fullmodel_LIST = list()
halfmodel_LIST = list()
#tuningCurve_fullmodel_LIST = list()
#tuningCurve_halfmodel_LIST = list()
for(k in seq(1,3)){ # trialType
  trialType = c("goodTrials","correctL","correctR")[k]
  TRIALS = trialTypeData[[trialType]]
  # trialTime = rep(trialTimeInterval,length(TRIALS))
  # trialTime_poly = poly(trialTime,degree = deg)
  
  if(k == 1){
    fullmodel = readRDS(paste("/Volumes/work/harisf/session",session,"/lassoFit/n",neuron,"_b1ms.rds",sep=""))
    modelMatrix = readRDS(paste("/Volumes/work/harisf/session",session,"/modelMatrix/n",neuron,"_b1ms.rds",sep=""))
  }
  if(k == 2){
    fullmodel = readRDS(paste("/Volumes/work/harisf/session",session,"/lassoFit_leftTrials/n",neuron,"_b1ms.rds",sep=""))
    modelMatrix = readRDS(paste("/Volumes/work/harisf/session",session,"/modelMatrix_leftTrials/n",neuron,"_b1ms.rds",sep=""))
  }
  if(k == 3){
    fullmodel = readRDS(paste("/Volumes/work/harisf/session",session,"/lassoFit_rightTrials/n",neuron,"_b1ms.rds",sep=""))
    modelMatrix = readRDS(paste("/Volumes/work/harisf/session",session,"/modelMatrix_rightTrials/n",neuron,"_b1ms.rds",sep=""))
  }
  
  # tuning curve full model
  #intercept_fullmodel = coef(fullmodel,s="lambda.min")[1]
  #coefs_fullmodel = coef(fullmodel,s="lambda.min")[(length(coef(fullmodel,s="lambda.min"))-4):length(coef(fullmodel,s="lambda.min"))]
  
  # tuningCurve_fullmodel = trialTime_poly %*% coefs_fullmodel + intercept_fullmodel
  # tuningCurve_fullmodel = exp(tuningCurve_fullmodel) / (1 + exp(tuningCurve_fullmodel))
  # baselineFR_fullmodel = exp(intercept_fullmodel) / (1 + exp(intercept_fullmodel))
  
  # tuning curve half model
  y = modelMatrix[,1]
  x = modelMatrix[,(dim(modelMatrix)[2]-4):dim(modelMatrix)[2]]
  
  registerDoMC(cores = 10)
  halfmodel = cv.glmnet(x,y,family = "binomial",alpha = 1, nfolds = 10,parallel = TRUE)
  
  # intercept_halfmodel = coef(halfmodel,s="lambda.min")[1]
  # coefs_halfmodel = coef(halfmodel,s="lambda.min")[-1]
  # 
  # tuningCurve_halfmodel = trialTime_poly %*% coefs_halfmodel + intercept_halfmodel
  # tuningCurve_halfmodel = exp(tuningCurve_halfmodel) / (1 + exp(tuningCurve_halfmodel))
  # baselineFR_halfmodel = exp(intercept_halfmodel) / (1 + exp(intercept_halfmodel))
  # 
  # tuningCurve_fullmodel_LIST[[trialType]] = list(tuningCurve = tuningCurve_fullmodel,baselineFR = baselineFR_fullmodel)
  # tuningCurve_halfmodel_LIST[[trialType]] = list(tuningCurve = tuningCurve_halfmodel,baselineFR = baselineFR_halfmodel)
  # 
  fullmodel_LIST[[trialType]] = fullmodel
  halfmodel_LIST[[trialType]] = halfmodel

}


# plot

trialNames = names(tuningCurve_fullmodel_LIST)
maxValue_fullmodel = 0
maxValue_halfmodel = 0
for(trialType in trialNames){
  #maxValue = max(maxValue,TuningCurveData[[trialType]][[neuron]]$tuningCurve)
  maxValue_fullmodel = max(maxValue_fullmodel,tuningCurve_fullmodel_LIST[[trialType]]$tuningCurve)
  maxValue_halfmodel = max(maxValue_halfmodel,tuningCurve_halfmodel_LIST[[trialType]]$tuningCurve)
}

pdf(file="/Volumes/harisf/master/figures/thesis/tuningCurve_halfFullModel_s2n1v2.pdf",
    width = 7.236842, height = 4.219298)
par(mfrow=c(1,2))
epochStartTimes_mean = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/epochStartTimes_mean_s",session,".rds",sep=""))
plot(1,type="n",xlim=c(0,5),ylim=c(0,maxValue_halfmodel),
     xlab="trial time (s)",ylab=paste("prob. firing n",neuron,sep=""),
     main="Stimulus only")
mtext(paste("Neuron",neuron))
for(k in seq(1,3)){
  lines(seq(binSize,5,binSize),tuningCurve_halfmodel_LIST[[k]]$tuningCurve[seq(1,5/binSize)],col=c("darkgray","red","blue")[k])
}
abline(v=colMeans(epochStartTimes_mean),lty=2)
plot(1,type="n",xlim=c(0,5),ylim=c(0,maxValue_fullmodel),
     xlab="trial time (s)",ylab=paste("prob. firing n",neuron,sep=""),
     main="Full model")
mtext(paste("Neuron",neuron))
for(k in seq(1,3)){
  lines(seq(binSize,5,binSize),tuningCurve_fullmodel_LIST[[k]]$tuningCurve[seq(1,5/binSize)],col=c("darkgray","red","blue")[k])
}
abline(v=colMeans(epochStartTimes_mean),lty=2)
dev.off()


# plot(seq(binSize,5,binSize),tuningCurve_halfmodel[seq(1,5/binSize)],type="l")
# abline(h=baselineFR_halfmodel[seq(1,5/binSize)])
# plot(seq(binSize,5,binSize),tuningCurve_fullmodel[seq(1,5/binSize)],type="l")
# abline(h=baselineFR[seq(1,5/binSize)])

# model coefficients and regularization parameter 

for(k in seq(1,3)){
  print(halfmodel_LIST[[k]]$lambda.min)
  print(fullmodel_LIST[[k]]$lambda.min)
}

for(k in seq(1,3)){
  print(coef(halfmodel_LIST[[k]],s="lambda.min"))
  print(coef(fullmodel_LIST[[k]],s="lambda.min")[c(1,72:76)])
}




















# NEURON 1 SESSION 2 LASSO RE-DO
session = 2
neuron = 1
modelMatrix = readRDS(paste("/Volumes/work/harisf/session",session,"/modelMatrix/n",neuron,"_b1ms.rds",sep=""))
#modelMatrix = readRDS(paste("/global/work/harisf/session",session,"/modelMatrix/n",neuron,"_b1ms.rds",sep=""))
y = modelMatrix[,1]
x = modelMatrix[,(dim(modelMatrix)[2]-4):dim(modelMatrix)[2]]

fit = glmnet(x,y,family = "binomial",alpha = 1)
registerDoMC(cores = 10)
fit.cv = cv.glmnet(x,y,family = "binomial",alpha = 1, nfolds = 10,parallel = TRUE)

plot(fit)
plot(fit.cv)
coef(fit.cv,s="lambda.min")

pdf(file="/Volumes/harisf/master/figures/thesis/lassoModelWithOnlyStimulus_s2n1_V2.pdf",
    width = 8.070175+0.3, height = 4.192982+0.3)
par(mfrow=c(1,2))
plot(fit,label = F,xvar="lambda",col=seq(1,dim(x)[2]),xlab=expression(paste("log(",nu,")",sep="")))
legend("bottomright",c("P1","P2","P3","P4","P5"), lty=1, col=seq(1,dim(x)[2]),bty="n",cex=0.75)
plot(fit.cv,xlab=expression(paste("log(",nu,")",sep="")))
text(log(fit.cv$lambda.min)+0.15,0.02225,"min",cex = 0.8)
text(log(fit.cv$lambda.1se)-0.15,0.0212,"1se",cex = 0.8)
dev.off()

fit.glm = glm(y~as.matrix(x),family = "binomial")
coefficients(fit.glm)

tuningCurve = trialTime_poly %*% coef(fit.cv,s="lambda.min")[-1] + coef(fit.cv,s="lambda.min")[1]
tuningCurve = exp(tuningCurve) / (1 + exp(tuningCurve))
baselineFR = exp(coef(fit.cv,s="lambda.min")[1]) / (1 + exp(coef(fit.cv,s="lambda.min")[1]))


epochStartTimes_mean = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/epochStartTimes_mean_s",session,".rds",sep=""))
pdf(file="/Volumes/harisf/master/figures/thesis/lassoModelWithOnlyStimulus_s2n1_tuningCurvev3.pdf",
    width = 3.859649, height = 4.280702)
par(mfrow=c(1,1))
plot(seq(binSize,5,binSize),tuningCurve[seq(1,5/binSize)],type="l",
     xlab="trial time (s)", ylab="prob. firing n1",main="Neuron 1",col="darkgray")
abline(v=colMeans(epochStartTimes_mean),lty=2)
abline(h=baselineFR,lty=1,col="darkgray")
dev.off()




  



