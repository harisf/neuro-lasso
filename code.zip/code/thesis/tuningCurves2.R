session = 2
neuron = 1
trialType = c("goodTrials","correctL","correctR")[2]

if(trialType == "goodTrials")
  fileName = paste("/Volumes/work/harisf/session",session,"/modelMatrix/n",neuron,"_b1ms.rds",sep="")
if(trialType == "correctL")
  fileName = paste("/Volumes/work/harisf/session",session,"/modelMatrix_leftTrials/n",neuron,"_b1ms.rds",sep="")
if(trialType == "correctR")
  fileName = paste("/Volumes/work/harisf/session",session,"/modelMatrix_rightTrials/n",neuron,"_b1ms.rds",sep="")

modelMatrix = readRDS(fileName)

# fitting lasso model with ONLY stimulus effects
library(glmnet)
library(doMC)
y = modelMatrix[,1]
x = modelMatrix[,seq(dim(modelMatrix)[2]-4,dim(modelMatrix)[2])]

startTime = Sys.time()
registerDoMC(cores = 10)
model_lasso_cv = cv.glmnet(x,y,
                           family = "binomial",alpha = 1, nfolds = 10,
                           parallel = TRUE)
Sys.time() - startTime

str(model_lasso_cv)
modelCoefs = coef(model_lasso_cv,s="lambda.1se")

#binSize = 0.001
#x[seq(1,5/binSize),]
#tuningCurve = x[1:4999,] %*% modelCoefs[-1,1] + modelCoefs[1,1]
tuningCurve = x[1:4999,] %*% modelCoefs[-1,1]
tuningCurve = exp(tuningCurve) / (1 + exp(tuningCurve))
#baselineFR = exp(modelCoefs[1,1]) / (1 + exp(modelCoefs[1,1]))
plot(seq(0.001,5-0.001,0.001),tuningCurve,xlab="trial time (s)",ylab="prob. of firing",type="l")
#abline(h = baselineFR,lty=2)


neuron = 1
barplot(meanFR_LIST[[neuron]][,trialType])

saveRDS(meanFR_LIST,file = "/Volumes/harisf/master/data/variables/thesis/meanFR_LIST_s2.rds")
