library(R.matlab)
#library(grDevices)

data = readMat("/home/shomea/h/harisf/master/data/data_structure_ANM210861/data_structure_ANM210861_20130703.mat")
#data = readMat("/Volumes/harisf/master/data/data_structure_ANM210861/data_structure_ANM210861_20130701.mat")
totalNumberOfNeurons = length(data$obj[[12]][[1]])

getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

trials_correctR = which(data$obj[[8]][1,] == 1)
trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# # get trials where there was a correct LEFT lick 
trials_correctL = which(data$obj[[8]][2,] == 1)
trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]

# startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials.good]),na.rm=TRUE)
# startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials.good]),na.rm=TRUE)
# startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE) # aka lickOnset

#binSize = 0.01
#timeInterval = seq(0,5.5,binSize)
#trialWiseSpikes = matrix(0,ncol=length(timeInterval)-1,nrow=length(trials.good))
#spikeCountLIST = list()
#spikeCount = matrix(0,ncol=3,nrow=16))
#firingRate = spikeCount

#pdf(file = "/Volumes/harisf/master/figures/thesis/estFiringRate_trialTime.pdf",
#    width = 7.745614, height = 2.947368)
#LO <- layout(matrix(c(1,2,3),ncol=3,nrow=1))

#TRIALS = trials.good
#TRIALS = trials_correctL
#TRIALS = trials_correctR


firingRateLIST = list()
meanFR_LIST = list()

for(neuron in seq(1,totalNumberOfNeurons)){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  
  meanFR = matrix(0,ncol=3,nrow = 3)
  colnames(meanFR) = c("goodTrials","correctL","correctR")
  rownames(meanFR) = c("Sample","Delay","Response")
  
  for(k in seq(1,3)){
    TRIALS = list(trials.good,trials_correctL,trials_correctR)[[k]]
    spikeCount = matrix(0,ncol=3,nrow=length(TRIALS))
    firingRate = spikeCount
    for(j in seq(1,length(TRIALS))){
      trial_j = TRIALS[j]
      
      startOfSampleEpoch = data$obj[[9]][[3]][[1]][[1]][trial_j]
      startOfDelayEpoch = data$obj[[9]][[3]][[2]][[1]][trial_j]
      startOfResponseEpoch = data$obj[[9]][[3]][[3]][[1]][trial_j]
      timeInterval = c(startOfSampleEpoch,startOfDelayEpoch,startOfResponseEpoch,5.5)
      
      trialStartTime_j = data$obj[[7]][1,trial_j]
      eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
      #trialWiseSpikes[j,] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
      #spikeCount[neuron,] = spikeCount[neuron,] + as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
      spikeCount[j,] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
      firingRate[j,] = spikeCount[j,] / diff(timeInterval)
    }
    #firingRate[neuron,] = spikeCount[neuron,] / diff(timeInterval)
    firingRateLIST[[neuron]] = firingRate
    
    meanFR[,k] = colMeans(firingRateLIST[[neuron]])
  }
  
  meanFR_LIST[[neuron]] = meanFR
  
  
  #plot(seq(binSize,5,binSize),colMeans(trialWiseSpikes)/binSize,main=paste("Neuron",neuron),ylab="est. firing rate",xlab="trial time (s)")
  #abline(v=startOfSampleEpoch,lty=2)
  #abline(v=startOfDelayEpoch,lty=2)
  #abline(v=startOfResponseEpoch,lty=2)
}

saveRDS(meanFR_LIST,file = "/home/shomea/h/harisf/master/data/variables/thesis/meanFR_LIST_s3.rds")
#saveRDS(meanFR_LIST,file = "/Volumes/harisf/master/data/variables/thesis/meanFR_LIST_s1.rds")

meanFR_LIST = readRDS(file = "/Volumes/harisf/master/data/variables/thesis/meanFR_LIST_s2.rds")

#s1: width = 9.22807, height = 10.10526*2
#s2: width = 9.22807, height = 10.10526
#s3: width = 9.22807, height = 7.587719

pdf(file = "/Volumes/harisf/master/figures/thesis/averageFR_n269_s2v2.pdf",
    width = 7.578947, height = 2.964912)
#layout(matrix(seq(1,totalNumberOfNeurons),ncol=4,nrow=4,byrow = T))
layout(matrix(c(1,2,3),ncol=3,nrow=1,byrow = T))
#for(neuron in seq(1,totalNumberOfNeurons)){
for(neuron in c(2,6,9)){
  #barplot(meanFR_LIST[[neuron]][,"goodTrials"],col="gray",main=paste("Neuron",neuron),
  #        ylab="Average FR")
  
  plot(c(2,4,6),meanFR_LIST[[neuron]][,"goodTrials"],type="b",xlab = "",xaxt="n",xlim=c(1,7),
       col="gray",main=paste("Neuron",neuron),ylab="Average FR")
  axis(1,at=c(2,4,6),labels = names(meanFR_LIST[[neuron]][,"goodTrials"]))
  
}
dev.off()


layout(matrix(c(1,2,3),ncol=3,nrow=1))
plot(firingRate[1,],type="l")
plot(firingRate[2,],type="l")
plot(firingRate[3,],type="l")

ymax = sort(apply(trialWiseSpikes,2,max),decreasing = TRUE)[1]/binSize
plot(1,type="n",ylim=c(0,ymax),xlim=c(0,5),ylab="firing rate",xlab="trial time (s)")
for(j in seq(1,dim(trialWiseSpikes)[1])){
  lines(seq(binSize,5,binSize),trialWiseSpikes[j,]/binSize,col=rgb(0,0,0,0.1),pch=16)
}

j = 2
plot(as.spikeTrain((trialWiseSpikes[j,]*seq(binSize,5,binSize))[which(trialWiseSpikes[j,]>0)]))





# NEED LEFT/RIGTH VERSION OF FIGURE 3.3 IN THESIS

trials_correctR = which(data$obj[[8]][1,] == 1)
trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# # get trials where there was a correct LEFT lick 
trials_correctL = which(data$obj[[8]][2,] == 1)
trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]

pdf(file = "/Volumes/harisf/master/figures/thesis/estFiringRate_trialTime_leftRight.pdf",
    width = 7.745614, height = 2.947368*3)
LO <- layout(matrix(seq(1,9),ncol=3,nrow=3,byrow = T))
for(neuron in sample(seq(1,16),3)){
#for(neuron in seq(1,3)){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  
  for(k in seq(1,3)){
    TRIALS = list(trials.good,trials_correctL,trials_correctR)[[k]]
    binSize = 0.01
    timeInterval = seq(0,5,binSize)
    trialWiseSpikes = matrix(0,ncol=length(timeInterval)-1,nrow=length(TRIALS))
    
    for(j in seq(1,length(TRIALS))){
      trial_j = TRIALS[j]
      trialStartTime_j = data$obj[[7]][1,trial_j]
      eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
      trialWiseSpikes[j,] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
      #trialWiseSpikes[1,] = trialWiseSpikes[1,] + as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    }
    
    startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][TRIALS]),na.rm=TRUE)
    startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][TRIALS]),na.rm=TRUE)
    startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][TRIALS]),na.rm=TRUE) # aka lickOnset
    
    plot(seq(binSize,5,binSize),colMeans(trialWiseSpikes)/binSize,main=paste("Neuron",neuron),ylab="est. firing rate",xlab="trial time (s)",col=rgb(0,0,0,0.5))
         #ylim=c(0,1600))
    if(k == 2)
      mtext("Correct left trials")
    if(k == 3)
      mtext("Correct right trials")
    abline(v=startOfSampleEpoch,lty=2)
    abline(v=startOfDelayEpoch,lty=2)
    abline(v=startOfResponseEpoch,lty=2)
  }
}
dev.off()





#s1: width = 9.22807, height = 10.10526*2
#s2: width = 9.22807, height = 10.10526
#s3: width = 9.22807, height = 7.587719

session = 3

if(session == 1){
  totalNumberOfNeurons = 30
  plotwidth = 9.22807+0.4
  plotheight = (10.10526+0.5)*2
  #layout(matrix(seq(1,totalNumberOfNeurons+2),ncol=4,nrow=8,byrow = T))
  meanFR_LIST = readRDS(file = "/Volumes/harisf/master/data/variables/thesis/meanFR_LIST_s1.rds") 
}
if(session == 2){
  totalNumberOfNeurons = 16
  plotwidth = 9.22807+0.4
  plotheight = 10.10526+0.5
  #layout(matrix(seq(1,totalNumberOfNeurons),ncol=4,nrow=4,byrow = T))
  meanFR_LIST = readRDS(file = "/Volumes/harisf/master/data/variables/thesis/meanFR_LIST_s2.rds") 
}
if(session == 3){
  totalNumberOfNeurons = 12
  plotwidth = 9.22807+0.4
  plotheight = 7.587719+0.5
  #layout(matrix(seq(1,totalNumberOfNeurons),ncol=3,nrow=4,byrow = T))
  meanFR_LIST = readRDS(file = "/Volumes/harisf/master/data/variables/thesis/meanFR_LIST_s3.rds") 
}


pdf(file = paste("/Volumes/harisf/master/figures/thesis/averageFR_trialTypes_s",session,"v2.pdf",sep=""),
    width = plotwidth, height = plotheight)
#layout(matrix(seq(1,totalNumberOfNeurons),ncol=4,nrow=4,byrow = T))
#layout(matrix(c(1,2,3),ncol=3,nrow=1,byrow = T))
if(session == 1)
  layout(matrix(seq(1,totalNumberOfNeurons+2),ncol=4,nrow=8,byrow = T))
if(session == 2)
  layout(matrix(seq(1,totalNumberOfNeurons),ncol=4,nrow=4,byrow = T))
if(session == 3)
  layout(matrix(seq(1,totalNumberOfNeurons),ncol=4,nrow=3,byrow = T))
for(neuron in seq(1,totalNumberOfNeurons)){
#for(neuron in c(2,6,9)){
  #barplot(meanFR_LIST[[neuron]][,"goodTrials"],col="gray",main=paste("Neuron",neuron),
  #        ylab="Average FR")
  
  plot(c(2,4,6),meanFR_LIST[[neuron]][,"goodTrials"],type="b",xlab = "",xaxt="n",xlim=c(1,7),ylim=c(0,max(meanFR_LIST[[neuron]])),
       col="gray",main=paste("Neuron",neuron),ylab="Average FR",lty=1)
  lines(c(2,4,6),meanFR_LIST[[neuron]][,"correctL"],lty=1,
        col="red",type="b")
  lines(c(2,4,6),meanFR_LIST[[neuron]][,"correctR"],lty=1,
        col="blue",type="b")
  axis(1,at=c(2,4,6),labels = names(meanFR_LIST[[neuron]][,"goodTrials"]))
  
}
dev.off()























