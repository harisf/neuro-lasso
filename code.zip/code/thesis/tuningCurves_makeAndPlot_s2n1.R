library(foreach)
library(doParallel)
library(glmnet)
library(doMC)

pdiscretizeSpikeData = function(neuron,TRIALS){
  eventTrials = eventData[[2]][[neuron]]
  eventTimes = eventData[[1]][[neuron]]
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  #mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  #no_cores = detectCores()-1
  #no_cores = 10
  registerDoParallel(cores = detectCores()-1)
  mat = foreach(trial_j = TRIALS,.combine = rbind) %dopar% {
    #mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
    
    trialStartTime_j = trialStartTime[[trial_j]]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    mat_j
  }
  stopImplicitCluster()
  
  colnames(mat) = c("trialId","trialTime",paste("spikeCountj",neuron,sep=""))
  mat = as.data.frame(mat)
  return(mat)
}

binSize = 0.001
session = 2
# eventData = readRDS(paste("/home/shomea/h/harisf/master/data/variables/thesis/eventData_s",session,".rds",sep=""))
# trialTypeData = readRDS(paste("/home/shomea/h/harisf/master/data/variables/thesis/trialTypeData_s",session,".rds",sep=""))
# trialStartTime = readRDS(paste("/home/shomea/h/harisf/master/data/variables/thesis/trialStartTime_LIST_s",session,".rds",sep=""))
eventData = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/eventData_s",session,".rds",sep=""))
trialTypeData = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/trialTypeData_s",session,".rds",sep=""))
trialStartTime = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/trialStartTime_LIST_s",session,".rds",sep=""))

totalNumberOfNeurons = c(30,16,12)[session]

neuron = 1

trialType = c("goodTrials","correctL","correctR")[1]
TRIALS = trialTypeData[[trialType]]

spikeData = pdiscretizeSpikeData(neuron,TRIALS)

deg = 5
predMat = cbind(spikeData[,3],poly(spikeData[,2],degree = deg))
txtPolyname = NULL
for(i in seq(1,deg))
  txtPolyname = c(txtPolyname,paste("poly(lickOnset)",i,sep = ""))
colnames(predMat)[seq(dim(predMat)[2]-deg+1,dim(predMat)[2])] = txtPolyname

# fitting lasso model with ONLY stimulus effects
y = predMat[,1]
x = predMat[,-1]

model_glm = glm(y ~x,family = "binomial")

model_lasso = glmnet(x,y,family = "binomial",alpha = 1)

#startTime = Sys.time()
registerDoMC(cores = 10)
model_lasso_cv = cv.glmnet(x,y,
                           family = "binomial",alpha = 1, nfolds = 10,
                           parallel = TRUE)
#Sys.time() - startTime

pdf(file="/Volumes/harisf/master/figures/thesis/lassoModelWithOnlyStimulus_s2n1.pdf",
    width = 8.070175, height = 4.192982)
par(mfrow=c(1,2))
plot(model_lasso,label = F,xvar="lambda",col=seq(1,dim(x)[2]),xlab=expression(paste("log(",nu,")",sep="")))
legend("bottomright",c("P1","P2","P3","P4","P5"), lty=1, col=seq(1,dim(x)[2]),bty="n",cex=0.75)
plot(model_lasso_cv,xlab=expression(paste("log(",nu,")",sep="")))
text(log(model_lasso_cv$lambda.min)+0.15,0.0221,"min",cex = 0.8)
text(log(model_lasso_cv$lambda.1se)-0.15,0.02135,"1se",cex = 0.8)
dev.off()

library(hdi)
library(parallel)

lasso.cv.lambda.min = function (x, y, nfolds = 10, grouped = nrow(x) > 3 * nfolds, 
                                ...){
  suppressMessages(library(doMC))
  registerDoMC(cores=10)
  fit.cv <- cv.glmnet(x, y, nfolds = nfolds, grouped = grouped, parallel = TRUE,
                      ...)
  sel <- predict(fit.cv, type = "nonzero", s = "lambda.min")
  sel[[1]]
}

glm.pval.x.as.matrix = function (x, y, family = "binomial", verbose = FALSE, ...){
  fit.glm <- glm(y ~ as.matrix(x), family = family, ...)
  fit.summary <- summary(fit.glm)
  if (!fit.glm$converged & verbose) {
    #print(fit.summary)
  }
  pval.sel <- coef(fit.summary)[-1, 4]
  names(pval.sel) <- colnames(x)
  pval.sel
}

fit.multiSplit <- multi.split(x,y, ci = FALSE, B = 50,
                   classical.fit = glm.pval.x.as.matrix,
                   model.selector = lasso.cv.lambda.min, args.model.selector = list(family = "binomial"),
                   #parallel = TRUE, ncores = 10,
                   return.selmodels = FALSE, verbose = FALSE)

fit.multiSplit$pval.corr
summary(model_glm)

#str(model_lasso_cv)
modelCoefs = coef(model_lasso_cv,s="lambda.min")

tuningCurve = x[1:4999,] %*% modelCoefs[-1,1] + modelCoefs[1,1]
tuningCurve = exp(tuningCurve) / (1 + exp(tuningCurve))
baselineFR = exp(modelCoefs[1,1]) / (1 + exp(modelCoefs[1,1]))



epochStartTimes_mean = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/epochStartTimes_mean_s",session,".rds",sep=""))
pdf(file="/Volumes/harisf/master/figures/thesis/lassoModelWithOnlyStimulus_s2n1_tuningCurve.pdf",
    width = 3.859649, height = 4.280702)
par(mfrow=c(1,1))
plot(seq(binSize,5-binSize,binSize),tuningCurve,type="l",
     xlab="trial time(s)", ylab="prob. firing n1",main="Neuron 1",col="darkgray")
abline(v=colMeans(epochStartTimes_mean),lty=2)
abline(h=baselineFR,lty=1,col="darkgray")
dev.off()






