###########################
# get and save tuningCurves
###########################

library(foreach)
library(doParallel)
library(glmnet)
library(doMC)

pdiscretizeSpikeData = function(neuron,TRIALS){
  eventTrials = eventData[[2]][[neuron]]
  eventTimes = eventData[[1]][[neuron]]
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  #mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  #no_cores = detectCores()-1
  #no_cores = 10
  registerDoParallel(cores = detectCores()-1)
  mat = foreach(trial_j = TRIALS,.combine = rbind) %dopar% {
    #mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
    
    trialStartTime_j = trialStartTime[[trial_j]]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    mat_j
  }
  stopImplicitCluster()
  
  colnames(mat) = c("trialId","trialTime",paste("spikeCountj",neuron,sep=""))
  mat = as.data.frame(mat)
  return(mat)
}

binSize = 0.001
session = 2
eventData = readRDS(paste("/home/shomea/h/harisf/master/data/variables/thesis/eventData_s",session,".rds",sep=""))
trialTypeData = readRDS(paste("/home/shomea/h/harisf/master/data/variables/thesis/trialTypeData_s",session,".rds",sep=""))
trialStartTime = readRDS(paste("/home/shomea/h/harisf/master/data/variables/thesis/trialStartTime_LIST_s",session,".rds",sep=""))

totalNumberOfNeurons = c(30,16,12)[session]

getTuningCurveData = function(TRIALS){
  
  tuningCurveData_NEURON = list()
  for(neuron in seq(1,totalNumberOfNeurons)){
    spikeData = pdiscretizeSpikeData(neuron,TRIALS)
    
    deg = 5
    predMat = cbind(spikeData[,3],poly(spikeData[,2],degree = deg))
    txtPolyname = NULL
    for(i in seq(1,deg))
      txtPolyname = c(txtPolyname,paste("poly(lickOnset)",i,sep = ""))
    colnames(predMat)[seq(dim(predMat)[2]-deg+1,dim(predMat)[2])] = txtPolyname
    
    # fitting lasso model with ONLY stimulus effects
    y = predMat[,1]
    x = predMat[,-1]
    
    #startTime = Sys.time()
    registerDoMC(cores = 10)
    model_lasso_cv = cv.glmnet(x,y,
                               family = "binomial",alpha = 1, nfolds = 10,
                               parallel = TRUE)
    #Sys.time() - startTime
    
    #str(model_lasso_cv)
    modelCoefs = coef(model_lasso_cv,s="lambda.min")
    
    tuningCurve = x[1:4999,] %*% modelCoefs[-1,1] + modelCoefs[1,1]
    tuningCurve = exp(tuningCurve) / (1 + exp(tuningCurve))
    baselineFR = exp(modelCoefs[1,1]) / (1 + exp(modelCoefs[1,1]))
    
    
    tuningCurveData_NEURON[[neuron]] = list(tuningCurve = tuningCurve, baselineFR = baselineFR)
  }
  
  return(tuningCurveData_NEURON)
}

TuningCurveData = list()
for(trialType in c("goodTrials","correctL","correctR")){
  TRIALS = trialTypeData[[trialType]]
  TuningCurveData[[trialType]] = getTuningCurveData(TRIALS)
}

saveRDS(TuningCurveData,file = paste("/home/shomea/h/harisf/master/data/variables/thesis/TuningCurveData_s",session,"v2.rds",sep=""))


###################
# plot tuningCurves
###################
#s1: width = 9.22807, height = (10.10526+0.8)*2
#s2: width = 9.22807, height = 10.10526+0.8
#s3: width = 9.22807, height = 7.587719+0.8

#binSize = 0.001
session = 3
TuningCurveData = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/TuningCurveData_s",session,"v2.rds",sep=""))
epochStartTimes_mean = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/epochStartTimes_mean_s",session,".rds",sep=""))

# pdf(file = paste("/Volumes/harisf/master/figures/thesis/tuningCurves_onlyCovariateTrialTime_s",session,"_withBaselineFR.pdf",sep=""),
pdf(file = paste("/Volumes/harisf/master/figures/thesis/tuningCurves_onlyCovariateTrialTime_s",session,".pdf",sep=""),
    width = 9.22807, height = 7.587719+0.8)
layout(matrix(seq(1,12),ncol=4,nrow=3,byrow = T))
for(neuron in seq(1,12)){
  trialNames = names(TuningCurveData)
  maxValue = 0
  #baselineFR_mean = 0
  #baselineFR = NULL
  for(trialType in trialNames){
    maxValue = max(maxValue,TuningCurveData[[trialType]][[neuron]]$tuningCurve)
    #baselineFR_mean = baselineFR_mean + TuningCurveData[[trialType]][[neuron]]$baselineFR
    #baselineFR = c(baselineFR,TuningCurveData[[trialType]][[neuron]]$baselineFR)
  }
  #baselineFR_mean = baselineFR_mean/3
  plot(1,type="n",xlim=c(binSize,5-binSize),ylim=c(0,maxValue),
       xlab="trial time (s)",ylab=paste("prob. firing n",neuron,sep=""),main=paste("Neuron",neuron))
  for(k in seq(1,3)){
    trialType = trialNames[k]
    lines(seq(binSize,5-binSize,binSize),TuningCurveData[[trialType]][[neuron]]$tuningCurve,
          col=c("darkgray","red","blue")[k])
  }
  abline(v=colMeans(epochStartTimes_mean),lty=2)
  #abline(h=baselineFR_mean)
  #abline(h=baselineFR,col=c("darkgray","red","blue"),lty=2)
}
dev.off()
  


















