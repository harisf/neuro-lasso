library(R.matlab)

data = readMat("\\\\sambaad.stud.ntnu.no/harisf/master/data/data_structure_ANM210861/data_structure_ANM210861_20130703.mat")

for(neuron in seq(1,30)){
  cellType = data$obj[[12]][[3]][[neuron]][[1]][[6]]
  if(length(cellType) != 0)
    cat("Neuron",neuron,": ",as.character(cellType[[1]]),"\n")
  else
    cat("Neuron",neuron,": ","NA","\n")
}
