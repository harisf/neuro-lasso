exponent = seq(4,8)
elapsedTime = c(0.028,0.049,0.099,0.274,2.453)#,25.932)

pdf(file="/Volumes/harisf/master/figures/thesis/computationTimeInnerProduct.pdf",
    width = 4.482456, height = 4.868421)
plot(exponent,elapsedTime,type="b",lty=2,xaxt="n",
     xlab=expression(paste("size of ",x[j],sep="")),
     ylab="elapsed time (s)", main = "Computation time of inner product")#,cex.main = 1)
#mtext("of inner product")
axis(1,at=exponent,
     labels = c(expression(10^4),expression(10^5),expression(10^6),expression(10^7),expression(10^8)))#,expression(10^9)))
dev.off()