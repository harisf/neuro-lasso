library(glmnet)
library(doMC)

session = 2
neuron = 1

k = 3
trialType = c("goodTrials","correctL","correctR")[k]

if(k == 1)
  modelMatrix = readRDS(paste("/global/work/harisf/session",session,"/modelMatrix/n",neuron,"_b1ms.rds",sep=""))
if(k == 2)
  modelMatrix = readRDS(paste("/global/work/harisf/session",session,"/modelMatrix_leftTrials/n",neuron,"_b1ms.rds",sep=""))
if(k == 3)
  modelMatrix = readRDS(paste("/global/work/harisf/session",session,"/modelMatrix_rightTrials/n",neuron,"_b1ms.rds",sep=""))


y = modelMatrix[,1]

# fit model with only stimulus
x = modelMatrix[,(dim(modelMatrix)[2]-4):dim(modelMatrix)[2]]
fit_stim = glmnet(x,y,family = "binomial")

registerDoMC(cores = 10)
fitcv_stim = cv.glmnet(x,y,family = "binomial",alpha = 1, nfolds = 10,parallel = TRUE)

# fit full model
x = modelMatrix[,-1]
fit_full = glmnet(x,y,family = "binomial")

saveRDS(fitcv_stim,paste("/home/shomea/h/harisf/master/data/variables/thesis/lassoFit_cv_stimonly_s",session,"n",neuron,"_b1ms_",trialType,".rds",sep=""))
saveRDS(fit_stim,paste("/home/shomea/h/harisf/master/data/variables/thesis/lassoFit_nocv_stimonly_s",session,"n",neuron,"_b1ms_",trialType,".rds",sep=""))
saveRDS(fit_full,paste("/home/shomea/h/harisf/master/data/variables/thesis/lassoFit_nocv_full_s",session,"n",neuron,"_b1ms_",trialType,".rds",sep=""))



for(k in seq(1,3)){
  trialType = c("goodTrials","correctL","correctR")[k]
  
  # deviance
  fit_stim = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/lassoFit_nocv_stimonly_s",session,"n",neuron,"_b1ms_",trialType,".rds",sep=""))
  fit_full = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/lassoFit_nocv_full_s",session,"n",neuron,"_b1ms_",trialType,".rds",sep=""))
  
  fitcv_stim = readRDS(paste("/Volumes/harisf/master/data/variables/thesis/lassoFit_cv_stimonly_s",session,"n",neuron,"_b1ms_",trialType,".rds",sep=""))
  
  if(k == 1)
    fitcv_full = readRDS(paste("/Volumes/work/harisf/session",session,"/lassoFit/","n",neuron,"_b1ms.rds",sep=""))
  if(k == 2)
    fitcv_full = readRDS(paste("/Volumes/work/harisf/session",session,"/lassoFit_leftTrials/","n",neuron,"_b1ms.rds",sep=""))
  if(k == 3)
    fitcv_full = readRDS(paste("/Volumes/work/harisf/session",session,"/lassoFit_rightTrials/","n",neuron,"_b1ms.rds",sep=""))
  
  
  devratio.stim = fit_stim$dev.ratio[which(fit_stim$lambda == fitcv_stim$lambda.min)]
  dev.stim = deviance(fit_stim)[which(fit_stim$lambda == fitcv_stim$lambda.min)]
  #aic.mette_stim = deviance(fit_stim)[which(fit_stim$lambda == fitcv_stim$lambda.min)] + length(which(coef(fitcv_stim,s="lambda.min") != 0)) 
  
  devratio.full = fit_full$dev.ratio[which(fit_full$lambda == fitcv_full$lambda.min)]
  dev.full = deviance(fit_full)[which(fit_full$lambda == fitcv_full$lambda.min)]
  #aic.mette_full = deviance(fit_full)[which(fit_full$lambda == fitcv_full$lambda.min)] + length(which(coef(fitcv_full,s="lambda.min") != 0)) 
  
  cat(trialType,": \n",sep="")
  cat("\tDeviance full: ",dev.full," \tDeviance stim: ",dev.stim,"\n",sep="")
  cat("\tDevRatio full: ",devratio.full," \tDevRatio stim: ",devratio.stim,"\n",sep="")
}

# par(mfrow=c(1,2))
# plot(deviance(fit_stim))
# plot(deviance(fit_full))
# 
# 
# plot(log(fit_full$lambda),fit_full$dev.ratio)






