library(R.matlab)
library(foreach)

data = readMat("/Volumes/harisf/master/data/data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

data3 = readMat("data_structure_ANM210861/data_structure_ANM210861_20130703.mat")

getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}

data = data2
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
trials_correctR = which(data$obj[[8]][1,] == 1)
trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# # get trials where there was a correct LEFT lick 
trials_correctL = which(data$obj[[8]][2,] == 1)
trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]


totalNumberOfNeurons = length(data$obj[[12]][[1]])

eventTimesLIST = foreach(neuron = seq(1,totalNumberOfNeurons)) %do% {
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  
  eventTimes[is.element(eventTrials,trials.good)]
}

saveRDS(eventTimesLIST,file="variables/thesis/eventTimesLIST_s2.rds")


data = data2
trials.good = getGoodTrials()
totalNumberOfNeurons = length(data$obj[[12]][[1]])

binSize = 0.01
timeInterval = seq(0,5,binSize)
trialWiseSpikes = matrix(0,ncol=length(timeInterval)-1,nrow=length(trials.good))

approxFiringRate = foreach(neuron = seq(1,totalNumberOfNeurons),.combine = c) %do% {
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  
  for(j in seq(1,length(trials.good))){
    trial_j = trials.good[j]
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    trialWiseSpikes[j,] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
  }
  mean(colMeans(trialWiseSpikes)/binSize)
}

saveRDS(approxFiringRate,file="variables/thesis/approxFiringRate_s2_mean.rds")


approxFiringRate_s1 = readRDS(file="/Volumes/harisf/master/data/variables/thesis/approxFiringRate_s1_mean.rds")
approxFiringRate_s2 = readRDS(file="/Volumes/harisf/master/data/variables/thesis/approxFiringRate_s2_mean.rds")
approxFiringRate_s3 = readRDS(file="/Volumes/harisf/master/data/variables/thesis/approxFiringRate_s3_mean.rds")

pdf(file="/Volumes/harisf/master/figures/thesis/approximateFiringRate.pdf",
    width = 7.780702, height = 4.526316)
plot(1,type="n",xlim=c(0.5,3.5),ylim=c(0,25),xaxt="n",ylab="spikes (Hz)",main="Approximate Firing Rate",xlab="Session")
axis(1,at=c(1,2,3),labels = c(1,2,3))
boxplot(approxFiringRate_s1,add=T,at=1)
boxplot(approxFiringRate_s2,add=T,at=2)
boxplot(approxFiringRate_s3,add=T,at=3)


box1 = boxplot.stats(approxFiringRate_s1)
box1$out = sort(box1$out)
text(x=1.2,y=box1$out[1]-0.35,which(approxFiringRate_s1 == box1$out[1]))
text(x=1.2,y=box1$out[2]+0.35,which(approxFiringRate_s1 == box1$out[2]))
text(x=1.2,y=box1$out[3]-0.35,which(approxFiringRate_s1 == box1$out[3]))
text(x=1.2,y=box1$out[4]+0.35,which(approxFiringRate_s1 == box1$out[4]))
text(x=1.2,y=box1$out[5],which(approxFiringRate_s1 == box1$out[5]))

box2 = boxplot.stats(approxFiringRate_s2)
text(x=2.2,y=box2$out,which(approxFiringRate_s2 == box2$out))
dev.off()



library(STAR)
#s1
# plotHeight = 8.787719+1
# plotWidth = 6.236842*3

#s2
# plotHeight = 5.736842
# plotWidth = 5.921053*3

#s3
plotHeight = 5.017544
plotWidth = 5.035088*3

setEPS()
postscript(file="/Volumes/harisf/master/figures/thesis/cellActivity_s3_goodAndLeftRightTrials_v2.eps",
    width = plotWidth, height = plotHeight)
par(mfrow=c(1,3))
#par(mfrow=c(1,1))
eventTimesLIST = readRDS(file="/Volumes/harisf/master/data/variables/thesis/eventTimesLIST_s3.rds")
eventTimesLIST_left = readRDS(file="/Volumes/harisf/master/data/variables/thesis/eventTimesLIST_s3_leftTrials.rds")
eventTimesLIST_right = readRDS(file="/Volumes/harisf/master/data/variables/thesis/eventTimesLIST_s3_rightTrials.rds")
plot(as.repeatedTrain(eventTimesLIST),ylab="Neuron",xlab="Session time (s)",pch="|",
     main="Session 3")
plot(as.repeatedTrain(eventTimesLIST_left),ylab="Neuron",xlab="Session time (s)",pch="|",
     main="Session 3")
mtext("Correct left trials")
plot(as.repeatedTrain(eventTimesLIST_right),ylab="Neuron",xlab="Session time (s)",pch="|",
     main="Session 3")
mtext("Correct right trials")
dev.off()






