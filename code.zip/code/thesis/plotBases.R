getBasis2 = function(nBases,binSize){
  # b = binSize*5
  # peaks = c(binSize,binSize*50) # old basis
  b = binSize*nBases
  peaks = c(binSize,binSize*10*nBases)
  #peaks = c(binSize,binSize*5*nBases) #short bases
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}

getMedianBasis = function(nBases,binSize_original,binSize_median){
  bas_original = getBasis2(nBases,binSize = binSize_original)
  
  pointsToCombine = binSize_median / binSize_original
  totalCombinedPoints = floor(dim(bas_original$bas)[1] / pointsToCombine)
  
  indexes = list()
  for(i in seq(0,totalCombinedPoints - 1))
    indexes = c(indexes,list(seq(1,pointsToCombine) + pointsToCombine * i))
  
  # numberOfRemainingPoints = dim(bas$bas)[1] %% pointsToCombine
  # THESE LAST POINTS ARE DISCARDED
  # if(numberOfRemainingPoints != 0)
  #   indexes = c(indexes,list(seq(1,numberOfRemainingPoints) + indexes[[totalCombinedPoints]][pointsToCombine]))
  
  binSize_median = list(bas = matrix(NA,ncol = dim(bas_original$bas)[2],nrow = length(indexes)), 
                        bas_orth = matrix(NA,ncol = dim(bas_original$bas)[2],nrow = length(indexes)),
                        tau_N = bas_original$tau_N)
  for(i in seq(1,length(indexes))){
    binSize_median$bas[i,] = bas_original$bas[floor(median(indexes[[i]])),]
    binSize_median$bas_orth[i,] = bas_original$bas_orth[floor(median(indexes[[i]])),]
  }
  binSize_median
}




# pdf(file="/Volumes/harisf/master/figures/thesis/bases.pdf",
#     width = dev.size()[1],height = dev.size()[2])
# LO <- layout(matrix(c(1,2,3,4),ncol = 2))
# binSize = 0.001
# TITLE = c("History","Coupling","History orthogonal","Coupling orthogonal")
# nBASES = c(10,4)
# for(j in c(1,2)){
#   nBases = nBASES[j]
#   basList = getBasis2(nBases,binSize)
#   tau_N = basList$tau_N
#   bas = basList$bas
#   bas_orth = basList$bas_orth
#   
#   matplot(bas,type="l",lty=1,col=seq(1,nBases),main=TITLE[j],xlab="lag (ms)",ylab="")
#   matplot(bas_orth,type="l",lty=1,col=seq(1,nBases),main=TITLE[j+2],xlab="lag (ms)",ylab="")
# }
# # dev.off()

binSize_original = 0.001
binSize_median = 0.01


pdf(file="/Volumes/harisf/master/figures/thesis/bases_median_orthv2.pdf",
    width = dev.size()[1],height = dev.size()[2])
layout(matrix(c(1,2,3,4),ncol = 2,byrow = F))
nBases = 10 
basList_original = getBasis2(nBases,binSize_original)
basList_median = getMedianBasis(nBases,binSize_original,binSize_median)

matplot(seq(binSize_original,dim(basList_original$bas)[1]*binSize_original,binSize_original)*1000,
        basList_original$bas_orth,type="b",lty=1,col=seq(1,nBases),pch=1,
        xlab = "lag (ms)",ylab="",main=expression(paste("History ",Delta,"t = 1 ms",sep="")) )
matplot(seq(binSize_median,dim(basList_median$bas)[1]*binSize_median,binSize_median)*1000,
        basList_median$bas_orth,type="b",lty=1,col=seq(1,nBases),pch=1,
        xlab = "lag (ms)",ylab="",main=expression(paste("History ",Delta,"t = 10 ms",sep="")) )

nBases = 4
basList_original = getBasis2(nBases,binSize_original)
basList_median = getMedianBasis(nBases,binSize_original,binSize_median)

matplot(seq(binSize_original,dim(basList_original$bas)[1]*binSize_original,binSize_original)*1000,
        basList_original$bas_orth,type="b",lty=1,col=seq(1,nBases),pch=1,
        xlab = "lag (ms)",ylab="",main=expression(paste("Coupling ",Delta,"t = 1 ms",sep="")) )
matplot(seq(binSize_median,dim(basList_median$bas)[1]*binSize_median,binSize_median)*1000,
        basList_median$bas_orth,type="b",lty=1,col=seq(1,nBases),pch=1,
        xlab = "lag (ms)",ylab="",main=expression(paste("Coupling ",Delta,"t = 10 ms",sep="")) )

dev.off()


pdf(file="/Volumes/harisf/master/figures/thesis/bases_medianv2.pdf",
    width = dev.size()[1],height = dev.size()[2])
layout(matrix(c(1,2,3,4),ncol = 2,byrow = F))
nBases = 10 
basList_original = getBasis2(nBases,binSize_original)
basList_median = getMedianBasis(nBases,binSize_original,binSize_median)

matplot(seq(binSize_original,dim(basList_original$bas)[1]*binSize_original,binSize_original)*1000,
        basList_original$bas,type="b",lty=1,col=seq(1,nBases),pch=1,
        xlab = "lag (ms)",ylab="",main=expression(paste("History ",Delta,"t = 1 ms",sep="")) )
matplot(seq(binSize_median,dim(basList_median$bas)[1]*binSize_median,binSize_median)*1000,
        basList_median$bas,type="b",lty=1,col=seq(1,nBases),pch=1,
        xlab = "lag (ms)",ylab="",main=expression(paste("History ",Delta,"t = 10 ms",sep="")) )

nBases = 4
basList_original = getBasis2(nBases,binSize_original)
basList_median = getMedianBasis(nBases,binSize_original,binSize_median)

matplot(seq(binSize_original,dim(basList_original$bas)[1]*binSize_original,binSize_original)*1000,
        basList_original$bas,type="b",lty=1,col=seq(1,nBases),pch=1,
        xlab = "lag (ms)",ylab="",main=expression(paste("Coupling ",Delta,"t = 1 ms",sep="")) )
matplot(seq(binSize_median,dim(basList_median$bas)[1]*binSize_median,binSize_median)*1000,
        basList_median$bas,type="b",lty=1,col=seq(1,nBases),pch=1,
        xlab = "lag (ms)",ylab="",main=expression(paste("Coupling ",Delta,"t = 10 ms",sep="")) )

dev.off()





