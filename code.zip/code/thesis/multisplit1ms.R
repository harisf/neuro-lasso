


library(Matrix)
library(parallel)
library(hdi)
library(glmnet)

lasso.cv.lambda.min = function (x, y, nfolds = 10, grouped = nrow(x) > 3 * nfolds, 
                                ...){
  suppressMessages(library(doMC))
  registerDoMC(cores=10)
  fit.cv <- cv.glmnet(x, y, nfolds = nfolds, grouped = grouped, parallel = TRUE,
                      ...)
  sel <- predict(fit.cv, type = "nonzero", s = "lambda.min")
  sel[[1]]
}

glm.pval.x.as.matrix = function (x, y, family = "binomial", verbose = FALSE, ...){
  fit.glm <- glm(y ~ as.matrix(x), family = family, ...)
  fit.summary <- summary(fit.glm)
  if (!fit.glm$converged & verbose) {
    #print(fit.summary)
  }
  pval.sel <- coef(fit.summary)[-1, 4]
  names(pval.sel) <- colnames(x)
  pval.sel
}


session = 2
neuron = 1

modelMatrix = readRDS(paste("/global/work/harisf/session",session,"/modelMatrix10ms/n",neuron,"_b10ms.rds",sep=""))

y = modelMatrix[,1]
y[which(y > 1)] = 1
x = modelMatrix[,-1]

startTime = Sys.time()
fit <- multi.split(x,y, ci = FALSE, B = 50,
                   classical.fit = glm.pval.x.as.matrix,
                   model.selector = lasso.cv.lambda.min, args.model.selector = list(family = "binomial"),
                   parallel = TRUE, ncores = 10,
                   return.selmodels = FALSE, verbose = FALSE)

endTime = Sys.time() - startTime
cat("Multisplit done for neuron ",neuron,". Time used: ",endTime," ",attr(endTime,"units"),". \n",sep="")


#saveRDS(fit,paste("/global/work/harisf/session",session,"/multisplit/n",neuron,"_b1ms.rds",sep=""))

# made the file "multisplit" at 15:27 (6th June)
# for bin 1 ms, multisplit used  about 6 hours and 15 min (session 2, neuron 1)








# getBasis2 = function(nBases,binSize){
#   # b = binSize*5
#   # peaks = c(binSize,binSize*50) # old basis
#   b = binSize*nBases
#   peaks = c(binSize,binSize*10*nBases)
#   #peaks = c(binSize,binSize*5*nBases) #short bases
#   
#   # nonlinearity for stretching x axis (and its inverse)
#   nlin = function(x){log(x+1e-20)}
#   invnl = function(x){exp(x)-1e-20}
#   
#   # Generate basis of raised cosines
#   yrange = nlin(peaks+b)
#   db = diff(yrange)/(nBases-1)
#   centers = seq(yrange[1],yrange[2],db)
#   maxt = invnl(yrange[2]+2*db)-b
#   iht = seq(binSize,maxt,binSize)
#   nt = length(iht)
#   
#   raisedCosineBasis = function(x,c,dc){
#     (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
#   }
#   
#   ihbasis = matrix(NA,nrow = nt,ncol = nBases)
#   for(i in seq(1,nt)){
#     for(j in seq(1,length(centers))){
#       ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
#     }
#   }
#   #matplot(ihbasis,type="b",pch=seq(1,5))
#   
#   # for plotting model coefficients
#   lags = invnl(centers)-b
#   
#   library(pracma)
#   ihbas = orth(ihbasis) # orthogonal bases
#   
#   return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
# }
# 
# nBases = 10
# binSize = 0.01
# 
# bas = getBasis2(nBases,binSize)
# 
# str(bas)
# 
# 
# library(glmnet)
# library(doMC)
# 
# modelMatrix = readRDS("/global/work/harisf/session2/modelMatrix10ms/n1_b10ms.rds")
# 
# y = modelMatrix[,1]
# y[which(y > 1)] = 1
# x = modelMatrix[,-1]
# 
# fit = glmnet(x,y,family = "binomial",alpha = 1)
# 
# registerDoMC(cores = 10)
# fit.cv = cv.glmnet(x,y,family = "binomial",alpha = 1, nfolds = 10,parallel = TRUE)
# 
# saveRDS(fit,file = "/global/work/harisf/session2/lassoFit10ms/n1_b10ms_NOTcv.rds")
# saveRDS(fit.cv,file = "/global/work/harisf/session2/lassoFit10ms/n1_b10ms.rds")
# 
# 
# 
# fit = readRDS(file = "/Volumes/work/harisf/session2/lassoFit10ms/n1_b10ms_NOTcv.rds")
# fit.cv = readRDS(file = "/Volumes/work/harisf/session2/lassoFit10ms/n1_b10ms.rds")
# 
# plot(fit,xvar="lambda")
# log.lambda = -9
# fit.lambda.index = which.min(abs(fit$lambda-exp(log.lambda)))
# 
# sort(fit$beta[,fit.lambda.index], decreasing = T)
# #sort(abs(fit$beta[,fit.lambda.index]), decreasing = T)
# 
# log.lambda = -9
# fit.lambda.index = which.min(abs(fit$lambda-exp(log.lambda)))
# text(log.lambda,fit$beta["poly(lickOnset)2",fit.lambda.index]-0,"P2",cex = 0.8)
# text(log.lambda,fit$beta["poly(lickOnset)3",fit.lambda.index]+0,"P3",cex = 0.8)
# text(log.lambda,fit$beta["poly(lickOnset)1",fit.lambda.index]+0,"P1",cex = 0.8)
# text(log.lambda,fit$beta["poly(lickOnset)5",fit.lambda.index]+0,"P5",cex = 0.8)
# text(log.lambda,fit$beta["poly(lickOnset)4",fit.lambda.index]-0,"P4",cex = 0.8)
# #log.lambda = -7
# #fit.lambda.index = which.min(abs(fit$lambda-exp(log.lambda)))
# text(log.lambda,fit$beta["j1.k1",fit.lambda.index],"hist.l1",cex = 0.8)
# text(log.lambda,fit$beta["j1.k4",fit.lambda.index],"hist.l4",cex = 0.8)
# text(log.lambda,fit$beta["j16.k4",fit.lambda.index],"coup.16.l4",cex = 0.8)
# 
# 
# plot(fit.cv)
# 
# coef(fit.cv,s="lambda.min")


#fit = readRDS("/Volumes/harisf/master/data/variables/thesis/multisplit_s2n1.rds")




fit1ms = readRDS("/Volumes/work/harisf/session2/multisplit/n1_b1ms.rds")
fit10ms = readRDS("/Volumes/work/harisf/session2/multisplit10ms/n1_b10ms.rds")

fit1ms$pval.corr
which(fit1ms$pval.corr != 1)
which(fit1ms$pval.corr < 0.05)

fit10ms$pval.corr
which(fit10ms$pval.corr != 1)
which(fit10ms$pval.corr < 0.001)



library(glmnet)
lassofit1ms = readRDS("/Volumes/work/harisf/session2/lassoFit/n1_b1ms.rds")
lassofit10ms = readRDS("/Volumes/work/harisf/session2/lassoFit10ms/n1_b10ms.rds")

coef(lassofit1ms,s="lambda.min")
coef(lassofit10ms,s="lambda.min")


