# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

rm(list=setdiff(ls(), c("data")))

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}

getLickTrace = function(trials.good,getTime = FALSE){
  trials.good.lick_trace = is.element(data$obj[[11]][[3]][[1]][[1]][[6]],trials.good) # a logical vector indicating which trials in lick_trace/aom/laser_power are good trials
  lick_trace = data$obj[[11]][[3]][[1]][[1]][[7]][trials.good.lick_trace,1] # lick traces that correspond to good trials
  trial.lick_trace = data$obj[[11]][[3]][[1]][[1]][[6]][trials.good.lick_trace] # trial number for each element in lick trace
  if(getTime){
    time.lick_trace = data$obj[[11]][[3]][[1]][[1]][[5]][trials.good.lick_trace] # time stamp (in session time) for each element in lick_trace
    return(list(lickTrace = lick_trace,lickTrials = trial.lick_trace,lickTimes = time.lick_trace))
  }
  else
    return(list(lickTrace = lick_trace,lickTrials = trial.lick_trace))
}

# get spike times (and corresponding trials) for good trials
getSpikeTimes = function(neuron,trials.good){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTrials.good = is.element(eventTrials,trials.good)
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]][eventTrials.good]
  return(list(eventTimes = eventTimes,eventTrials=eventTrials[eventTrials.good]))
}

# get lick times (and corresponding trials). Must run getLickTrace first
getLickTimes = function(lickTraceObj){
  
  lickTrace = lickTraceObj$lickTrace
  lickTimes = lickTraceObj$lickTimes
  lickTrials = lickTraceObj$lickTrials
  
  lick_times = c()
  lick_trials = c()
  
  for(trial_j in unique(lickTrials)){
    
    lickTrace_j = lickTrace[which(lickTrials == trial_j)][-50000]
    lickTimes_j = lickTimes[which(lickTrials == trial_j)][-50000]
    lickTrials_j = lickTrials[which(lickTrials == trial_j)][-50000]
    
    thresh = 0.135
    traceOverThresh_index = which(lickTrace_j > thresh)
    
    DIFF = diff(traceOverThresh_index)
    onsetIndexes = c(traceOverThresh_index[1], traceOverThresh_index[which(DIFF > 100)+1])
    
    if(length(onsetIndexes) == 1){
      lickIndexes = onsetIndexes
    } else {
      lickIndexes = c()
      for(i in seq(1,length(onsetIndexes)-1)){
        lickCurve = lickTrace_j[onsetIndexes[i]:onsetIndexes[(i+1)]]
        lickIndexes = c(lickIndexes,which.max(lickCurve)+onsetIndexes[i])
      }
      # the last lickCurve
      lickCurve = lickTrace_j[onsetIndexes[i+1]:length(lickTrace_j)]
      lickIndexes = c(lickIndexes,which.max(lickCurve)+onsetIndexes[i+1])
    }
    
    # trim first and last elements if necessary
    if(length(lickIndexes) > 1 && !is.na(lickIndexes)){
      if(lickIndexes[length(lickIndexes)]==49999)
        lickIndexes = lickIndexes[-length(lickIndexes)]
      if(lickIndexes[1] < 10)
        lickIndexes = lickIndexes[-1]
    }
    
    lick_times = c(lick_times,lickTimes_j[lickIndexes])
    lick_trials = c(lick_trials,lickTrials_j[lickIndexes])
    
  }
  return(list(lickTimes = lick_times,lickTrials = lick_trials))
}

trials.good = getGoodTrials()
res = getLickTrace(trials.good,getTime = T)

res = getLickTimes(res)
lickTimes = res$lickTimes
lickTrials = res$lickTrials

# get trials where there was a correct RIGTH lick 
trials_correctR = which(data$obj[[8]][1,] == 1)
trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# get trials where there was a correct LEFT lick 
trials_correctL = which(data$obj[[8]][2,] == 1)
trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]


discretizeSpikeData = function(neuron,TRIALS,binSize=0.01){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  data_lick = NULL
  data_lick_j = matrix(0,ncol=3,nrow=length(timeInterval)-1)
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    data_lick_j[,1] = timeInterval[2:length(timeInterval)]
    data_lick_j[,2] =  as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    data_lick_j[,3] = rep(trial_j,length(timeInterval)-1)
    
    data_lick = rbind(data_lick,data_lick_j)
  }
  
  colnames(data_lick) = c("trialTime","spikeCount","trialId")
  dataFrame_lick = as.data.frame(data_lick)
  return(dataFrame_lick)
}
discretizeLickData = function(lickTimes,lickTrials,TRIALS,binSize=0.01){
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  data_lick = NULL
  data_lick_j = matrix(0,ncol=3,nrow=length(timeInterval)-1)
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    lickTimes_j = lickTimes[which(lickTrials == trial_j)] - trialStartTime_j
    
    data_lick_j[,1] = timeInterval[2:length(timeInterval)]
    data_lick_j[,2] =  as.vector(table(cut(lickTimes_j,breaks=timeInterval)))
    data_lick_j[,3] = rep(trial_j,length(timeInterval)-1)
    
    data_lick = rbind(data_lick,data_lick_j)
  }
  
  colnames(data_lick) = c("trialTime","lickCount","trialId")
  dataFrame_lick = as.data.frame(data_lick)
  return(dataFrame_lick)
}

licks_lickL = discretizeLickData(lickTimes,lickTrials,TRIALS = trials_correctL)
licks_lickR = discretizeLickData(lickTimes,lickTrials,TRIALS = trials_correctR)

# aggregate lickCounts over trialIds
licks_lickL_sum = data.frame(trialTime = unique(licks_lickL$trialTime),lickCount = aggregate(licks_lickL$lickCount,by=list(licks_lickL$trialTime),FUN = sum)$x)
licks_lickR_sum = data.frame(trialTime = unique(licks_lickR$trialTime),lickCount = aggregate(licks_lickR$lickCount,by=list(licks_lickR$trialTime),FUN = sum)$x)


neuron = 12
spikes_lickL = discretizeSpikeData(neuron,TRIALS = trials_correctL)
spikes_lickR = discretizeSpikeData(neuron,TRIALS = trials_correctR)

# aggregate spikeCounts over trialIds
spikes_lickL_sum = data.frame(trialTime = unique(spikes_lickL$trialTime),spikeCount = aggregate(spikes_lickL$spikeCount,by=list(spikes_lickL$trialTime),FUN = sum)$x)
spikes_lickR_sum = data.frame(trialTime = unique(spikes_lickR$trialTime),spikeCount = aggregate(spikes_lickR$spikeCount,by=list(spikes_lickR$trialTime),FUN = sum)$x)

countsL = data.frame(trialTime = unique(spikes_lickL_sum$trialTime),
                     spikeCount = spikes_lickL_sum$spikeCount,
                     lickCount = licks_lickL_sum$lickCount)
countsR = data.frame(trialTime = unique(spikes_lickR_sum$trialTime),
                     spikeCount = spikes_lickR_sum$spikeCount,
                     lickCount = licks_lickR_sum$lickCount)

counts = data.frame(trialTime = countsR$trialTime,
                    spikeCount = countsR$spikeCount+countsL$spikeCount,
                    lickCount = countsR$lickCount+countsL$lickCount)
#par(mfrow=c(1,1))
plot(counts$lickCount,counts$spikeCount)
plot(gam(spikeCount~s(lickCount),data = counts[-500,],family = "poisson"),
     se=T)

which.max(counts$lickCount)



# FIT AND PLOT GAMS
#library(gam)
gam_L = gam(spikeCount~s(lickCount),data = countsL,family = "poisson")
gam_R = gam(spikeCount~s(lickCount),data = countsR,family = "poisson")

#pdf(file="/Volumes/harisf/master/figures/tuningCurves/gamSpline_neuron16_lickCount.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(1,2))
plot(gam_L,se=T,main=paste("neuron",neuron,"lick L"))
plot(gam_R,se=T,main=paste("neuron",neuron,"lick R"))
#dev.off()














# TO PLOT LICK TRACES
randomSamples = sample(trials.good,4)
#pdf(file=paste("/Volumes/harisf/master/figures/lickTraces/trials_",randomSamples[1],"_",randomSamples[2],"_",randomSamples[3],"_",randomSamples[4],".pdf",sep=""),
#    width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(2,2))
for(trial_j in randomSamples){

#trial_j = 93

lickTrace_j = res$lickTrace[which(res$lickTrials == trial_j)][-50000]
lickTimes_j = res$lickTimes[which(res$lickTrials == trial_j)][-50000]
lickTrials_j = res$lickTrials[which(res$lickTrials == trial_j)][-50000]
#plot(lickTimes_j,lickTrace_j,type="l")

thresh = 0.135
traceOverThresh_index = which(lickTrace_j > thresh)
#points(lickTimes_j[traceOverThresh_index],lickTrace_j[traceOverThresh_index],col="red")

DIFF = diff(traceOverThresh_index)
#points(lickTimes_j[traceOverThresh_index[which(DIFF > 100)+1]],lickTrace_j[traceOverThresh_index[which(DIFF > 100)+1]],col="red")
onsetIndexes = c(traceOverThresh_index[1], traceOverThresh_index[which(DIFF > 100)+1])

#onsetIndexes = traceOverThresh_index[which(DIFF > 100)]

if(length(onsetIndexes) == 1){
  lickIndexes = onsetIndexes
} else {
  lickIndexes = c()
  for(i in seq(1,length(onsetIndexes)-1)){
    lickCurve = lickTrace_j[onsetIndexes[i]:onsetIndexes[(i+1)]]
    lickIndexes = c(lickIndexes,which.max(lickCurve)+onsetIndexes[i])
  }
  # the last lickCurve
  lickCurve = lickTrace_j[onsetIndexes[i+1]:length(lickTrace_j)]
  lickIndexes = c(lickIndexes,which.max(lickCurve)+onsetIndexes[i+1])
}

if(length(lickIndexes) > 1 && !is.na(lickIndexes)){
  if(lickIndexes[length(lickIndexes)]==49999)
    lickIndexes = lickIndexes[-length(lickIndexes)]
  if(lickIndexes[1] < 10)
    lickIndexes = lickIndexes[-1]
}

plot(lickTimes_j,lickTrace_j,type="l",main=paste("Trial",trial_j),
     xlab="session time (s)",ylab="lick trace")
#points(lickTimes_j[onsetIndexes],lickTrace_j[onsetIndexes],col="blue")
if(length(lickIndexes) > 1 && !is.na(lickIndexes))
  points(lickTimes_j[lickIndexes],lickTrace_j[lickIndexes],col="red")
}
#dev.off()


# TO PLOT LICK COUNTS AND SPIKE COUNTS
startOfSampleEpoch_L = mean(c(data$obj[[9]][[3]][[1]][[1]][trials_correctL]),na.rm=TRUE)
startOfDelayEpoch_L = mean(c(data$obj[[9]][[3]][[2]][[1]][trials_correctL]),na.rm=TRUE)
startOfResponseEpoch_L = mean(c(data$obj[[9]][[3]][[3]][[1]][trials_correctL]),na.rm=TRUE) # aka lickOnset
startOfSampleEpoch_R = mean(c(data$obj[[9]][[3]][[1]][[1]][trials_correctR]),na.rm=TRUE)
startOfDelayEpoch_R = mean(c(data$obj[[9]][[3]][[2]][[1]][trials_correctR]),na.rm=TRUE)
startOfResponseEpoch_R = mean(c(data$obj[[9]][[3]][[3]][[1]][trials_correctR]),na.rm=TRUE) # aka lickOnset

#pdf(file="/Volumes/harisf/master/figures/lickCounts/trialTimeCount.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=(c(1,2)))
plot(licks_lickL_sum,main="lick L",ylab="lick count",xlab="trial time (s)")
abline(v=startOfSampleEpoch_L,lty=2)
abline(v=startOfDelayEpoch_L,lty=2)
abline(v=startOfResponseEpoch_L,lty=2)
plot(licks_lickR_sum,main="lick R",ylab="lick count",xlab="trial time (s)")
abline(v=startOfSampleEpoch_R,lty=2)
abline(v=startOfDelayEpoch_R,lty=2)
abline(v=startOfResponseEpoch_R,lty=2)
#dev.off()

#pdf(file="/Volumes/harisf/master/figures/spikesAndLicks/trialTimeCount_neuron1.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(2,2))
plot(spikes_lickL_sum,main="neuron 1 lick L",ylab="spike count",xlab="trial time (s)")
abline(v=startOfSampleEpoch_L,lty=2)
abline(v=startOfDelayEpoch_L,lty=2)
abline(v=startOfResponseEpoch_L,lty=2)
plot(spikes_lickR_sum,main="neuron 1 lick R",ylab="spike count",xlab="trial time (s)")
abline(v=startOfSampleEpoch_R,lty=2)
abline(v=startOfDelayEpoch_R,lty=2)
abline(v=startOfResponseEpoch_R,lty=2)
plot(licks_lickL_sum,main="lick L",ylab="lick count",xlab="trial time (s)")
abline(v=startOfSampleEpoch_L,lty=2)
abline(v=startOfDelayEpoch_L,lty=2)
abline(v=startOfResponseEpoch_L,lty=2)
plot(licks_lickR_sum,main="lick R",ylab="lick count",xlab="trial time (s)")
abline(v=startOfSampleEpoch_R,lty=2)
abline(v=startOfDelayEpoch_R,lty=2)
abline(v=startOfResponseEpoch_R,lty=2)
#dev.off()

#pdf(file="/Volumes/harisf/master/figures/lickCounts/counts_neuron12.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(1,2))
plot(licks_lickL_sum$lickCount,spikes_lickL_sum$spikeCount,
     main="neuron 12 lick L",xlab="lick count",ylab="spike count")
plot(licks_lickR_sum$lickCount,spikes_lickR_sum$spikeCount,
     main="neuron 12 lick R",xlab="lick count",ylab="spike count")
#dev.off()





