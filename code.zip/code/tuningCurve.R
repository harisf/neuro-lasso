# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
trials_correctR = which(data$obj[[8]][1,] == 1)
trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# get trials where there was a correct LEFT lick 
trials_correctL = which(data$obj[[8]][2,] == 1)
trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]

# plot tuning curves
plotTuningCurve = function(neuron){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  
  getFiringRate = function(TRIALS){
    binSize = 0.1
    timeInterval = seq(0,5.4,binSize)
    spikeCount = vector(mode="numeric",length=length(timeInterval)-1)
    
    for(trial_j in TRIALS){
      trialStartTime_j = data$obj[[7]][1,trial_j]
      eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
      
      spikeCount = spikeCount + as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    }
    firingRate = spikeCount/(binSize*length(spikeCount))
  }
  
  firingRate_R = getFiringRate(trials_correctR)
  firingRate_L = getFiringRate(trials_correctL)
  
  binSize = 0.1
  timeInterval = seq(0,5.4,binSize)
  plot(timeInterval[-length(timeInterval)],firingRate_R,type="l",col="blue",main=paste("Neuron",neuron,sep = " "),
       xlab = "Trial time (s)", ylab = "Firing Rate (Hz)",
       ylim = c(min(firingRate_R,firingRate_L),max(firingRate_R,firingRate_L)))
  lines(timeInterval[-length(timeInterval)],firingRate_L,col="red")
  
  startOfSampleEpoch = mean(data$obj[[9]][[3]][[1]][[1]][trials_correctL],na.rm=TRUE)
  startOfDelayEpoch = mean(data$obj[[9]][[3]][[2]][[1]][trials_correctL],na.rm=TRUE)
  startOfResponseEpoch = mean(data$obj[[9]][[3]][[3]][[1]][trials_correctL],na.rm=TRUE)
  abline(v=startOfSampleEpoch,lty=2)
  abline(v=startOfDelayEpoch,lty=2)
  abline(v=startOfResponseEpoch,lty=2)
  legend("topright", c("Lick R", "Lick L"), lty=c(1,1),col=c("blue","red"))
}

plotTuningCurve(12)
plotTuningCurve(16)
plotTuningCurve(19)
plotTuningCurve(20)



