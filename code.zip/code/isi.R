# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

rm(list=setdiff(ls(), c("data")))

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()



#neurons = sample(seq(1,30),9)
#pdf(file="/Volumes/harisf/master/figures/history/isi_density.pdf",width=dev.size()[1],height=dev.size()[2])
#par(mfrow=c(3,3))
#for(neuron in neurons){

neuron = 1

eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
#lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)

#timeInterval = seq(0,5.4,binSize)
#timeInterval = seq(0,5,binSize)

#mat = NULL
#mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)


isi = c()
for(trial_j in trials.good){
  #trialStartTime_j = data$obj[[7]][1,trial_j]
  #eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
  
  eventTimes_j = eventTimes[which(eventTrials == trial_j)]
  isi = c(isi,diff(eventTimes_j))
}

seconds = 0.6
nBins = 100 # bins pr seconds.
# That is, each bar in the hist represents the number of eventTimes in a time bin of size 1/nBins
hist(isi[isi<seconds],xlab="isi (s)",breaks = seconds*nBins,
     main=paste("neuron",neuron),freq = F)

#}
#dev.off()

plot(isi)
  



