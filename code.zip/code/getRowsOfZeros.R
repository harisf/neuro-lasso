getBasis2 = function(nBases,binSize){
  #b = binSize*5
  #peaks = c(binSize,binSize*50)
  b = binSize*nBases
  peaks = c(binSize,binSize*10*nBases)

  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}

  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)

  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }

  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))

  # for plotting model coefficients
  lags = invnl(centers)-b

  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases

  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}

setwd("/Volumes/harisf/master/data/variables/modelMatrix")
modelMatrix1ms = readRDS("n1_b1ms.rds")
modelMatrix10ms = readRDS("n1_b10ms.rds")

bas1ms = getBasis2(nBases = 10, binSize = 0.001)
str(bas1ms$bas)
my_bas = bas1ms$bas[1:10,]

bas10ms = getBasis2(nBases = 10, binSize = 0.01)

bas_new = getBasis2(5,0.001)
str(bas_new$bas)

str(bas1ms$bas)
str(bas10ms$bas)

plot(seq(0.001,bas1ms$tau_N,0.001),bas1ms$bas[,2])

#plot(bas$bas[,1],type="l")
matplot(seq(0.01,bas_new$tau_N,0.01),bas_new$bas,type="b",col=1,lty=1, pch = 1,
        ylab="",xlab="lag (s)")


str(bas10ms$bas)
str(bas1ms$bas)
str(bas100ms$bas)

setwd("/Volumes/harisf/master/data/variables")
modelMatrix = readRDS("n1_b1ms.rds")

test_model1msbas1ms = convolve(c(0,modelMatrix1ms[,1]),rev(bas1ms$bas_orth[,1]),type="open")[2:dim(modelMatrix1ms)[1]]
str(test_model1msbas1ms)

plot(test_model10msbas1ms,type="l")
rug(modelMatrix10ms[,1]*seq(1,dim(modelMatrix10ms)[1]))

plot(1,type="n",xlim=c(1,dim(modelMatrix10ms)[1]),ylim=c(0,1))
rug(modelMatrix10ms[,1]*seq(1,dim(modelMatrix10ms)[1]))#,ticksize = 0.03, side = 1, lwd = 0.5)

test_model10msbas10ms = test10ms
test_model10msbas1ms = test1ms


a = seq(1,5)
b = seq(3,5)

a = c(1,0,-1)
b = seq(0,2)
convolve(a,rev(b),type="open")






plot((modelMatrix1ms[,"j1.k1"]),type="l")


# 
# setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
# #setwd("/Volumes/harisf/master/data/variables/modelMatrix")
# #lassoData = readRDS("lassoData.rds")
# modelMatrix = readRDS("n1_b1ms.rds")
# 
# 
# library(foreach)
# library(doParallel)
# 
# registerDoParallel(cores = 10)
# #nrows = dim(modelMatrix)[1]
# #ncols = dim(modelMatrix)[2]
# nrows = 1564999
# ncols = 132
# rowsOfZeros = foreach(i = 2001:3000,.combine = c) %dopar% { 
#   length(which(modelMatrix[i,] == 0)) == ncols
#   #cat("Row where all observations are zero: ", i,sep="") 
# }
# stopImplicitCluster()
# which(rowsOfZeros == T)
# 
# setwd("/home/shomea/h/harisf/master/data/variables")
# saveRDS(rowsOfZeros,"rowsOfZeros.rds")


