library(Matrix)
library(parallel)
library(hdi)
library(glmnet)

lasso.cv.lambda.min = function (x, y, nfolds = 10, grouped = nrow(x) > 3 * nfolds, 
                                ...){
  suppressMessages(library(doMC))
  registerDoMC(cores=10)
  fit.cv <- cv.glmnet(x, y, nfolds = nfolds, grouped = grouped, parallel = TRUE,
                      ...)
  sel <- predict(fit.cv, type = "nonzero", s = "lambda.min")
  sel[[1]]
}

glm.pval.x.as.matrix = function (x, y, family = "binomial", verbose = FALSE, ...){
  fit.glm <- glm(y ~ as.matrix(x), family = family, ...)
  fit.summary <- summary(fit.glm)
  if (!fit.glm$converged & verbose) {
    #print(fit.summary)
  }
  pval.sel <- coef(fit.summary)[-1, 4]
  names(pval.sel) <- colnames(x)
  pval.sel
}

# for all 16 neurons in session 2
# for all 12 neurons in session 3
#for(neuron in seq(1,12)){
for(neuron in seq(8,8)){
  setwd("/global/work/harisf/session3/modelMatrix10ms")
  fileName = paste("n",neuron,"_b10ms.rds",sep="")
  
  modelMatrix = readRDS(fileName)
  
  y = modelMatrix[,1]
  y[which(y > 1)] = 1
  x = modelMatrix[,-1]
  
  startTime = Sys.time()
  fit <- multi.split(x,y, ci = FALSE, B = 50,
                     classical.fit = glm.pval.x.as.matrix,
                     model.selector = lasso.cv.lambda.min, args.model.selector = list(family = "binomial"),
                     #parallel = TRUE, ncores = 10,
                     return.selmodels = FALSE, verbose = FALSE)
  
  endTime = Sys.time() - startTime
  
  setwd("/global/work/harisf/session3/multisplit10ms")
  saveRDS(fit,fileName)
  
  cat("Multisplit done for neuron ",neuron,". Time used: ",endTime," ",attr(endTime,"units"),". \n",sep="")
}









