b = 0.1;
t = linspace(0,1,1000);
nlin  = inline('log(x+eps)');
nt = nlin(t + b);
nBases = 5;
cSt = nt(1);
cEnd = nt(end);
db = (cEnd - cSt) / (nBases-1)
c = cSt:db:cEnd;

bas = nan(nBases,length(t));
for k = 1:nBases
  bas(k,:) = ( cos( ...
    max(-pi, min(pi,(nt - c(k))*pi/(db) )) ) ...
    + 1) / 2;
end
