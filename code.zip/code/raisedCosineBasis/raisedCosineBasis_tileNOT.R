
Tau = 0.075
#Tau = 1
t = seq(0,Tau,Tau/1000)
b = Tau/10

nBases = 4
cStart = log(0+b)
#cEnd = log(t[length(t)-250]+b) # works for 10
cEnd = log(t[length(t)-500]+b) # works for 4
#cEnd = log(t[length(t)-740]+b) # works for 5
#cEnd = log(t[length(t)]+b)
db = (cEnd - cStart)/(nBases-1)
#c = seq(cStart-2*db,cEnd+2*db,db)
c = seq(cStart,cEnd,db)

bas = matrix(NA,ncol=length(t),nrow = nBases)
for(j in seq(1,nBases)){
  for(i in seq(1,length(t))){
    x = max(-pi, min(pi,pi*(log(t[i]+b)-c[j])*0.5/db)) # multipying with 0.5 ensures overlapping
    bas[j,i] = (cos(x) + 1)/2
  }
}

plot(NULL,xlim=c(0,Tau*1000),ylim=c(0,1),xlab="t (ms)",ylab="")
for(j in seq(1,nBases)){
  lines(t*1000,bas[j,],type="l",col=j)
  #lines(t[which(bas[i,] > 0)],bas[i,which(bas[i,] > 0)],type="l",col=i)
}

#plot(t,colSums(bas)

