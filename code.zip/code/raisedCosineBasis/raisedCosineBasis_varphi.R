
nBases = 10

tau_N = 0.12
#tau_N = 1
t = seq(0,tau_N,tau_N/1000)
#t = seq(0,tau_N,0.01)
a = 1
if(nBases == 4){
  b = tau_N/8 # works for nBases = 4
}
if(nBases == 10){
  b = tau_N/150 # works for nBases = 10
}

varphiStart = log(b)*pi
varphi = seq(varphiStart,varphiStart+(nBases-1)*pi/2,pi/2)
#varphi = seq(varphiStart,varphiStart+(nBases-1)*pi,pi) # for tiling

bas = matrix(NA,ncol=length(t),nrow = nBases)
for(j in seq(1,nBases)){
  for(i in seq(1,length(t))){
    x = max(-pi, min(pi,pi*a*log(t[i]+b)-varphi[j]))
    bas[j,i] = (cos(x) + 1)/2
  }
}

#pdf(file="/Volumes/harisf/master/figures/basises/evaluated.pdf",width=dev.size()[1],height=dev.size()[2])
#par(mfrow=c(1,1))
plot(NULL,xlim=c(0,tau_N),ylim=c(0,1),xlab="t (ms)",ylab="")
#cl = rainbow(nBases,start=2/6)
for(j in seq(1,nBases)){
  lines(t,bas[j,],type="l",col=j)
  #lines(t,bas[j,],type="l",col=cl[j])
  #lines(t[which(bas[i,] > 0)],bas[i,which(bas[i,] > 0)],type="l",col=i)
}
#matplot(t(bas),type = "l",lty=1,xlab="t",ylab="")

#plot(t,colSums(bas))


binSize = 0.01
t_new = seq(0,tau_N,binSize)

indexes = list()
indexes[[1]] = which(t <= t_new[2])
for(k in seq(2,length(t_new)-1)){
  indexes[[k]] = intersect(which(t <= t_new[k+1]),which(t > t_new[k]))
}

#median(bas[10,indexes[[10]]])

#plot(bas[1,])
#plot(bas[1,indexes[[1]]])

#par(mfrow=c(2,1))
bas_new = matrix(NA,ncol = length(t_new),nrow = nBases)
for(j in seq(1,nBases)){
  for(k in seq(1,length(indexes))){
    #bas_new[j,k] = median(bas[j,indexes[[k]]])
    bas_new[j,k] = mean(bas[j,indexes[[k]]])
  }
}

matplot(t(bas_new),type="b",pch=seq(1,5))


#par(mfrow=c(1,1))
plot(bas[5,indexes[[2]]])
mean(bas[1,indexes[[2]]])



bas_new = matrix(NA,ncol = length(t_new),nrow = nBases)
for(j in seq(1,nBases)){
  bas_new[j,] = c(bas[j,1],bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)+1])
}

plot(NULL,xlim=c(0,tau_N),ylim=c(0,1),xlab="t (ms)",ylab="")
for(j in seq(1,nBases)){
  points(t_new,bas_new[j,],col=j)
  #lines(t[which(bas[i,] > 0)],bas[i,which(bas[i,] > 0)],type="l",col=i)
}


#log time
t_new_log = log(t_new + b)
bas_new_log = matrix(NA,ncol = length(t_new_log),nrow = nBases)
for(j in seq(1,nBases)){
  bas_new_log[j,] = c(bas[j,1],bas[j,which(as.vector(table(cut(t_new_log,breaks=t))) == 1)+1])
}

plot(NULL,xlim=c(0,tau_N),ylim=c(0,1),xlab="t (ms)",ylab="")
for(j in seq(1,nBases)){
  points(t_new_log,bas_new_log[j,],col=j)
  #lines(t[which(bas[i,] > 0)],bas[i,which(bas[i,] > 0)],type="l",col=i)
}

matplot(t(bas_new_log))


#dev.off()






