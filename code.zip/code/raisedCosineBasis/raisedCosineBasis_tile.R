
nBases = 10
#Tau = 1 #s
Tau = 0.12#s

a = 1
#b = Tau / 8  # nBases = 4
b = Tau / 150 # nBases = 10
t = seq(0,Tau,Tau/1000)
nt = log(t+b)

#nBases = 10
#cStart = t[1]+binSize
#cEnd = t[length(t)]
cStart = nt[1] # to use log time
cEnd = nt[length(nt)]
db = (cEnd - cStart) / (nBases-1)
c = seq(cStart,cEnd,db)
#str(c)

#varphi = seq(t[1],(nBases-1)*pi/2,pi/2)
#varphi = seq(nt[1]*pi,(nBases-1)*pi/2,pi/2)

bas = matrix(NA,nrow = nBases,ncol = length(t))
for(i in seq(1,nBases)){
  for(j in seq(1,length(t))){
    #x = (t[j]-c[i])*pi/db
    x = (nt[j]-c[i])*pi/db
    bas[i,j] = (cos(max(-pi, min(pi,x))) + 1) / 2
  }
}

lags = c()
for(i in seq(1,nBases))
  lags = c(lags,t[which.max(bas[i,])])
  #lags = c(lags,t[which.max(bas[i,2:length(t)])+1])


t_new = seq(0,tau_N,binSize)
bas_new = matrix(NA,ncol = length(t_new),nrow = nBases)
for(j in seq(1,nBases)){
  bas_new[j,] = c(bas[j,1],bas[j,which(as.vector(table(cut(log(t_new),breaks=log(t)))) == 1)+1])
  #bas_new[j,] = c(NA,bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)+1])
}
#lags = t[which(as.vector(table(cut(t_new,breaks=t))) == 1)+1]
#colSums(bas_new[-1,])

#pdf(file="/Volumes/harisf/master/figures/bases/evaluated_tile2.pdf",width=dev.size()[1],height=dev.size()[2])
#par(mfrow=c(3,1))
par(mfrow=c(2,1))
plot(NULL,xlim=c(0,Tau),ylim=c(0,1),xlab="t",ylab="")
for(i in seq(1,nBases)){
  lines(t,bas[i,],type="l",col=i)
  #lines(t[which(bas[i,] > 0)],bas[i,which(bas[i,] > 0)],type="l",col=i)
}

plot(NULL,xlim=c(0,Tau),ylim=c(0,1),xlab="t",ylab="")#,main="bin size 10 ms")
for(i in seq(1,nBases)){
  lines(t_new,bas_new[i,],type="b",col=i,pch=i)
  #lines(t[which(bas[i,] > 0)],bas[i,which(bas[i,] > 0)],type="l",col=i)
}
# 
# t_new = seq(0,tau_N,binSize/10)
# bas_new = matrix(NA,ncol = length(t_new),nrow = nBases)
# for(j in seq(1,nBases)){
#   bas_new[j,] = c(bas[j,1],bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)+1])
#   #bas_new[j,] = c(NA,bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)+1])
# }
# plot(NULL,xlim=c(0,Tau),ylim=c(0,1),xlab="t",ylab="",main="bin size 1 ms")
# for(i in seq(1,nBases)){
#   lines(t_new,bas_new[i,],type="b",col=i,pch=i)
#   #lines(t[which(bas[i,] > 0)],bas[i,which(bas[i,] > 0)],type="l",col=i)
# }
#dev.off()

#colSums(bas)

#plot(bas[1,],type="l")
