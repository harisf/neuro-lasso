getBasis2 = function(nBases,binSize){
  #b = binSize*5
  #peaks = c(binSize,binSize*50)
  b = binSize*nBases
  peaks = c(binSize,binSize*10*nBases)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}

binSize_old = 0.001
binSize_new = 0.01

bas_old = getBasis2(10,binSize = binSize_old)

pointsToCombine = binSize_new / binSize_old
totalCombinedPoints = floor(dim(bas$bas)[1] / pointsToCombine)

indexes = list()
for(i in seq(0,totalCombinedPoints - 1))
  indexes = c(indexes,list(seq(1,pointsToCombine) + pointsToCombine * i))

# numberOfRemainingPoints = dim(bas$bas)[1] %% pointsToCombine
# THESE LAST POINTS ARE DISCARDED
# if(numberOfRemainingPoints != 0)
#   indexes = c(indexes,list(seq(1,numberOfRemainingPoints) + indexes[[totalCombinedPoints]][pointsToCombine]))

str(indexes)

bas_new = list(bas = matrix(NA,ncol = dim(bas_old$bas)[2],nrow = length(indexes)), 
               bas_orth = matrix(NA,ncol = dim(bas_old$bas)[2],nrow = length(indexes)),
               tau_N = bas_old$tau_N)
for(i in seq(1,length(indexes))){
  bas_new$bas[i,] = bas_old$bas[floor(median(indexes[[i]])),]
  bas_new$bas_orth[i,] = bas_old$bas_orth[floor(median(indexes[[i]])),]
}

par(mfrow=c(2,1))
matplot(seq(binSize_old,bas_old$tau_N,binSize_old),bas_old$bas,type = "b",lty=1,pch=1,col=1,
     xlab = "lag (s)",ylab="",main="Original bases")
matplot(seq(binSize_new,bas_new$tau_N,binSize_new),bas_new$bas,type = "b",lty=1,pch=1,col=1,
     xlab = "lag (s)",ylab="",main="Median point bases")
