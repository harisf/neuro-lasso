binSize = 0.01

#input to makeBasis_PostSpike
nBases = 5
b = binSize*5
peaks = c(binSize,binSize*50)
absref = NULL

# check input values
try(if((peaks[1]+b) < 0)
  stop("b + first peak location: must be greater than 0"))

# nonlinearity for stretching x axis (and its inverse)
nlin = function(x){log(x+1e-20)}
invnl = function(x){exp(x)-1e-20}

# Generate basis of raised cosines
yrange = nlin(peaks+b)
db = diff(yrange)/(nBases-1)
centers = seq(yrange[1],yrange[2],db)
maxt = invnl(yrange[2]+2*db)-b
maxt
iht = seq(binSize,maxt,binSize)
nt = length(iht)

raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
}

ihbasis = matrix(NA,nrow = nt,ncol = nBases)
for(i in seq(1,nt)){
  for(j in seq(1,length(centers))){
    ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
  }
}
#matplot(ihbasis,type="b",pch=seq(1,5))

lags = invnl(centers)-b


plot(NULL,xlim=c(0,maxt),ylim=c(0,1),xlab="t (s)",ylab="")#,main="bin size 10 ms")
for(j in seq(1,nBases)){
  lines(iht,ihbasis[,j],type="b",col=j,pch=j)
}

# str(iht)
# str(ihbasis)



# install.packages("pracma")
# library(pracma)
ihbas = orth(ihbasis)

par(mfrow=c(1,2))
matplot(ihbasis,type="l",col=seq(1,5),lty=1)
matplot(ihbas,type="l",col=seq(1,5),lty=1)

