# library(SGL)
# library(Matrix)
# 
# setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
# #setwd("/Volumes/harisf/master/data/variables/modelMatrix")
# modelMatrix = readRDS("n1_b1ms.rds")
# 
# p_connect = 4*29
# index = c(rep(1,10), ceiling(1:p_connect / 4) + 1, rep(ceiling(p_connect /4) + 2,5))
# 
# data = list(x = as.matrix(modelMatrix[,-1]), y = as.matrix(modelMatrix[,1]))
# 
# system.time(fit <- cvSGL(data, index, type = "logit", alpha = 1))
# 
# setwd("/home/shomea/h/harisf/master/data/variables/modelFit")
# saveRDS(fit,"fitcvSGL_n1_b1ms.rds")
# 
# 

library(Matrix)
library(doParallel)
library(logitsgl)

setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
modelMatrix = readRDS("n1_b1ms.rds")

x = as.matrix(modelMatrix[,-1])
y = as.matrix(modelMatrix[,1])

p_connect = 4*29
index = c(rep(1,10), ceiling(1:p_connect / 4) + 1, rep(ceiling(p_connect /4) + 2,5))


cl <- makeCluster(10)
registerDoParallel(cl)

start = Sys.time()
fit = cv(x,y,grouping = index,alpha = 0, # this alpha value gives the group lasso (alpha = 1 gives the lasso)
         lambda=0.05, # this lambda value is the same as min.frac in SGL::cvSGL
         use_parallel = TRUE)
Sys.time() - start

stopCluster(cl)

# print fit
fit

# save fit
setwd("/home/shomea/h/harisf/master/data/variables/modelFit")
saveRDS(fit,"logitsgl_n1_b1ms.rds")
