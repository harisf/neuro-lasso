# # sparse group lasso example
# library(SGL)
# set.seed(1)
# n = 50; p = 100; size.groups = 10
# index <- ceiling(1:p / size.groups)
# X = matrix(rnorm(n * p), ncol = p, nrow = n)
# beta = (-2:2)
# y = X[,1:5] %*% beta + 0.1*rnorm(n)
# data = list(x = X, y = y)
# cvFit = cvSGL(data, index, type = "linear")
# plot(cvFit)


library(SGL)
library(Matrix)

setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
#setwd("/Volumes/harisf/master/data/variables/modelMatrix")
modelMatrix = readRDS("n1_b1ms.rds")

p_connect = 4*29
index = c(rep(1,10), ceiling(1:p_connect / 4) + 1, rep(ceiling(p_connect /4) + 2,5))

data = list(x = as.matrix(modelMatrix[,-1]), y = as.matrix(modelMatrix[,1]))

system.time(fit <- cvSGL(data, index, type = "logit", alpha = 0.95))

setwd("/home/shomea/h/harisf/master/data/variables/modelFit")
saveRDS(fit,"fitcvSGL_n1_b1ms.rds")


# install.packages("devtools")
# devtools::install_github("vincent-dk/sglOptim")
# devtools::install_github("vincent-dk/logitsgl")



# setwd("/Volumes/harisf/master/data/variables/hdi")
# multisplitRES_1ms = readRDS("fitMultisplit_n1_b1msML1.rds")
# multisplitRES_10ms = readRDS("fitMultisplit_n1_b10ms_medianBases.rds")
# 
# which(multisplitRES_1ms$pval.corr < 0.05)
# which(multisplitRES_10ms$pval.corr < 0.05)
# 
# multisplitRES_1ms$pval.corr[which(multisplitRES_1ms$pval.corr < 0.05)]
# multisplitRES_10ms$pval.corr[which(multisplitRES_10ms$pval.corr < 0.05)]
