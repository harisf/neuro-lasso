library(Matrix)
#library(doParallel)
#library(doMC)
library(parallel)
library(hdi)
library(glmnet)

lasso.cv.lambda.min = function (x, y, nfolds = 10, grouped = nrow(x) > 3 * nfolds, 
                                ...){
  suppressMessages(library(doMC))
  registerDoMC(cores=10)
  #library(doParallel)
  #registerDoParallel(cores = 10)
  fit.cv <- cv.glmnet(x, y, nfolds = nfolds, grouped = grouped, parallel = TRUE,
                      ...)
  #cat("   cross-validation completed... ",sep="")
  sel <- predict(fit.cv, type = "nonzero", s = "lambda.min")
  sel[[1]]
}

glm.pval.x.as.matrix = function (x, y, family = "binomial", verbose = FALSE, ...){
  fit.glm <- glm(y ~ as.matrix(x), family = family, ...)
  #cat("and glm fitted.")
  fit.summary <- summary(fit.glm)
  if (!fit.glm$converged & verbose) {
    #print(fit.summary)
    #cat(" glm.fit: algorithm did not converge.\n")
  }
  #cat("\n")
  pval.sel <- coef(fit.summary)[-1, 4]
  names(pval.sel) <- colnames(x)
  pval.sel
}

#for(neuron in c(14,15,29,30)){
for(neuron in c(16,16)){
  setwd("/global/work/harisf/session2/modelMatrix10ms_rightTrials")
  fileName = paste("n",neuron,"_b10ms.rds",sep="")
  
  modelMatrix = readRDS(fileName)
  
  y = modelMatrix[,1]
  y[which(y > 1)] = 1
  
  x = modelMatrix[,-1]
  
  startTime = Sys.time()
  fit <- multi.split(x,y, ci = FALSE, B = 50,
                     classical.fit = glm.pval.x.as.matrix, #args.classical.fit = list(verbose = TRUE),
                     model.selector = lasso.cv.lambda.min, args.model.selector = list(family = "binomial"),
                     parallel = TRUE, ncores = 10,
                     return.selmodels = FALSE, verbose = FALSE)
  
  endTime = Sys.time() - startTime
  
  setwd("/global/work/harisf/session2/multisplit10ms_rightTrials")
  saveRDS(fit,fileName)
  
  cat("Multisplit done for neuron ",neuron,". Time used: ",endTime," ",attr(endTime,"units"),". \n",sep="")
}










