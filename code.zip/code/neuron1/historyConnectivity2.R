# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

rm(list=setdiff(ls(), c("data")))

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
# trials_correctR = which(data$obj[[8]][1,] == 1)
# trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# # get trials where there was a correct LEFT lick 
# trials_correctL = which(data$obj[[8]][2,] == 1)
# trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]


discretizeSpikeData = function(neuron,TRIALS,binSize=0.01,tau_N=NA){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  if(!is.na(tau_N)){
    M = floor(tau_N / binSize) # number of bins we go back
    mat_j = cbind(mat_j,matrix(NA,nrow=dim(mat_j)[1],ncol=M))
  }
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]-lickOnset
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    if(!is.na(tau_N)){
      for(m in seq(1,M)){
        mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
        #mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
      }
    }
    
    mat = rbind(mat,mat_j)
  }
  
  if(!is.na(tau_N)){
    cnames = c()
    for(m in seq(1,M)){
      cnames = c(cnames,paste("spikeCountj",neuron,"m",m,sep = ""))
    }
    colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""),cnames)
  } else
    colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""))
  df = as.data.frame(mat)
  return(df)
}

discretizeAndAlignSpikeData = function(mainNeuron,TRIALS,binSize=0.01){
  spikeData_mainNeuron = discretizeSpikeData(mainNeuron,TRIALS,binSize)
  
  otherNeurons = setdiff(seq(1,30),mainNeuron)
  spikeData_otherNeurons = matrix(NA,nrow=dim(spikeData_mainNeuron)[1],ncol=29)
  
  colnamesTxt = NULL
  timeInterval = seq(0,5,binSize)
  for(i in seq(1,29)){
    neuron = otherNeurons[i]
    eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
    eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
    
    for(trial_j in unique(spikeData_mainNeuron$trialId)){
      trialStartTime_j = data$obj[[7]][1,trial_j]
      eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
      
      spikeData_otherNeurons[which(spikeData_mainNeuron$trialId == trial_j),i] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
      
    }
    colnamesTxt = c(colnamesTxt,paste("spikeCountj",neuron,sep = ""))
  }
  colnames(spikeData_otherNeurons) = colnamesTxt
  
  return(as.data.frame(cbind(spikeData_mainNeuron,spikeData_otherNeurons)))
  
}

getBasis2 = function(nBases,binSize){
  b = binSize*5
  peaks = c(binSize,binSize*50)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}

weightedSpikeData = function(spikeData,nBases_history,nBases_connectivity,binSize=0.01){
  bas_hist = getBasis2(nBases_history,binSize)$bas_orth
  bas_connect = getBasis2(nBases_connectivity,binSize)$bas_orth
  
  #history
  basisWeights = matrix(NA,nrow=dim(spikeData)[1]-1,ncol=nBases_history)
  for(k in seq(1,dim(bas_hist)[2])){
    basisWeights[,k] = convolve(c(0,spikeData[,3]),rev(bas_hist[,k]),type="open")[2:dim(spikeData)[1]]
  }
  
  txt=NULL
  for(k in seq(1,nBases_history)){
    txt = c(txt,paste(sub("spikeCount","",colnames(spikeData)[3]),".k",k,sep=""))
  }
  colnames(basisWeights) = txt
  
  spikeData_basis = cbind(spikeData[-1,seq(1,3)],basisWeights) #when using convolution
  colnames(spikeData_basis)[1:3] = colnames(spikeData)[1:3]
  spikeData_basis = as.data.frame(spikeData_basis)
  
  #connectivity
  for(j in seq(4,dim(spikeData)[2])){
    basisWeights = matrix(NA,nrow=dim(spikeData)[1]-1,ncol=nBases_connectivity)
    for(k in seq(1,dim(bas_connect)[2])){
      basisWeights[,k] = convolve(c(0,spikeData[,j]),rev(bas_connect[,k]),type="open")[2:dim(spikeData)[1]]
    }
    
    txt=NULL
    for(k in seq(1,nBases_connectivity)){
      txt = c(txt,paste(sub("spikeCount","",colnames(spikeData)[j]),".k",k,sep=""))
    }
    colnames(basisWeights) = txt
    
    spikeData_basis = cbind(spikeData_basis,basisWeights)
    
  }
  
  return(spikeData_basis)
  
}

binSize = 0.01

spikeData = discretizeAndAlignSpikeData(mainNeuron = 1,trials.good,binSize)
#str(spikeData)

spikeData_basis = weightedSpikeData(spikeData,
                                       nBases_history = 10,
                                       nBases_connectivity = 4,binSize)
#str(spikeData_basis)


pdf(file="/Volumes/harisf/master/figures/tuningCurves/polydeg5.pdf",width=dev.size()[1],height=dev.size()[2])
matplot(t[1:499,],type="l",lty=1,col=seq(1,5),main="poly(lickOnset,5)",xlab="trial time (index)")
dev.off()


# fit GAM model, to get the estimated degree of freedom of spline
library(mgcv)
txtFormula = names(spikeData_basis)[4]
for(name in names(spikeData_basis)[5:dim(spikeData_basis)[2]]){
  txtFormula = paste(txtFormula,"+",name,sep="")
}
txtFormula = paste(names(spikeData_basis)[3]," ~ s(lickOnset) + ",txtFormula,sep="")

model_spline = gam(formula = formula(txtFormula),
                   data = spikeData_basis, family = "poisson")

deg = round(anova(model_spline)$edf)

# fit lasso model, using polynomial effect of lickOnset
predMat = cbind(spikeData_basis[,-c(1,2,3)],poly(spikeData_basis$lickOnset,degree = deg))
txtPolyname = NULL
for(i in seq(1,deg))
  txtPolyname = c(txtPolyname,paste("poly(lickOnset)",i,sep = ""))
colnames(predMat)[seq(dim(predMat)[2]-deg+1,dim(predMat)[2])] = txtPolyname
library(glmnet)
model_lasso = glmnet(x = as.matrix(predMat),y = as.factor(spikeData_basis[,3]),
                     family = "binomial",alpha = 1)
plot(model_lasso,xvar = "lambda")
plot(model_lasso,label=T)

#library(plotmo)
pdf(file="/Volumes/harisf/master/figures/bases/neuron1_final/lassoPath.pdf",width=dev.size()[1],height=dev.size()[2])
plot_glmnet(model_lasso,label = 10,xvar="lambda") #xvar can be lambda, rlambda, norm or dev
dev.off()

# find lasso model from cross-validation
model_lasso_cv = cv.glmnet(x = as.matrix(predMat),y = as.factor(spikeData_basis[,3]),
                       family = "binomial",alpha = 1)
# model_lasso_cv = cv.glmnet(x = as.matrix(predMat),y = spikeData_basis[,3],
#                            family = "poisson",alpha = 1)

pdf(file="/Volumes/harisf/master/figures/bases/neuron1_final/cvLambda.pdf",width=dev.size()[1],height=dev.size()[2])
plot(model_lasso_cv)
dev.off()
coef(model_lasso_cv,s="lambda.min")


# print coefficient table
library(xtable)
printCoefTables = function(cvfit,mainNeuron,nBases_history, nBases_connectivity,deg,roundDigits){
  #format(fittedValues,scientific = T,digits = 3)
  #round(aic,digits = 0)
  #print(xtable(summaryTable_interceptModels),include.rownames = TRUE,only.contents = TRUE)
  #print(xtable(t(as.matrix(coef(model_lasso_cv,s="lambda.min")))),include.rownames = T,only.contents = TRUE)
  
  COEFS = round(coef(cvfit, s = "lambda.min"),digits = roundDigits)
  coeff_connectivity = COEFS[(nBases_history+2):(length(COEFS)-deg)]
  
  # coeff_intercept = coef(cvfit, s = "lambda.min")[1]
  # coeff_history = coef(cvfit, s = "lambda.min")[2:(nBases_history+1)]
  #coeff_connectivity = coef(cvfit, s = "lambda.min")[-seq(1,(nBases_history+1))]
  #coeff_connectivity = coef(cvfit, s = "lambda.min")[(nBases_history+2):(length(coef(cvfit, s = "lambda.min"))-deg)]
  #coeff_lickOnset = coef(cvfit, s = "lambda.min")[(length(coef(cvfit, s = "lambda.min"))-deg+1):length(coef(cvfit, s = "lambda.min"))]
  
  getTxtBases = function(nBases){
    txtBases = NULL
    for(k in seq(1,nBases)){
      txtBases = c(txtBases,paste("k",k,sep=""))
    }
    return(txtBases)
  }
  
  tableCoef_otherNeurons = matrix(NA,ncol=29,nrow=nBases_connectivity)
  otherNeurons = dimnames(COEFS)[[1]][(nBases_history+2):(length(COEFS)-deg)]
  txtotherNeurons = NULL
  i = 1
  for(j in seq(1,29*nBases_connectivity,nBases_connectivity)){
    currentNeuron = substring(otherNeurons[j],2,gregexpr("k",otherNeurons[j])[[1]][1]-2)
    txtotherNeurons = c(txtotherNeurons,paste("N",currentNeuron,sep=""))
    tableCoef_otherNeurons[,i] = coeff_connectivity[seq(j,j+nBases_connectivity-1)]
    tableCoef_otherNeurons[which(tableCoef_otherNeurons[,i] == 0),i] = "."
    i = i + 1
  }
  #colnames(tableCoef_otherNeurons) = txtotherNeurons
  colnames(tableCoef_otherNeurons) = as.character(setdiff(seq(1,30),mainNeuron))
  rownames(tableCoef_otherNeurons) = getTxtBases(nBases_connectivity)
  
  tableCoef_history = as.matrix(COEFS[1:(nBases_history+1)],ncol=1)
  rownames(tableCoef_history) = c("intercept",getTxtBases(nBases_history))
  
  tableCoef_lickOnset = as.matrix(COEFS[(length(COEFS)-deg+1):length(COEFS)],ncol=1)
  
  
  # print intercept + history
  print(xtable(t(tableCoef_history)),include.rownames = T,only.contents = TRUE)
  # print lickOnset
  print(xtable(t(tableCoef_lickOnset)),include.rownames = T,only.contents = TRUE)
  # print connectivity
  print(xtable(t(tableCoef_otherNeurons)),include.rownames = T,only.contents = TRUE)
  
}
  
printCoefTables(model_lasso_cv,mainNeuron = 1,nBases_history = 10, nBases_connectivity = 4,deg = 5,roundDigits = 2)










# COMPARE THE FITTED POLYNOMIAL FROM LASSO MODEL TO THE SPLINE FROM GAM
#lickOnsetPoly_lasso = poly(spikeData$lickOnset[1:500],deg) %*% coef(model_lasso_cv,s="lambda.min")[seq(length(coef(model_lasso_cv,s="lambda.min"))-deg+1,length(coef(model_lasso_cv,s="lambda.min")))]
lickOnsetPoly_lasso_full = poly(spikeData_basis$lickOnset,deg) %*% coef(model_lasso_cv,s="lambda.min")[seq(length(coef(model_lasso_cv,s="lambda.min"))-deg+1,length(coef(model_lasso_cv,s="lambda.min")))]
pdf(file="/Volumes/harisf/master/figures/bases/gamVSglmnet/lickOnsetEffectDeg5_n2.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(1,2))
plot(model_spline,rug=F,se=F,xlab = "lickOnset (s)",
     main="gam spline")
plot(spikeData_basis$lickOnset[1:499],lickOnsetPoly_lasso_full[1:499],type="l",xlab="lickOnset (s)",ylab="",
     main=paste("glmnet poly deg.",deg))
dev.off()


# #fit GLM with lickOnset polynomial and bs
# model_poly = glm(formula = spikeCountj2 ~ . - trialId - lickOnset + poly(lickOnset,degree = deg),
#                  data = spikeData_basis, family = "poisson")
# library(splines)
# model_bs = glm(formula = spikeCountj2 ~ . - trialId - lickOnset + bs(lickOnset,df = 4.7,degree = deg),
#                  data = spikeData_basis, family = "poisson")
# 
# plot((poly(spikeData_basis$lickOnset,deg) %*% coefficients(model_poly)[seq(length(coefficients(model_poly))-deg+1,length(coefficients(model_poly)))])[1:500])
# plot((bs(spikeData_basis$lickOnset,deg) %*% coefficients(model_bs)[seq(length(coefficients(model_bs))-deg+1,length(coefficients(model_bs)))])[1:500])
# 
# #


















##########################################


# GLM MODEL
# this model doesn't converge... why?
deg = 5
model = glm(formula = spikeCountj1 ~ . - trialId - lickOnset + poly(lickOnset,deg),
               data = spikeData_n1_basis, family = "poisson")

model_n12 = glm(formula = spikeCountj12 ~ . - trialId - lickOnset,
               data = spikeData_n12_basis, family = "binomial")#,control = list(maxit=100))
summary(model_n12)
plot(coefficients(model_n1),coefficients(model_n1_maxit))
#plot(coefficients(model_n1)[128:132],type="b")

t = spikeData_n1$lickOnset[1:500]
test3 = poly(t,deg) %*% coefficients(model_n1)[seq(length(coefficients(model_n1))-deg+1,length(coefficients(model_n1)))]
plot(test3)
# GAM MODEL
# how to interpret this model?
# the spline s(lickOnset) is a straight line (the predictor has a linear effect),
# because the observations are not aggregated, since the basisweighted predictors all have different values

# library(gam)
# model_n1_gam = gam(formula = spikeCountj1 ~ . - trialId + s(lickOnset),
#                    data = spikeData_n1_basis, family = "binomial")
library(mgcv)
txtFormula = names(spikeData_basis)[4]
for(name in names(spikeData_n1_basis)[4:dim(spikeData_basis)[2]]){
  txtFormula = paste(txtFormula,"+",name,sep="")
}
txtFormula = paste("spikeCountj1 ~ s(lickOnset) + ",txtFormula,sep="")

model_n1_gam = gam(formula = formula(txtFormula),
                   data = spikeData_n1_basis, family = "binomial")
summary(model_n1_gam)
plot(model_n1_gam)#,terms = "s(lickOnset)")

model_n1_gam_nobasis = gam(formula = spikeCountj1 ~ s(lickOnset),
                           data = spikeData_n1_basis, family = "binomial")

summary(model_n1_gam_nobasis)
plot(model_n1_gam_nobasis)

#image(as.matrix(spikeData_n1_basis[,-c(1,2)]))

# LASSO REGRESSION
deg = 5
predMat = cbind(spikeData_basis[,-c(1,2,3)],poly(spikeData$lickOnset,degree = deg)[-1,])
txtPolyname = NULL
for(i in seq(1,deg))
  txtPolyname = c(txtPolyname,paste("poly(lickOnset)",i,sep = ""))
colnames(predMat)[seq(dim(predMat)[2]-deg+1,dim(predMat)[2])] = txtPolyname
library(glmnet)
model_n1_lasso = glmnet(x = as.matrix(predMat),
                        y = as.factor(spikeData_basis[,3]),
                        family = "poisson",alpha = 1)
# model_n1_lasso = glmnet(x = as.matrix(cbind(spikeData_n1_basis[,-c(1,2,3)],test)),
#                         y = as.factor(spikeData_n1_basis[,3]),
#                         family = "binomial",alpha = 1)
plot(model_n1_lasso)

# chose model with cross validaiton
model_lasso_cv_binomial = cv.glmnet(x = as.matrix(predMat),
                              y = as.factor(spikeData_basis[,3]),
                              family = "binomial",alpha = 1)
model_lasso_cv_poisson = cv.glmnet(x = as.matrix(predMat),
                              y = spikeData_basis[,3],
                              family = "poisson",alpha = 1)
plot(model_lasso_cv)
coef(model_lasso_cv, s = "lambda.min")






# save plots from lasso regression
plotAndSaveEffects = function(cvfit,filePathName,mainNeuron,nBases_history,nBases_connectivity,binSize = 0.01,family){
  bas_list_hist = getBasis2(nBases_history,binSize)
  bas_hist = bas_list_hist$bas_orth
  tau_N_hist = bas_list_hist$tau_N
  bas_list_connect = getBasis2(nBases_connectivity,binSize)
  bas_connect = bas_list_connect$bas_orth
  tau_N_connect = bas_list_connect$tau_N
  
  coeff_intercept = coef(cvfit, s = "lambda.min")[1]
  coeff_history = coef(cvfit, s = "lambda.min")[2:(nBases_history+1)]
  #coeff_connectivity = coef(cvfit, s = "lambda.min")[-seq(1,(nBases_history+1))]
  coeff_connectivity = coef(cvfit, s = "lambda.min")[(nBases_history+2):(length(coef(cvfit, s = "lambda.min"))-deg)]
  coeff_lickOnset = coef(cvfit, s = "lambda.min")[(length(coef(cvfit, s = "lambda.min"))-deg+1):length(coef(cvfit, s = "lambda.min"))]
  
  
  if(family == "poisson"){
    invLink = function(x){exp(x)}
    txtylab = paste("firing rate n",mainNeuron,sep="")
  }
  if(family == "binomial"){
    invLink = function(x){exp(x)/(1+exp(x))}
    txtylab = paste("firing prob. n",mainNeuron,sep="")
  }
  
  # save history plot
  pdf(file=paste(filePathName,"history.pdf",sep=""),width=dev.size()[1],height=dev.size()[2])
  
  plot(seq(binSize,tau_N_hist,binSize),invLink(bas_hist %*% coeff_history+coeff_intercept),type="l",
       xlab="lag (s)",ylab = txtylab,main=paste("history n",mainNeuron,sep=""),
       ylim = c(0,max(invLink(bas_hist %*% coeff_history + coeff_intercept))))
  
  
  # plot(c(0,seq(binSize,tau_N_hist,binSize)),exp(c(coeff_intercept,bas_hist %*% coeff_history)),type="l",
  #      xlab="lag (s)",ylab = paste("firing rate n",mainNeuron,sep=""),main=paste("history n",mainNeuron,sep=""))
  #abline(h=1,lty=2)
  abline(h=invLink(coeff_intercept),lty=2)
  dev.off()
  
  # save connectivity plots
  otherNeurons = dimnames(coef(cvfit, s = "lambda.min"))[[1]][-seq(1,(nBases_history+1))]
  for(j in seq(1,29*nBases_connectivity,nBases_connectivity)){
    currentNeuron = substring(otherNeurons[j],2,gregexpr("k",otherNeurons[j])[[1]][1]-2)
    pdf(file=paste(filePathName,"connectivity_n",currentNeuron,".pdf",sep=""),width=dev.size()[1],height=dev.size()[2])
    plot(seq(binSize,tau_N_connect,binSize),invLink(bas_connect %*% coeff_connectivity[seq(j,j+nBases_connectivity-1)]+coeff_intercept),type="l",
         xlab="lag (s)",ylab = txtylab,main=paste("n",mainNeuron," <- n",currentNeuron,sep=""),
         ylim = c(0,max(invLink(bas_hist %*% coeff_history+coeff_intercept))),xlim=c(0,tau_N_hist))
    #abline(h=1,lty=2)
    abline(h=invLink(coeff_intercept),lty=2)
    dev.off()
  }

}

plotAndSaveEffects(model_lasso_cv,
                   filePathName = "/Volumes/harisf/master/figures/bases/neuron1_final/",
                   mainNeuron = 1,nBases_history = 10, nBases_connectivity = 4,
                   family = "binomial")

# save lick onset plot
startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials.good]),na.rm=TRUE)
startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials.good]),na.rm=TRUE)
startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE) # aka lickOnset

#if(family == "binomial"){
  invLink = function(x){exp(x)/(1+exp(x))}
#}
lickOnsetPoly_full = poly(spikeData_basis$lickOnset,deg) %*% coef(model_lasso_cv,s="lambda.min")[seq(length(coef(model_lasso_cv,s="lambda.min"))-deg+1,length(coef(model_lasso_cv,s="lambda.min")))]
pdf(file="/Volumes/harisf/master/figures/bases/neuron1_final/lickOnset.pdf",width=dev.size()[1],height=dev.size()[2])
plot(spikeData_basis$lickOnset[1:499],invLink(lickOnsetPoly_full[1:499]+coef(cvfit, s = "lambda.min")[1]),type="l",xlab="lickOnset (s)",ylab=paste("firing prob. n",mainNeuron,sep=""),
     main=paste("n",mainNeuron," poly(lO) deg.",deg,sep=""))
abline(h=invLink(coef(cvfit, s = "lambda.min")[1]),lty=2)#,col="gray")
abline(v=startOfSampleEpoch-startOfResponseEpoch,lty=3,col="gray")
abline(v=startOfDelayEpoch-startOfResponseEpoch,lty=3,col="gray")
abline(v=startOfResponseEpoch-startOfResponseEpoch,lty=3,col="gray")
dev.off()


nBases_history = 10
nBases_connectivity = 4
bas_list_hist = getBasis2(nBases_history,binSize)
bas_hist = bas_list_hist$bas_orth
tau_N_hist = bas_list_hist$tau_N
bas_list_connect = getBasis2(nBases_connectivity,binSize)
bas_connect = bas_list_connect$bas_orth
tau_N_connect = bas_list_connect$tau_N

coeff_intercept = coef(cvfit, s = "lambda.min")[1]
coeff_history = coef(cvfit, s = "lambda.min")[2:(nBases_history+1)]
coeff_connectivity = coef(cvfit, s = "lambda.min")[(nBases_history+2):(length(coef(cvfit, s = "lambda.min"))-deg)]

pdf(file="/Volumes/harisf/master/figures/bases/neuron1_final/allConnectivity.pdf",width=dev.size()[1]*5*0.6,height=dev.size()[2]*6*0.65)
par(mfrow=c(6,5))
otherNeurons = dimnames(coef(model_lasso_cv, s = "lambda.min"))[[1]][(nBases_history+2):(length(coef(cvfit, s = "lambda.min"))-deg)]
for(j in seq(1,29*nBases_connectivity,nBases_connectivity)){
  currentNeuron = substring(otherNeurons[j],2,gregexpr("k",otherNeurons[j])[[1]][1]-2)
  if(j == 1){
    plot(seq(binSize,tau_N_connect,binSize),invLink(bas_connect %*% coeff_connectivity[seq(j,j+nBases_connectivity-1)]+coeff_intercept),type="l",
         xlab="lag (s)",ylab = "firing prob. n1",main=paste("n",mainNeuron," <- n",currentNeuron,sep=""),
         ylim = c(0,max(invLink(bas_hist %*% coeff_history+coeff_intercept))),xlim=c(0,tau_N_hist))
    abline(h=invLink(coeff_intercept),lty=2)
  } else {
    plot(seq(binSize,tau_N_connect,binSize),invLink(bas_connect %*% coeff_connectivity[seq(j,j+nBases_connectivity-1)]+coeff_intercept),type="l",
         xlab="",ylab = "",main=paste("n",mainNeuron," <- n",currentNeuron,sep=""),yaxt="n",xaxt="n",
         ylim = c(0,max(invLink(bas_hist %*% coeff_history+coeff_intercept))),xlim=c(0,tau_N_hist))
    abline(h=invLink(coeff_intercept),lty=2)
  }
}
dev.off()


pdf(file="/Volumes/harisf/master/figures/bases/neuron1_final/historyANDallConnectivity.pdf",width=dev.size()[1]*5*0.58,height=dev.size()[2]*6*0.6)
par(mfrow=c(6,5))
plot(seq(binSize,tau_N_hist,binSize),invLink(bas_hist %*% coeff_history+coeff_intercept),type="l",
     xlab="lag (s)",ylab = "firing prob. n1",main=paste("history n",mainNeuron,sep=""),
     ylim = c(0,max(invLink(bas_hist %*% coeff_history + coeff_intercept))),cex.main=1.5,cex.lab=1)
abline(h=invLink(coeff_intercept),lty=2)
otherNeurons = dimnames(coef(model_lasso_cv, s = "lambda.min"))[[1]][(nBases_history+2):(length(coef(cvfit, s = "lambda.min"))-deg)]
for(j in seq(1,29*nBases_connectivity,nBases_connectivity)){
  currentNeuron = substring(otherNeurons[j],2,gregexpr("k",otherNeurons[j])[[1]][1]-2)
  plot(seq(binSize,tau_N_connect,binSize),invLink(bas_connect %*% coeff_connectivity[seq(j,j+nBases_connectivity-1)]+coeff_intercept),type="l",
       xlab="",ylab = "",main=paste("n",mainNeuron," <- n",currentNeuron,sep=""),yaxt="n",xaxt="n",
       ylim = c(0,max(invLink(bas_hist %*% coeff_history+coeff_intercept))),xlim=c(0,tau_N_hist),cex.main=1.5,cex.lab=1)
  abline(h=invLink(coeff_intercept),lty=2)
}
dev.off()



