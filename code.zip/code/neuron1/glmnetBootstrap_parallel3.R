setwd("/home/shomea/h/harisf/master/data/variables")
#setwd("/Volumes/harisf/master/data/variables")
lassoData = readRDS("lassoData.rds")
# lassoData: 156499 observations on 132 parameters

library(glmnet)
library(boot)

bootStatistic = function(lassoData,indices){
  d = lassoData[indices,] # allow boot to select data samples
  # model_lasso_cv = cv.glmnet(x = as.matrix(d[,-1]),y = as.factor(d[,1]),
  #                            family = "binomial",alpha = 1,nfolds = 10)
  #model_lasso = glmnet(x = as.matrix(d[,-1]),y = as.factor(d[,1]),
  #                     family = "binomial",alpha = 1)
  #return(as.numeric(coef(model_lasso_cv,s="lambda.min")))
  #colMeans(d)
  x=as.matrix(d[,-1])
  y=as.factor(d[,1])
  #fit1=glmnet(x,y,family = "binomial")
  fit1 = glm(y ~ x,family = "binomial")
  
  #as.numeric(coef(fit1,s=0.01))
  as.numeric(coefficients(fit1))
  
}
#lassoData2 = lassoData[,-1]

bootResults = boot(data = lassoData, statistic = bootStatistic, R=100,
                   parallel = "multicore", ncpus = 10)
# 
saveRDS(bootResults,"bootResults.rds")
# 
# 
# 
# x=matrix(rnorm(100*20),100,20)
# y=rnorm(100)
# fit1=glmnet(x = as.matrix(lassoData[,-1]),y = as.factor(lassoData[,1]),family = "binomial")
# 
# str(as.numeric(coef(fit1,s=0.01)))


# x=as.matrix(lassoData[,-1])
# y=as.factor(lassoData[,1])
# #fit1=glmnet(x,y,family = "binomial")
# fit1 = glm(y ~ x,family = "binomial")
# as.numeric(coefficients(fit1))
