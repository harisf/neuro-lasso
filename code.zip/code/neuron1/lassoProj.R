setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
#setwd("/Volumes/harisf/master/data/variables/modelMatrix")
#lassoData = readRDS("lassoData.rds")
modelMatrix = readRDS("n1_b10ms.rds")

library(Matrix)
#library(doParallel)
#library(doMC)
#library(parallel)
library(hdi)
#library(glmnet)

# modelMatrix.Mat = Matrix(as.matrix(modelMatrix))
# x = modelMatrix.Mat[,-1]
# y = modelMatrix.Mat[,1]
# y[which(y > 1)] = 1

x = as.matrix(modelMatrix[,-1])
y = as.factor(modelMatrix[,1])

# tol = 1e-10
# for(i in seq(1,dim(x)[2])){
#   x[which(abs(x[,i]) < tol),i] = 0
# }

#y.sparsed = Matrix(y,sparse = TRUE)
#x = Matrix(x,sparse = TRUE) # reduces x by 55 Mb. I.e. x is 172 Mb, and x.sparsed is 117 Mb
#y = Matrix(y,sparse = TRUE)

#registerDoParallel(10)
# model_lasso_cv = cv.glmnet(x,y,family="binomial",alpha=1,
#                            nfolds = 10,parallel = T)

#system.time(fit <- lasso.proj(x,y,family = "binomial",parallel = TRUE,ncores = 10,suppress.grouptesting = F))
# startTime = Sys.time()
# fit <- lasso.proj(x,y,family = "binomial",parallel = TRUE,ncores = 10,suppress.grouptesting = T)
# Sys.time() - startTime
#stopImplicitCluster()

startTime = Sys.time()
fit <- multi.split(x,y, ci = FALSE, 
                   classical.fit = glm.pval, args.classical.fit = list(family = "binomial",verbose = TRUE),
                   model.selector = lasso.cv, args.model.selector = list(family = "binomial"),
                   parallel = TRUE, ncores = 10,
                   return.selmodels = TRUE, verbose = TRUE)
Sys.time() - startTime

# no_cores = detectCores() - 1
#no_cores = 10
#registerDoParallel(no_cores)
#registerDoMC(cores = no_cores)
#system.time(pval <- lasso.proj(x,y,family = "binomial",parallel = TRUE,ncores = 10)$pval)
#stopImplicitCluster()

# lasso.proj_parallel = function(data){
#   x = data[,-1]
#   y = data[,1]
#   lasso.proj(x,y,family = "binomial",parallel = T,ncores = 10)
# }
# 
# res <- mclapply(lassoData.Mat,lasso.proj_parallel,mc.cores = no_cores)

#saveRDS(res,"res_lasso_proj.rds")
setwd("/home/shomea/h/harisf/master/data/variables")
saveRDS(fit,"fitMultisplit_n1_b10ms.rds")
#saveRDS(pval,"pval.rds")

# x <- matrix(rnorm(100*20), nrow = 1000, ncol = 10)
# y <- x[,1] + x[,2] + rnorm(1000)
# # system.time(fit.lasso <- lasso.proj(x, y))
# system.time(fit.lasso_par <- lasso.proj(x, y,parallel = T,ncores = 3))










