# setwd("/Volumes/harisf/master/data/variables")
# lassoData = readRDS("lassoData.rds")
# bootResults = readRDS("bootResults_neuron1.rds")
# 
# str(bootResults[1,"boot.coef"])
# colnames(lassoData)
# 
# proportionZero = matrix(0,ncol = 132,nrow = 1)
# boot.coef = matrix(NA,ncol = 132,nrow = 1000)
# 
# colnames(proportionZero) = c("intercept",colnames(lassoData)[-1])
# colnames(boot.coef) = c("intercept",colnames(lassoData)[-1])
# 
# for(i in seq(1,1000)){
#   indexesZero = which(bootResults[i,]$boot.coef == 0)
#   proportionZero[1,indexesZero] = proportionZero[1,indexesZero] + 1
#   
#   boot.coef[i,] = bootResults[i,]$boot.coef
# }
# proportionZero = proportionZero / 1000
# 
# proportionZero.increasingIndex = sort(proportionZero[1,],decreasing = F,index.return=T)$ix
# colnames(proportionZero)[proportionZero.increasingIndex]
# 
# #pdf(file="/Volumes/harisf/master/figures/bootstrap/allCoefs.pdf",width=dev.size()[1],height=dev.size()[2])
# par(mfrow=c(1,2))
# #par(cex.axis=0.4)
# #par(cex.lab=1.5)
# boxplot(boot.coef[,proportionZero.increasingIndex],las=1,horizontal=T,show.names=T,
#         main="Bootstrap samples",cex.axis=0.3)
# barplot(sort(proportionZero[1,],decreasing = F),horiz = T,las=1,cex.names = 0.3,
#         main="Bootstrap prob. of 0")
# #dev.off()
# 
# 
# # history
# boxplot(boot.coef[,2:11],las=1,horizontal=T)
# abline(v=0,lty=2)
# barplot(proportionZero[1,2:11],las=1,horiz=T,xlim=c(0,1))
# 
# # lickOnset
# boxplot(boot.coef[,128:132],las=1,horizontal=T)
# abline(v=0,lty=2)
# barplot(proportionZero[1,128:132],las=1,horiz=T,xlim=c(0,1))
# 
# # neuron 2
# boxplot(boot.coef[,12:15],las=1,horizontal=T)
# abline(v=0,lty=2)
# barplot(proportionZero[1,12:15],las=1,horiz=T,xlim=c(0,1))
# 
# # plot boot.cvm, i.e. mean cross-validation error
# # HVORDAN REGNE UT GJENNOMSNITTET (ROD PLOT I FIG. 6.5 SIDE 144 I SLS)
# par(mfrow=c(1,1))
# plot(log(bootResults[1,]$boot.lambda),bootResults[1,]$boot.cvm,type="l",col = "gray",
#      ylim=c(0.0346,0.0501))
# for(i in seq(2,1000)){
#   lines(log(bootResults[i,]$boot.lambda),bootResults[i,]$boot.cvm,col = "gray")
# }


# 10 ms VS 100 ms
setwd("/Volumes/harisf/master/data/variables/modelMatrix")
data10ms = readRDS("n1_b10ms.rds")
data100ms = readRDS("n1_b100ms.rds")

setwd("/Volumes/harisf/master/data/variables/bootstrap")
res10ms = readRDS("n1_b10ms.rds")
res100ms = readRDS("n1_b100ms.rds")

proportionZeroANDbootCoef = function(bootResults,modelMatrix){
  proportionZero = matrix(0,ncol = 132,nrow = 1)
  boot.coef = matrix(NA,ncol = 132,nrow = 1000)
  
  colnames(proportionZero) = c("intercept",colnames(modelMatrix)[-1])
  colnames(boot.coef) = c("intercept",colnames(modelMatrix)[-1])
  
  for(i in seq(1,1000)){
    indexesZero = which(bootResults[i,]$boot.coef == 0)
    proportionZero[1,indexesZero] = proportionZero[1,indexesZero] + 1
  
    boot.coef[i,] = bootResults[i,]$boot.coef
  }
  proportionZero = proportionZero[1,] / 1000 #* colMeans(boot.coef)
  #proportionZero = proportionZero[-1]
  
  proportionZero.increasingIndex = sort(proportionZero,decreasing = F,index.return=T)$ix
  names(proportionZero)[proportionZero.increasingIndex]
  
  # #pdf(file="/Volumes/harisf/master/figures/bootstrap/allCoefs.pdf",width=dev.size()[1],height=dev.size()[2])
  # par(mfrow=c(1,2))
  # #par(cex.axis=0.4)
  # #par(cex.lab=1.5)
  # boxplot(boot.coef[,proportionZero.increasingIndex],las=1,horizontal=T,show.names=T,
  #         main="Bootstrap samples",cex.axis=0.3)
  # barplot(sort(proportionZero[1,],decreasing = F),horiz = T,las=1,cex.names = 0.3,
  #         main="Bootstrap prob. of 0")
  # #dev.off()
  return(boot.coef)

}

coefOrder10ms = proportionZeroANDbootCoef(res10ms,data10ms)
#coefOrder100ms = proportionZeroANDbootCoef(res100ms,data100ms)

#coefOrder10ms == coefOrder100ms

boot.coef10ms = proportionZeroANDbootCoef(res10ms,data10ms)
#boot.coef100ms = proportionZeroANDbootCoef(res100ms,data100ms)
boxplot(boot.coef10ms[,-seq(128,132)],las=1,horizontal=T,show.names=F)








################################################
# 100 ms bootstrap VS 100 ms lasso.proj
################################################
setwd("/Volumes/harisf/master/data/variables")
fit_lasso_proj = readRDS("fitLassoProj_n1_b100ms.rds")
#plot(coefOrder10ms[-1],names(sort(fit_lasso_proj$pval,decreasing = F)))

# boot rank vs hdi rank
pdf(file="/Volumes/harisf/master/figures/bootstrap/bootVShdi.pdf",
    width = dev.size()[1],height = dev.size()[2])
plot(1,type="n",xlab="boot rank (smalles to largest Prob(coef = 0))",ylab="hdi rank (smalles to largest p-value)",xlim=c(1,131),ylim=c(1,131),
     main=expression(paste("Boot vs hdi ",Delta,"t = 100 ms",sep = "")))
for(i in seq(1,131)){
  rankInBoot = which(is.element(coefOrder100ms,names(sort(fit_lasso_proj$pval,decreasing = F))[i]) == T)
  points(i,rankInBoot)
  text(i,rankInBoot,labels = coefOrder100ms[i],pos=3,cex = 0.5)
}
lines(seq(1,131),seq(1,131))
dev.off()


# boot coef vs hdi rank
pdf(file="/Volumes/harisf/master/figures/bootstrap/bootVShdi.pdf",
    width = dev.size()[1],height = dev.size()[2])
plot(1,type="n",xlab="boot rank (smalles to largest Prob(coef = 0))",ylab="hdi rank (smalles to largest p-value)",xlim=c(1,131),ylim=c(1,131),
     main=expression(paste("Boot vs hdi ",Delta,"t = 100 ms",sep = "")))
for(i in seq(1,131)){
  rankInBoot = which(is.element(coefOrder100ms[-1],names(sort(fit_lasso_proj$pval* colMeans(boot.coef100ms)[-1],decreasing = F))[i]) == T)
  points(i,rankInBoot)
  text(i,rankInBoot,labels = coefOrder100ms[-1][i],pos=3,cex = 0.5)
}
lines(seq(1,131),seq(1,131))
dev.off()





####################
# lasso.proj
####################

setwd("/Volumes/harisf/master/data/variables")
fit_lasso_proj = readRDS("fitLassoProj_n1_b100ms.rds")

hist(fit_lasso_proj$pval,freq = F)


coefANDpval = cbind(fit_lasso_proj$bhat,fit_lasso_proj$pval)
colnames(coefANDpval) = c("est.coef.","pvalue")

pval = fit_lasso_proj$pval
pval.corr = fit_lasso_proj$pval.corr

pval.corr[which(pval.corr < 0.05)]






