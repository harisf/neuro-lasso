setwd("/home/shomea/h/harisf/master/data/variables")
#setwd("/Volumes/harisf/master/data/variables")
lassoData = readRDS("lassoData.rds")
wts = readRDS("wts.rds")

library(glmnet)
# library(doMC)
# registerDoMC(cores=10)
library(doParallel)
no_cores = 10
registerDoParallel(no_cores)

model_lasso_cv = cv.glmnet(x = as.matrix(lassoData[,-1]),y = as.factor(lassoData[,1]),
                           family = "binomial",alpha = 1,weights = wts, nfolds = 10,
                           parallel = TRUE)

stopImplicitCluster()

saveRDS(model_lasso_cv,"model_lasso_cv.rds")