setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
#setwd("/Volumes/harisf/master/data/variables")
modelMatrix = readRDS("n1_b1ms.rds")

library(foreach)
library(doParallel)
library(glmnet)
library(Matrix)

B = 1000

# y = lassoData[,1]
# y[which(y > 1)] = 1
# y = as.factor(y)

# x = as.matrix(lassoData[,-1])
# tol = 1e-10
# for(i in seq(1,dim(x)[2])){
#   x[which(abs(x[,i]) < tol),i] = 0
# }
# x = Matrix(x,sparse = TRUE)

y = modelMatrix[,1]
x = modelMatrix[,-1]


startTime = Sys.time()

no_cores = detectCores()-1
registerDoParallel(no_cores)
bootResults = foreach(b = 1:B,.combine = rbind) %dopar% {
  
  # get weights 
  N = dim(modelMatrix)[1]
  no_cores = detectCores()-1
  registerDoParallel(no_cores)
  bootSample = sample(x=N,size=N,replace=T)
  wts = foreach(index = 1:N,
                .combine = c) %dopar%
    sum(bootSample==index)
  stopImplicitCluster()
  
  # fit cv.glmnet model
  no_cores = 10
  registerDoParallel(no_cores)
  model_lasso_cv = cv.glmnet(x,y,
                             family = "binomial",alpha = 1,weights = wts, nfolds = 10,
                             parallel = TRUE)
  stopImplicitCluster()
  
  list(boot.coef = as.numeric(coef(model_lasso_cv,s="lambda.min")),
       boot.cvm = model_lasso_cv$cvm,
       boot.lambda = model_lasso_cv$lambda,
       boot.lambda.min = model_lasso_cv$lambda.min)
  
  if((b %% 100) == 0)
    cat("Iterations completed: ",b,"\n",sep="")
}
stopImplicitCluster()

Sys.time() - startTime

setwd("/home/shomea/h/harisf/master/data/variables/bootstrap")
saveRDS(bootResults,"n1_b1ms.rds")









