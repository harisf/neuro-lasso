# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

rm(list=setdiff(ls(), c("data")))

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()


discretizeSpikeData = function(neuron,TRIALS,binSize=0.01,tau_N=NA){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  if(!is.na(tau_N)){
    M = floor(tau_N / binSize) # number of bins we go back
    mat_j = cbind(mat_j,matrix(NA,nrow=dim(mat_j)[1],ncol=M))
  }
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]-lickOnset
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    if(!is.na(tau_N)){
      for(m in seq(1,M)){
        mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
        #mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
      }
    }
    
    mat = rbind(mat,mat_j)
  }
  
  if(!is.na(tau_N)){
    cnames = c()
    for(m in seq(1,M)){
      cnames = c(cnames,paste("spikeCountj",neuron,"m",m,sep = ""))
    }
    colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""),cnames)
  } else
    colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""))
  df = as.data.frame(mat)
  return(df)
}

discretizeAndAlignSpikeData = function(mainNeuron,TRIALS,binSize=0.01){
  spikeData_mainNeuron = discretizeSpikeData(mainNeuron,TRIALS,binSize)
  
  otherNeurons = setdiff(seq(1,30),mainNeuron)
  spikeData_otherNeurons = matrix(NA,nrow=dim(spikeData_mainNeuron)[1],ncol=29)
  
  colnamesTxt = NULL
  timeInterval = seq(0,5,binSize)
  for(i in seq(1,29)){
    neuron = otherNeurons[i]
    eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
    eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
    
    for(trial_j in unique(spikeData_mainNeuron$trialId)){
      trialStartTime_j = data$obj[[7]][1,trial_j]
      eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
      
      spikeData_otherNeurons[which(spikeData_mainNeuron$trialId == trial_j),i] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
      
    }
    colnamesTxt = c(colnamesTxt,paste("spikeCountj",neuron,sep = ""))
  }
  colnames(spikeData_otherNeurons) = colnamesTxt
  
  return(as.data.frame(cbind(spikeData_mainNeuron,spikeData_otherNeurons)))
  
}

getBasis2 = function(nBases,binSize){
  b = binSize*5
  peaks = c(binSize,binSize*50)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}

weightedSpikeData = function(spikeData,nBases_history,nBases_connectivity,binSize=0.01){
  bas_hist = getBasis2(nBases_history,binSize)$bas_orth
  bas_connect = getBasis2(nBases_connectivity,binSize)$bas_orth
  
  #history
  basisWeights = matrix(NA,nrow=dim(spikeData)[1]-1,ncol=nBases_history)
  for(k in seq(1,dim(bas_hist)[2])){
    basisWeights[,k] = convolve(c(0,spikeData[,3]),rev(bas_hist[,k]),type="open")[2:dim(spikeData)[1]]
  }
  
  txt=NULL
  for(k in seq(1,nBases_history)){
    txt = c(txt,paste(sub("spikeCount","",colnames(spikeData)[3]),".k",k,sep=""))
  }
  colnames(basisWeights) = txt
  
  spikeData_basis = cbind(spikeData[-1,seq(1,3)],basisWeights) #when using convolution
  colnames(spikeData_basis)[1:3] = colnames(spikeData)[1:3]
  spikeData_basis = as.data.frame(spikeData_basis)
  
  #connectivity
  for(j in seq(4,dim(spikeData)[2])){
    basisWeights = matrix(NA,nrow=dim(spikeData)[1]-1,ncol=nBases_connectivity)
    for(k in seq(1,dim(bas_connect)[2])){
      basisWeights[,k] = convolve(c(0,spikeData[,j]),rev(bas_connect[,k]),type="open")[2:dim(spikeData)[1]]
    }
    
    txt=NULL
    for(k in seq(1,nBases_connectivity)){
      txt = c(txt,paste(sub("spikeCount","",colnames(spikeData)[j]),".k",k,sep=""))
    }
    colnames(basisWeights) = txt
    
    spikeData_basis = cbind(spikeData_basis,basisWeights)
    
  }
  
  return(spikeData_basis)
  
}

binSize = 0.01

spikeData_n1 = discretizeAndAlignSpikeData(neuron = 1,trials.good,binSize)
str(spikeData_n1)

spikeData_n1_basis = weightedSpikeData(spikeData_n1,
                                       nBases_history = 10,
                                       nBases_connectivity = 4)
str(spikeData_n1_basis)

# GLM MODEL
# this model doesn't converge... why?
model_n1 = glm(formula = spikeCountj1 ~ . - trialId - lickOnset,
                       data = spikeData_n1_basis, family = "binomial")

# GAM MODEL
# how to interpret this model?
# the spline s(lickOnset) is a straight line (the predictor has a linear effect),
# because the observations are not aggregated, since the basisweighted predictors all have different values

# library(gam)
# model_n1_gam = gam(formula = spikeCountj1 ~ . - trialId + s(lickOnset),
#                    data = spikeData_n1_basis, family = "binomial")
library(mgcv)
txtFormula = names(spikeData_n1_basis)[4]
for(name in names(spikeData_n1_basis)[4:129]){
  txtFormula = paste(txtFormula,"+",name,sep="")
}
txtFormula = paste("spikeCountj1 ~ s(lickOnset) + ",txtFormula,sep="")

model_n1_gam = gam(formula = formula(txtFormula),
                   data = spikeData_n1_basis, family = "binomial")
summary(model_n1_gam)
plot(model_n1_gam)#,terms = "s(lickOnset)")

model_n1_gam_nobasis = gam(formula = spikeCountj1 ~ s(lickOnset),
                           data = spikeData_n1_basis, family = "binomial")

summary(model_n1_gam_nobasis)
plot(model_n1_gam_nobasis)

#image(as.matrix(spikeData_n1_basis[,-c(1,2)]))

# LASSO REGRESSION
library(glmnet)
model_n1_lasso = glmnet(x = as.matrix(spikeData_n1_basis[,-c(1,2,3)]),
                        y = as.factor(spikeData_n1_basis[,3]),
                        family = "binomial",alpha = 1)
plot(model_n1_lasso)

# chose model with cross validaiton
model_n1_lasso_cv = cv.glmnet(x = as.matrix(spikeData_n1_basis[,-c(1,2,3)]),
                        y = as.factor(spikeData_n1_basis[,3]),
                        family = "binomial",alpha = 1)
plot(model_n1_lasso_cv)
coef(model_n1_lasso_cv, s = "lambda.min")

# save plots from lasso regression
plotAndSaveEffects = function(cvfit,filePathName,mainNeuron,nBases_history,nBases_connectivity,binSize = 0.01){
  bas_list_hist = getBasis2(10,binSize)
  bas_hist = bas_list_hist$bas_orth
  tau_N_hist = bas_list_hist$tau_N
  bas_list_connect = getBasis2(4,binSize)
  bas_connect = bas_list_connect$bas_orth
  tau_N_connect = bas_list_connect$tau_N
  
  coeff_intercept = coef(cvfit, s = "lambda.min")[1]
  coeff_history = coef(cvfit, s = "lambda.min")[2:(nBases_history+1)]
  coeff_connectivity = coef(cvfit, s = "lambda.min")[-seq(1,(nBases_history+1))]
  
  # save history plot
  pdf(file=paste(filePathName,"history.pdf",sep=""),width=dev.size()[1],height=dev.size()[2])
  
  plot(seq(binSize,tau_N_hist,binSize),exp(bas_hist %*% coeff_history),type="l",
       xlab="lag (s)",ylab = paste("firing rate n",mainNeuron,sep=""),main=paste("history n",mainNeuron,sep=""),
       ylim = c(0,max(exp(bas_hist %*% coeff_history))))
  
  
  # plot(c(0,seq(binSize,tau_N_hist,binSize)),exp(c(coeff_intercept,bas_hist %*% coeff_history)),type="l",
  #      xlab="lag (s)",ylab = paste("firing rate n",mainNeuron,sep=""),main=paste("history n",mainNeuron,sep=""))
  abline(h=1,lty=2)
  dev.off()
  
  # save connectivity plots
  otherNeurons = dimnames(coef(cvfit, s = "lambda.min"))[[1]][-seq(1,(nBases_history+1))]
  for(j in seq(1,29*nBases_connectivity,nBases_connectivity)){
    currentNeuron = substring(otherNeurons[j],2,gregexpr("k",otherNeurons[j])[[1]][1]-2)
    pdf(file=paste(filePathName,"connectivity_n",currentNeuron,".pdf",sep=""),width=dev.size()[1],height=dev.size()[2])
    plot(seq(binSize,tau_N_connect,binSize),exp(bas_connect %*% coeff_connectivity[seq(j,j+nBases_connectivity-1)]),type="l",
         xlab="lag (s)",ylab = paste("firing rate n",mainNeuron,sep=""),main=paste("n",mainNeuron," <- n",currentNeuron,sep=""),
         ylim = c(0,max(exp(bas_hist %*% coeff_history))),xlim=c(0,tau_N_hist))
    abline(h=1,lty=2)
    dev.off()
  }
}

plotAndSaveEffects(model_n1_lasso_cv,
                   filePathName = "/Volumes/harisf/master/figures/bases/untitled folder 2/",
                   mainNeuron = 1,nBases_history = 10, nBases_connectivity = 4)






