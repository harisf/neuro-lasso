setwd("/home/shomea/h/harisf/master/data/variables")
#print(getwd())
#setwd("/Volumes/harisf/master/data")
lassoData = readRDS("lassoData.rds")

#library(glmnet)
#library(parallel)
library(boot)

bootStatistic = function(lassoData,indices){
  d = lassoData[indices,] # allow boot to select data samples
  model_lasso_cv = cv.glmnet(x = as.matrix(d[,-1]),y = as.factor(d[,1]),
                             family = "binomial",alpha = 1)
  return(coef(model_lasso_cv,s="lambda.min"))
}

# bootStatistic2 = function(d,freq){
#   #d = lassoData[indices,] # allow boot to select data samples
#   library(glmnet)
#   require(doMC)
#   registerDoMC(cores=10)
#   model_lasso_cv = cv.glmnet(x = as.matrix(d[,-1]),y = as.factor(d[,1]),
#                              family = "binomial",alpha = 1,weights = freq,parallel = T)
#   #return(c(as.numeric(model_lasso_cv$lambda.min),as.numeric(coef(model_lasso_cv,s="lambda.min"))))
#   return(coef(model_lasso_cv,s="lambda.min"))
# }

#no_cores = detectCores()

# METHOD 1: use parallel-argument of boot
startTime = Sys.time()
bootResults1 = boot(data = lassoData, statistic = bootStatistic, R=100,
                    parallel = "multicore", ncpus = 10, stype = "i")
print(Sys.time() - startTime)
#str(bootResults1)
saveRDS(bootResults1,"bootResults2.rds")

# # # METHOD 2: run boot on pre-defined clusters
# cl = makeCluster(no_cores)
# clusterEvalQ(cl, library(boot))
# clusterEvalQ(cl, library(glmnet))
# clusterExport(cl, c("lassoData", "bootStatistic"))
# 
# startTime = Sys.time()
# bootResults2 = clusterEvalQ(cl, boot(data = lassoData, statistic = bootStatistic, R=10))
# Sys.time() - startTime
# 
# stopCluster(cl)
# 
# # 
# # 
# # 
# # # using mc
# run = function(...){
#   library(boot)
#   boot(data = lassoData, statistic = bootStatistic, R=4)
# }
# # mc = detectCores() - 1
# # bootResults3 = do.call(c, mclapply(seq_len(mc), run) )
# 
# 
# 
# 
# cl <- makeCluster(no_cores)
# clusterEvalQ(cl, library(glmnet))
# clusterExport(cl, c("lassoData", "bootStatistic"))
# library(boot) # needed for c() method on master
# 
# startTime = Sys.time()
# bootResults3 <- do.call(c, parLapply(cl, seq_len(no_cores), run) )
# Sys.time() - startTime
# 
# stopCluster(cl)
# 
# 

# to run scriptName on 6 processor: 
# mpiexec -n 6 R -f scriptName.R
# mpiexec -n 25 R -f glmnetBootstrap_parallel3.R
