setwd("/home/shomea/h/harisf/master/data/variables")
lassoData = readRDS("lassoData.rds")

library(glmnet)
library(boot)

bootStatistic = function(lassoData,indices){
  d = lassoData[indices,] # allow boot to select data samples
  
  # THIS DOES NOT WORK
  model_glm = glm(y ~ x, family = "binomial")
  return(coefficients(model_glm))
  
  # THIS DOES NOT WORK
  # model_lasso_cv = cv.glmnet(x = as.matrix(d[,-1]),y = as.factor(d[,1]),
  #                            family = "binomial",alpha = 1)
  # return(coef(model_lasso_cv,s="lambda.min"))
  
  # THIS WORKS
  # return(colMeans(d))
}

#no_cores = detectCores()


bootResults = boot(data = lassoData, statistic = bootStatistic, R=100,
                   parallel = "multicore", ncpus = 10, stype = "i")

saveRDS(bootResults,"bootResults.rds")
