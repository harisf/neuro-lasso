library(foreach)
library(doParallel)

no_cores = detectCores()-1
registerDoParallel(no_cores)

N = 156499
bootSample = sample(x=N,size=N,replace=T)
# wts = rep(0,N)
# for(i in seq(1,N))
#   wts[i] = sum(bootSample==i)

wts = foreach(index = 1:N,
              .combine = c) %dopar%
  sum(bootSample==index)
  # wts[index] = sum(bootSample==index)


stopImplicitCluster()

setwd("/home/shomea/h/harisf/master/data/variables")
saveRDS(wts,"wts.rds")

# base <- 2
# cl<-makeCluster(2)
# registerDoParallel(cl)
# test = foreach(exponent = 2:4,
#         .combine = c)  %dopar%
#   base^exponent
# stopCluster(cl)