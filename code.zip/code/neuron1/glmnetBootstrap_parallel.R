# read data
setwd("/Volumes/harisf/master/data")
#setwd("\\\\sambaad.stud.ntnu.no/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

rm(list=setdiff(ls(), c("data")))

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
# trials_correctR = which(data$obj[[8]][1,] == 1)
# trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# # get trials where there was a correct LEFT lick 
# trials_correctL = which(data$obj[[8]][2,] == 1)
# trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]


discretizeSpikeData = function(neuron,TRIALS,binSize=0.01,tau_N=NA){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  if(!is.na(tau_N)){
    M = floor(tau_N / binSize) # number of bins we go back
    mat_j = cbind(mat_j,matrix(NA,nrow=dim(mat_j)[1],ncol=M))
  }
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]-lickOnset
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    if(!is.na(tau_N)){
      for(m in seq(1,M)){
        mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
        #mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
      }
    }
    
    mat = rbind(mat,mat_j)
  }
  
  if(!is.na(tau_N)){
    cnames = c()
    for(m in seq(1,M)){
      cnames = c(cnames,paste("spikeCountj",neuron,"m",m,sep = ""))
    }
    colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""),cnames)
  } else
    colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""))
  df = as.data.frame(mat)
  return(df)
}

discretizeAndAlignSpikeData = function(mainNeuron,TRIALS,binSize=0.01){
  spikeData_mainNeuron = discretizeSpikeData(mainNeuron,TRIALS,binSize)
  
  otherNeurons = setdiff(seq(1,30),mainNeuron)
  spikeData_otherNeurons = matrix(NA,nrow=dim(spikeData_mainNeuron)[1],ncol=29)
  
  colnamesTxt = NULL
  timeInterval = seq(0,5,binSize)
  for(i in seq(1,29)){
    neuron = otherNeurons[i]
    eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
    eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
    
    for(trial_j in unique(spikeData_mainNeuron$trialId)){
      trialStartTime_j = data$obj[[7]][1,trial_j]
      eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
      
      spikeData_otherNeurons[which(spikeData_mainNeuron$trialId == trial_j),i] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
      
    }
    colnamesTxt = c(colnamesTxt,paste("spikeCountj",neuron,sep = ""))
  }
  colnames(spikeData_otherNeurons) = colnamesTxt
  
  return(as.data.frame(cbind(spikeData_mainNeuron,spikeData_otherNeurons)))
  
}

getBasis2 = function(nBases,binSize){
  b = binSize*5
  peaks = c(binSize,binSize*50)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}

weightedSpikeData = function(spikeData,nBases_history,nBases_connectivity,binSize=0.01){
  bas_hist = getBasis2(nBases_history,binSize)$bas_orth
  bas_connect = getBasis2(nBases_connectivity,binSize)$bas_orth
  
  #history
  basisWeights = matrix(NA,nrow=dim(spikeData)[1]-1,ncol=nBases_history)
  for(k in seq(1,dim(bas_hist)[2])){
    basisWeights[,k] = convolve(c(0,spikeData[,3]),rev(bas_hist[,k]),type="open")[2:dim(spikeData)[1]]
  }
  
  txt=NULL
  for(k in seq(1,nBases_history)){
    txt = c(txt,paste(sub("spikeCount","",colnames(spikeData)[3]),".k",k,sep=""))
  }
  colnames(basisWeights) = txt
  
  spikeData_basis = cbind(spikeData[-1,seq(1,3)],basisWeights) #when using convolution
  colnames(spikeData_basis)[1:3] = colnames(spikeData)[1:3]
  spikeData_basis = as.data.frame(spikeData_basis)
  
  #connectivity
  for(j in seq(4,dim(spikeData)[2])){
    basisWeights = matrix(NA,nrow=dim(spikeData)[1]-1,ncol=nBases_connectivity)
    for(k in seq(1,dim(bas_connect)[2])){
      basisWeights[,k] = convolve(c(0,spikeData[,j]),rev(bas_connect[,k]),type="open")[2:dim(spikeData)[1]]
    }
    
    txt=NULL
    for(k in seq(1,nBases_connectivity)){
      txt = c(txt,paste(sub("spikeCount","",colnames(spikeData)[j]),".k",k,sep=""))
    }
    colnames(basisWeights) = txt
    
    spikeData_basis = cbind(spikeData_basis,basisWeights)
    
  }
  
  return(spikeData_basis)
  
}

binSize = 0.01

spikeData = discretizeAndAlignSpikeData(mainNeuron = 1,trials.good,binSize)
#str(spikeData)

spikeData_basis = weightedSpikeData(spikeData,
                                    nBases_history = 10,
                                    nBases_connectivity = 4,binSize)
#str(spikeData_basis)


# prediction matrix of lasso model, with poly(lickOnset) of deg = 5
deg = 5
predMat = cbind(spikeData_basis[,-c(1,2,3)],poly(spikeData_basis$lickOnset,degree = deg))
txtPolyname = NULL
for(i in seq(1,deg))
  txtPolyname = c(txtPolyname,paste("poly(lickOnset)",i,sep = ""))
colnames(predMat)[seq(dim(predMat)[2]-deg+1,dim(predMat)[2])] = txtPolyname

library(glmnet)

# bootstrap using library(boot)
library(boot)
library(parallel)

#lassoData = as.data.frame(y = as.factor(spikeData_basis[,3]),x = as.matrix(predMat))
lassoData = cbind(spikeData_basis[,3],predMat)
saveRDS(lassoData,"lassoData2.rds")

bootStatistic = function(lassoData,indices){
  d = lassoData[indices,] # allow boot to select data samples
  model_lasso_cv = cv.glmnet(x = as.matrix(d[,-1]),y = as.factor(d[,1]),
                             family = "binomial",alpha = 1)
  return(c(as.numeric(model_lasso_cv$lambda.min),as.numeric(coef(model_lasso_cv,s="lambda.min"))))
}

#no_cores = detectCores() - 1
#no_cores = detectCores() 
#cl = makeCluster(no_cores, type="FORK")
startTime = Sys.time()
bootResults = boot(data = lassoData,statistic = bootStatistic,R=2)
                   #parallel = "snow",ncpus = 4,cl=cl)
#stopCluster(cl)
Sys.time() - startTime

boxplot(bootResults$t)
plot(bootResults,index=1)



#startTime = Sys.time()
model_lasso = glmnet(x = as.matrix(predMat),as.factor(spikeData_basis[,3]),
                           family = "binomial",alpha = 1)
as.numeric(coef(model_lasso)[,10])
#Sys.time() - startTime



# bootstrap
B = 1000
N = dim(spikeData_basis)[1]
boot.coef = matrix(NA,ncol = (1+dim(predMat)[2]),nrow = B)
colnames(boot.coef) = c("(Intercept)",colnames(predMat))
boot.cvm = list()
boot.lambda = list()
boot.lambdaMin = c()
for(b in seq(1,B)){
  bootSample = sample(x=N,size=N,replace=T)
  wts = rep(0,N)
  for(i in seq(1,N)) 
    wts[i] = sum(bootSample==i)
  
  model_lasso_cv = cv.glmnet(x = as.matrix(predMat),y = as.factor(spikeData_basis[,3]),
                             family = "binomial",alpha = 1,weights = wts)
  boot.coef[b,] = coef(model_lasso_cv,s="lambda.min")
  boot.cvm[[b]] = model_lasso_cv$cvm
  boot.lambda[[b]] = model_lasso_cv$lambda
  boot.lambdaMin = c(boot.lambdaMin,model_lasso_cv$lambda.min)
}

wts = lapply(bootSample,function(x){length(which(bootSample == x))})

bootSample = sample(x=N,size=N,replace=T)
sum(bootSample==bootSample[6])
test = hist(bootSample,breaks = N)$counts
str(test$counts)

bootSample = sample(x=10,size=10,replace=T)
as.vector(table(cut(bootSample,breaks=seq(0,10))))
hist(bootSample,breaks = 11)$counts

counts = table(bootSample)
table(bootSample[3])
as.numeric(table(bootSample)[which(bootSample[3] == names(counts))])

test = as.matrix(predMat)
str(test)

bootSample = sample(x=N,size=N,replace=T)
counts = table(bootSample)
test = as.character(bootSample)
counts[grep(test[1],names(counts))]

wts = sapply(bootSample,function(x){as.numeric(counts[which(x == names(counts))])})
wts = sapply(bootSample,function(x){as.numeric(counts[grep(x,names(counts))])})

# pdf(file="/Volumes/harisf/master/figures/bases/neuron1_final/cvLambda.pdf",width=dev.size()[1],height=dev.size()[2])
# plot(model_lasso_cv)
# dev.off()
# coef(model_lasso_cv,s="lambda.min")



################
# PARALLEL
################
library(parallel)

# basic workflow
no_cores = detectCores() - 1
cl = makeCluster(no_cores, type="FORK")
wts = parSapply(cl,bootSample,function(x){as.numeric(counts[which(x == names(counts))])})
stopCluster(cl)



library(parallel)
library(boot)

bootStatistic = function(lassoData,indices){
  d = lassoData[indices,] # allow boot to select data samples
  model_lasso_cv = cv.glmnet(x = as.matrix(d[,-1]),y = as.factor(d[,1]),
                             family = "binomial",alpha = 1)
  return(c(as.numeric(model_lasso_cv$lambda.min),as.numeric(coef(model_lasso_cv,s="lambda.min"))))
}

no_cores = detectCores()
# METHOD 1: use parallel-argument of boot
startTime = Sys.time()
bootResults1 = boot(data = lassoData, statistic = bootStatistic, R=1000,
                   parallel = "multicore", ncpus = no_cores)
Sys.time() - startTime

# METHOD 2: run boot on pre-defined clusters
cl = makeCluster(no_cores)
clusterEvalQ(cl, library(boot))

startTime = Sys.time()
bootResults2 = clusterEvalQ(cl, boot(data = lassoData, statistic = bootStatistic, R=1000))
Sys.time() - startTime

stopCluster(cl)








