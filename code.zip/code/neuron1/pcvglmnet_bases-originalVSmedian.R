library(glmnet)

setwd("/Volumes/harisf/master/data/variables/modelFit")
lassoModel10ms_medianBases = readRDS("fitLasso_n1_b10ms_medianBases.rds")
lassoModel1ms_fullBases = readRDS("fitLasso_n1_b1ms_newAdjustedBases.rds")

coef(lassoModel1ms_fullBases,s="lambda.min")
coef(lassoModel10ms_medianBases,s="lambda.min")

getBasis2 = function(nBases,binSize){
  #b = binSize*5
  #peaks = c(binSize,binSize*50)
  b = binSize*nBases
  peaks = c(binSize,binSize*10*nBases)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}
getMedianBasis = function(nBases,binSize_original,binSize_median){
  
  bas_original = getBasis2(nBases,binSize = binSize_original)
  
  pointsToCombine = binSize_median / binSize_original
  totalCombinedPoints = floor(dim(bas_original$bas)[1] / pointsToCombine)
  
  indexes = list()
  for(i in seq(0,totalCombinedPoints - 1))
    indexes = c(indexes,list(seq(1,pointsToCombine) + pointsToCombine * i))
  
  # numberOfRemainingPoints = dim(bas$bas)[1] %% pointsToCombine
  # THESE LAST POINTS ARE DISCARDED
  # if(numberOfRemainingPoints != 0)
  #   indexes = c(indexes,list(seq(1,numberOfRemainingPoints) + indexes[[totalCombinedPoints]][pointsToCombine]))
  
  binSize_median = list(bas = matrix(NA,ncol = dim(bas_original$bas)[2],nrow = length(indexes)), 
                        bas_orth = matrix(NA,ncol = dim(bas_original$bas)[2],nrow = length(indexes)),
                        tau_N = bas_original$tau_N)
  for(i in seq(1,length(indexes))){
    binSize_median$bas[i,] = bas_original$bas[floor(median(indexes[[i]])),]
    binSize_median$bas_orth[i,] = bas_original$bas_orth[floor(median(indexes[[i]])),]
  }
  binSize_median
}

mainNeuron = 1
nBases_history = 10

bas_hist_list_1ms = getBasis2(nBases_history,binSize = 0.001)
# bas_hist1ms = bas_hist_list$bas_orth
# tau_N_hist1ms = bas_hist_list$tau_N

bas_hist_list_10ms = getMedianBasis(nBases_history,binSize_original = 0.001,
                                    binSize_median = 0.01)
# bas_hist10ms = bas_hist_list$bas_orth
# tau_N_hist10ms = bas_hist_list$tau_N

#cvfit1ms = fit
#cvfit10ms = fit_medianBases

invLink = function(x){exp(x)/(1+exp(x))}

pdf(file="/Volumes/harisf/master/figures/bases/history_b1msFullBasesVSb10msMedianBases2_pvalues.pdf",
    width = dev.size()[1], height = dev.size()[2])
par(mfrow=c(1,2))
for(i in seq(1,2)){
  bas_hist_list = list(bas_hist_list_1ms,bas_hist_list_10ms)[[i]]
  bas_hist = bas_hist_list$bas_orth
  tau_N_hist = bas_hist_list$tau_N
  binSize = c(0.001,0.01)[i]
  
  cvfit = list(lassoModel1ms_fullBases,lassoModel10ms_medianBases)[[i]]
  
  coeff_intercept = coef(cvfit, s = "lambda.min")[1]
  coeff_history = coef(cvfit, s = "lambda.min")[2:(nBases_history+1)]
  
  maintxt = c("binsize 1 ms full bases","binsize 10 ms median bases")[i]
  #maintxt = paste("history n",mainNeuron,sep="")
  
  plot(seq(binSize,tau_N_hist,binSize),invLink(bas_hist %*% coeff_history+coeff_intercept),type="b",
       xlab="lag (s)",ylab = paste("firing prob. n",mainNeuron,sep=""),main=maintxt,
       ylim = c(0,max(invLink(bas_hist %*% coeff_history + coeff_intercept))))
  abline(h=invLink(coeff_intercept),lty=2)
}
# the three first history effects in the last model are significant (p-values < 0.05)
# setwd("/Volumes/harisf/master/data/variables/hdi")
# fitMultiSplit = readRDS("fitMultisplit_n1_b10ms_medianBases.rds")
# points(seq(binSize,binSize*3,binSize),invLink(bas_hist %*% coeff_history+coeff_intercept)[1:3],pch=16)
dev.off()


nBases_connectivity = 4
bas_connect_list = getBasis2(nBases_connectivity,0.001)
bas_connect = bas_connect_list$bas_orth
tau_N_connect = bas_connect_list$tau_N

coeff_intercept = coef(fit, s = "lambda.min")[1]
j = 5 # neighbour
coeff_connect = coef(fit, s = "lambda.min")[(1:nBases_connectivity)+(nBases_history+1)+nBases_connectivity*(j-2)]
plot(seq(0.001,tau_N_connect,0.001),invLink(bas_connect %*% coeff_connect+coeff_intercept),type="b",
     xlab="lag (s)",ylab = paste("firing prob. n",mainNeuron,sep=""),main="n1 <- n5",
     ylim = c(0,max(invLink(bas_hist %*% coeff_history + coeff_intercept))))
abline(h=invLink(coeff_intercept),lty=2)



#setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
setwd("/Volumes/harisf/master/data/variables/modelMatrix")
modelMatrix = readRDS("n1_b1ms_newAdjustedBases3.rds")

coeff_lickonset = coef(fit,s="lambda.min")[(-4:0)+length(coef(fit,s="lambda.min"))]

plot(seq(0.001,5,0.001)[-1],invLink(modelMatrix[1:4999,128:132] %*% coeff_lickonset+coeff_intercept),type="b",
     xlab="lag (s)",ylab = paste("firing prob. n",mainNeuron,sep=""),main="lickonset")#,
     #ylim = c(0,max(invLink(bas_hist %*% coeff_history + coeff_intercept))))
abline(h=invLink(coeff_intercept),lty=2)




