library(R.matlab)
library(foreach)
library(STAR)

setwd("/Volumes/harisf/master/data")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

#data = data3
totalNumberOfNeurons = length(data$obj[[12]][[1]])

eventTimesLIST = foreach(neuron = seq(1,totalNumberOfNeurons)) %do% {
  data$obj[[12]][[3]][[neuron]][[1]][[2]]
}
#str(eventTimesLIST)


# aspectRatio = 1.2 # height / width
# plotHeight = totalNumberOfNeurons / 3
# plotWidth = plotHeight /aspectRatio

#s1
# plotHeight = 8.787719+1
# plotWidth = 6.236842

#s2
# plotHeight = 5.736842
# plotWidth = 5.921053

#s3
plotHeight = 5.017544
plotWidth = 5.035088

pdf(file="/Volumes/harisf/master/figures/cellActivity/session3.pdf",
    width = plotWidth, height = plotHeight)
plot(as.repeatedTrain(eventTimesLIST),ylab="Cell",xlab="Session time (s)",pch="|",
     main="Session 3")
dev.off()
