#setwd("/home/shomea/h/harisf/master/data")
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data1 = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")
metaData1 = readMat("data_structure_ANM210861/meta_data_ANM210861_20130701.mat")
data2 = readMat("data_structure_ANM210861/data_structure_ANM210861_20130702.mat")
metaData2 = readMat("data_structure_ANM210861/meta_data_ANM210861_20130702.mat")
data3 = readMat("data_structure_ANM210861/data_structure_ANM210861_20130703.mat")
metaData3 = readMat("data_structure_ANM210861/meta_data_ANM210861_20130703.mat")

data.allsessons = list(data1,data2,data3)
metaData.allsessons = list(metaData1,metaData2,metaData3)

#rm(list=setdiff(ls(), c("data","metaData")))

totalNumberOfNeurons = c(length(data1$obj[[12]][[1]]),
                         length(data2$obj[[12]][[1]]),
                         length(data3$obj[[12]][[1]]))

library(foreach)
channels.allsessons = foreach(session = seq(1,3)) %do% {
  data = data.allsessons[[session]]
  channels = list()
  for(neuron in seq(1,totalNumberOfNeurons[session])){
    channels[[neuron]] = as.vector(unique(data$obj[[12]][[3]][[neuron]][[1]][[5]]))
  }
  channels
}
str(channels.allsessons)

locations.allsessons = foreach(session = seq(1,3)) %do% {
  metaData = metaData.allsessons[[session]]
  locations = matrix(NA,ncol=2,nrow=32)
  for(ch in seq(1,32)){
    locations[ch,] = metaData$meta.data["extracellular",1,1]$extracellular["siteLocations",1,1]$siteLocations[[ch]][[1]][1,2:3]
  }
  locations
}

printChannels = function(sesson){
  channels = channels.allsessons[[session]]
  for(neuron in seq(1,totalNumberOfNeurons[session])){
    cat(neuron,": ",sep="")
    for(ch in channels[[neuron]])
      cat(ch," ",sep="")
    cat("\n")
  }
}
printChannels(3)

plotNeuronsOnSiteLocations = function(session){
  locations = locations.allsessons[[session]]
  channels = channels.allsessons[[session]]
  
  plot(locations[,1],locations[,2],xlab="",ylab="",main=paste("Session",session),col="blue",pch=19,xaxt="n",yaxt="n",bty="n",
       xlim=c(-1.8-0.1,-1.2+0.1))
  #text(locations[1:16,1],locations[1:16,2],seq(1,16),pos=2,col="red")
  #text(locations[17:32,1],locations[17:32,2],seq(17,32),pos=4,col="red")
  
  if(session == 1){
    neuron = 1
    for(channel in channels){
      for(ch in channel){
        if(ch == 3 && neuron == 20)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 5 && neuron == 26)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 5 && neuron == 28)
          text(locations[ch,1]+0.05,locations[ch,2],neuron,pos=4)
        else if(ch == 6 && neuron == 2)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 9 && neuron == 3)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 12 && neuron == 7)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 13 && neuron == 8)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 19 && neuron == 13)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 25 && neuron == 14)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 28 && neuron == 21)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 29 && neuron == 17)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 30 && neuron == 22)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 30 && neuron == 24)
          text(locations[ch,1]+0.05,locations[ch,2],neuron,pos=4)
        else
          text(locations[ch,1],locations[ch,2],neuron,pos=4)
      }
      neuron = neuron + 1
    }
  }
  
  if(session == 2){
    neuron = 1
    for(channel in channels){
      for(ch in channel){
        if(ch == 9 && neuron == 2)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 20 && neuron == 5)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 19 && neuron == 1)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else 
          text(locations[ch,1],locations[ch,2],neuron,pos=4)
      }
      neuron = neuron + 1
    }
  }
  
  if(session == 3){
    neuron = 1
    for(channel in channels){
      for(ch in channel){
        if(ch == 3 && neuron == 1)
          text(locations[ch,1]-0.05,locations[ch,2],neuron,pos=2)
        else if(ch == 3 && neuron == 5)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 3 && neuron == 7)
          text(locations[ch,1]+0.05,locations[ch,2],neuron,pos=4)
        else if(ch == 28 && neuron == 2)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else if(ch == 28 && neuron == 11)
          text(locations[ch,1]+0.05,locations[ch,2],neuron,pos=4)
        else if(ch == 29 && neuron == 3)
          text(locations[ch,1],locations[ch,2],neuron,pos=2)
        else 
          text(locations[ch,1],locations[ch,2],neuron,pos=4)
      }
      neuron = neuron + 1
    }
  }
  
  

}

plotNeuronsOnSiteLocations(3)


pdf(file="/Volumes/harisf/master/figures/location/neuronsOnSite-allsessions.pdf",
    width = 9.587719, height = 3.736842)
    #width = 11.228070,height = 3.561403)
par(mfrow=c(1,3))
plotNeuronsOnSiteLocations(1)
plotNeuronsOnSiteLocations(2)
plotNeuronsOnSiteLocations(3)
dev.off()

session=3
pdf(file=paste("/Volumes/harisf/master/figures/location/neuronsOnSite-session",session,".pdf",sep=""),
    width = 5.385965, height = 5.868421)
par(mfrow=c(1,1))
plotNeuronsOnSiteLocations(session)
dev.off()

pdf(file="/Volumes/harisf/master/figures/location/siteLocations.pdf",
    width = 5.385965, height = 5.868421)
locations = locations.allsessons[[1]]
plot(locations[,1],locations[,2],xlab="",ylab="",main="Site locations",col="blue",pch=19,#,xaxt="n",yaxt="n",#bty="n",
     xlim=c(-1.8-0.1,-1.2+0.1))
text(locations[,1],locations[,2],seq(1,32),pos=4,col="blue")
dev.off()




