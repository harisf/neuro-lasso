setwd("/home/shomea/h/harisf/master/data/variables")
#setwd("/Volumes/harisf/master/data/variables")
#lassoData = readRDS("lassoData.rds")
lassoData = readRDS("evaluatedData_n1_b10ms.rds")

library(Matrix)

lassoData.Mat = Matrix(as.matrix(lassoData))
x = lassoData.Mat[,-1]
y = lassoData.Mat[,1]

pdf(file = "/Volumes/harisf/master/figures/evaluatedData/predMatColumns121-131.pdf",
    width = dev.size()[1],height = dev.size()[2])
par(mfrow=c(3,5))
j = 8
for(i in seq(1,11)){
  if(i == 1) {
    plot(sort(x[,i+(15*j)],decreasing = T),type="l",xlab = "index",ylab="value",main=paste("col. ",i+(15*j),sep = ""))
    abline(h=0,lty=2)
  }
  else {
    plot(sort(x[,i+(15*j)],decreasing = T),type="l",xlab = "",ylab = "",main=paste("col. ",i+(15*j),sep = ""),xaxt="n")
    abline(h=0,lty=2)
  }
}
dev.off()

tol = 1e-8
x.sparse = x
for(i in seq(1,dim(x)[2])){
  x.sparse[which(abs(x[,i]) < tol),i] = 0
}

pdf(file = "/Volumes/harisf/master/figures/evaluatedData/xsparse_tol1e-8.pdf",
    width = dev.size()[1],height = dev.size()[2])
par(mfrow=c(2,5))
COLS = sample(seq(1,131),size=5,replace = F)
for(i in COLS){
  plot(sort(x[,i],decreasing = T),type="l",xlab = "",ylab = "",main=paste("x[,",i,"]",sep=""))
  abline(h=0,lty=2)
}
for(i in COLS){
  plot(sort(x.sparse[,i],decreasing = T),type="l",xlab = "",ylab = "",main=paste("x.sparse[,",i,"]",sep=""))
  abline(h=0,lty=2)
}
dev.off()


y.sparsed = Matrix(y,sparse = TRUE)
x.sparsed = Matrix(x.sparse,sparse = TRUE)
object.size(x)
object.size(x.sparse)
object.size(x.sparsed)

object.size(y)
object.size(y.sparsed)
