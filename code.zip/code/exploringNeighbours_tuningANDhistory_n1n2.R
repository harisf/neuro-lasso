# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

rm(list=setdiff(ls(), c("data")))

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
# trials_correctR = which(data$obj[[8]][1,] == 1)
# trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# # get trials where there was a correct LEFT lick 
# trials_correctL = which(data$obj[[8]][2,] == 1)
# trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]

startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials.good]),na.rm=TRUE)
startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials.good]),na.rm=TRUE)
startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE) # aka lickOnset


discretizeSpikeData = function(neuron,TRIALS,binSize=0.01,tau_N=NA){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  mat = NULL
  mat_j = matrix(0,ncol=3,nrow=length(timeInterval)-1)
  
  if(!is.na(tau_N)){
    M = tau_N / binSize # number of bins we go back
    mat_j = cbind(mat_j,matrix(NA,nrow=dim(mat_j)[1],ncol=M))
  }
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]-lickOnset
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    if(!is.na(tau_N)){
      for(m in seq(1,M)){
        mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
      }
    }
    
    mat = rbind(mat,mat_j)
  }
  
  if(!is.na(tau_N)){
    cnames = c()
    for(m in seq(1,M)){
      cnames = c(cnames,paste("spikeCountj",neuron,"m",m,sep = ""))
    }
    colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""),cnames)
  } else
    colnames(mat) = c("trialId","lickOnset","spikeCount")
  df = as.data.frame(mat)
  return(df)
}

binSize = 0.01
tau_N = 0.12
spikes_n1 = discretizeSpikeData(1,trials.good,binSize,tau_N)
spikes_n2 = discretizeSpikeData(2,trials.good,binSize,tau_N)
#spikes_n12 = discretizeSpikeData(12,trials.good,binSize,tau_N)
#spikes_n16 = discretizeSpikeData(16,trials.good,binSize,tau_N)

head(spikes_n12)

# history effects neuron 1
model_history = glm(formula = spikeCountj1 ~ . - trialId - lickOnset,
                    data = spikes_n1, family = "poisson")
summary(model_history)
plot(seq(0,tau_N,binSize),coefficients(model_history),type = "l",
     main="neuron 1 history",ylab="alpha",xlab="lag (s)")
lines(seq(0,tau_N,binSize),coefficients(model_history) + 2*sqrt(diag(summary(model_history)$cov.unscaled)),lty=2)
lines(seq(0,tau_N,binSize),coefficients(model_history) - 2*sqrt(diag(summary(model_history)$cov.unscaled)),lty=2)

# tuning curve neuron 1
library(mgcv)
model_tuning = gam(formula = spikeCountj1 ~ s(lickOnset),
                   data = spikes_n1, family = "poisson")
plot(model_tuning,se=T,rug=F,
     main="neuron 1 stimulus",xlab="lick onset (s)")
abline(v=startOfSampleEpoch,lty=1,col="gray")
abline(v=startOfDelayEpoch,lty=1,col="gray")
abline(v=startOfResponseEpoch,lty=1,col="gray")

# tuning curve + history effects neuron 1
txtFormula = "spikeCountj1 ~ s(lickOnset)"
for(m in seq(1,dim(spikes_n1)[2]-3)){
  txtFormula = paste(txtFormula," + spikeCountj1m",m,sep = "")
}
model_tuningHistory = gam(formula = as.formula(txtFormula),
                          data = spikes_n1, family = "poisson")
summary(model_tuningHistory)

#pdf(file="/Volumes/harisf/master/figures/history/stimulusAndHistory_neuron1.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(1,2))
plot(model_tuningHistory,se=T,rug=F,main="neuron 1 stimulus",xlab="lick onset (s)")
abline(v=startOfSampleEpoch-startOfResponseEpoch,lty=1,col="gray")
abline(v=startOfDelayEpoch-startOfResponseEpoch,lty=1,col="gray")
abline(v=0,lty=1,col="gray")

plot(seq(0,tau_N,binSize),coefficients(model_tuningHistory)[1:13],type="l",
     main="neuron 1 history",ylab="alpha",xlab="lag (s)")
lines(seq(0,tau_N,binSize),coefficients(model_tuningHistory)[1:13] + 2* summary(model_tuningHistory)$se[1:13],lty=2)
lines(seq(0,tau_N,binSize),coefficients(model_tuningHistory)[1:13] - 2* summary(model_tuningHistory)$se[1:13],lty=2)
#dev.off()



# coupling between neuron 1 and 2
model_j1j1 = glm(spikeCountj1 ~. - trialId - lickOnset,
                 data = spikes_n1, family = "poisson")
model_j2j2 = glm(spikeCountj2 ~. - trialId - lickOnset,
                 data = spikes_n2, family = "poisson")


spikes_n1n2 = cbind(spikes_n1,subset(spikes_n2,select = -c(1,2)))
model_j1j2 = glm(spikeCountj1 ~. - trialId - lickOnset,
                 data = spikes_n1n2, family = "poisson")
model_j2j1 = glm(spikeCountj2 ~. - trialId - lickOnset,
                 data = spikes_n1n2, family = "poisson")

summary(model_j2j1)

pdf(file="/Volumes/harisf/master/figures/coupling/j1j2.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(2,2))
plot(seq(0,tau_N,binSize),coefficients(model_j1j1),type = "l",
     main = "Target: J1, Trigger: J1",xlab="lag (s)",ylab="alpha")
plot(seq(0,tau_N,binSize),coefficients(model_j1j2)[14:26],type = "l",
     main = "Target: J1, Trigger: J2",xlab="lag (s)",ylab="alpha")
plot(seq(0,tau_N,binSize),coefficients(model_j2j1)[2:14],type = "l",
     main = "Target: J2, Trigger: J1",xlab="lag (s)",ylab="alpha")
plot(seq(0,tau_N,binSize),coefficients(model_j2j2),type = "l",
     main = "Target: J2, Trigger: J2",xlab="lag (s)",ylab="alpha")
dev.off()


# check the model parameters from this model
model_j1j2_NEW = glm(spikeCountj1 ~. - trialId - lickOnset,
                     data = spikes_n2, family = "poisson")


















# par(mfrow=c(2,2))
# plot(model_tuning,se=T,rug=F,
#      main="neuron 1 stimulus",xlab="trial time (s)")
# abline(v=startOfSampleEpoch,lty=1,col="gray")
# abline(v=startOfDelayEpoch,lty=1,col="gray")
# abline(v=startOfResponseEpoch,lty=1,col="gray")
# 
# plot(seq(0,tau_N,binSize),coefficients(model_history),type = "l",
#      main="neuron 1 history",ylab="alpha",xlab="lag (s)")
# lines(seq(0,tau_N,binSize),coefficients(model_history) + 2*sqrt(diag(summary(model_history)$cov.unscaled)),lty=2)
# lines(seq(0,tau_N,binSize),coefficients(model_history) - 2*sqrt(diag(summary(model_history)$cov.unscaled)),lty=2)
# 
# plot(model_tuningHistory,terms = "s(trialTime)",se=T,rug=F,
#      main="neuron 1 stimulus + history",xlab="trial time (s)")
# abline(v=startOfSampleEpoch,lty=1,col="gray")
# abline(v=startOfDelayEpoch,lty=1,col="gray")
# abline(v=startOfResponseEpoch,lty=1,col="gray")
# 
# plot(seq(0,tau_N,binSize),coefficients(model_tuningHistory)[-c(2,3)],type = "l",
#      main="neuron 1 stimulus + history",ylab="alpha",xlab="lag (s)")



# consider modelling couplings between neuron 1 and neuron 2
head(cbind(spikes_n1,subset(spikes_n2,select = -c(1,2))))

#spikes_n1_pruned = spikes_n1[-seq(1,12),]



txtFormula = "spikeCountj2 ~ spikeCountj2m1"
for(m in seq(2,dim(spikes_n2)[2]-3)){
  txtFormula = paste(txtFormula," + spikeCountj2m",m,sep = "")
}
txtFormula = paste(txtFormula," + spikeCountj1",sep="")
for(m in seq(1,dim(spikes_n1)[2]-3)){
  txtFormula = paste(txtFormula," + spikeCountj1m",m,sep = "")
}
txtFormula
model = glm(as.formula(sub("spikeCountj1m10 +","",txtFormula)),data = cbind(spikes_n1_pruned,subset(spikes_n2_pruned,select = -c(1,2))),family = "poisson")
summary(model)
plot(seq(0,0.12,0.01),coefficients(model)[14:26],type="l",
     ylim=c(-397,372))
lines(seq(0,0.12,0.01),coefficients(model)[14:26] + 2*sqrt(diag(summary(model)$cov.scaled)[14:26]),lty=2)
lines(seq(0,0.12,0.01),coefficients(model)[14:26] - 2*sqrt(diag(summary(model)$cov.scaled)[14:26]),lty=2)


#library(mgcv)
txtFormula = "spikeCountj2 ~ s("
for(m in seq(1,dim(spikes_n2)[2]-4)){
  txtFormula = paste(txtFormula,"spikeCountj2m",m,",",sep = "")
}
txtFormula = paste(txtFormula,"spikeCountj2m12)",sep = "")
txtFormula

model_smooth = gam(as.formula(paste("spikeCountj2 ~ s(trialTime) + ",txtFormula)),data = cbind(spikes_n1_pruned,subset(spikes_n2_pruned,select = -c(1,2))),family = "poisson")
par(mfrow=c(1,2))
plot(model_smooth,se=T,rug=F,main="neuron 2 stimulus",xlab="trial time (s)")
abline(v=startOfSampleEpoch,lty=3)
abline(v=startOfDelayEpoch,lty=3)
abline(v=startOfResponseEpoch,lty=3)
plot(seq(0,0.12,0.01),coefficients(model_smooth)[1:13],type="l",
     main = "neuron 2 history",ylab = "alpha",xlab = "lag (s)")
lines(seq(0,0.12,0.01),coefficients(model_smooth)[1:13] + 2* summary(model_smooth)$se[1:13],lty=2)
lines(seq(0,0.12,0.01),coefficients(model_smooth)[1:13] - 2* summary(model_smooth)$se[1:13],lty=2)

test = summary(model_smooth)
test$se[1:13]

spikes_n2_pruned = spikes_n2[-seq(1,12),]
model_smooth = gam(as.formula(txtFormula),data = spikes_n2_pruned,family = "poisson")  
  
  


# PLOT REFRACTORY PERIODS
# getOption("na.action") 
# default is na.omit, which removes the observations where there are mising values (NA)
model = glm(as.formula(txtFormula),data = spikes_n2,family = "poisson")

plot(seq(0,0.48,0.01),exp(coefficients(model)),type="l",
     xlab = "lag (ms)",ylab="exp(alpha)",main="History effects, neuron 2")
lines(seq(0,0.48,0.01),exp(coefficients(model)) + 2*sqrt(diag(summary(model)$cov.scaled)),
      lty=2)
lines(seq(0,0.48,0.01),exp(coefficients(model)) - 2*sqrt(diag(summary(model)$cov.scaled)),
      lty=2)






getSpikeTimes = function(neuron,trials.good){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTrials.good = is.element(eventTrials,trials.good)
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]][eventTrials.good]
  return(list(eventTimes = eventTimes,eventTrials=eventTrials[eventTrials.good]))
}

eventTimesN1 = getSpikeTimes(1, trials.good)$eventTimes
eventTimesN2 = getSpikeTimes(2, trials.good)$eventTimes
eventTimesN12 = getSpikeTimes(12, trials.good)$eventTimes

str(eventTimesN12)
acf(eventTimesN1,lag.max = 1000)
acf(eventTimesN2,lag.max = 1000)
acf(eventTimesN12,lag.max = 50000)













