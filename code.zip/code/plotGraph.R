library(igraph)
library(glmnet)

session = 2
k = 3
trialType = c("Good Trials","Left Trials", "Right Trials")[k]

totalNumberOfNeurons = c(30,16,12)[session] # session 2: total of 16 neurons, but we ignore the last 16th neuron..
neuronsProducingErrors = list(c(13,14,15,28),c(0),c(2,3,4,6,8,10,11,12))[[session]]

if(k == 1)
  setwd(paste("/Volumes/work/harisf/session",session,"/multisplit10ms",sep=""))
if(k == 2)
  setwd(paste("/Volumes/work/harisf/session",session,"/multisplit10ms_leftTrials",sep=""))
if(k == 3)
  setwd(paste("/Volumes/work/harisf/session",session,"/multisplit10ms_rightTrials",sep=""))

coef.significant = function(neuron){
  #setwd(paste("/Volumes/work/harisf/session",session,"/multisplit10ms",sep=""))
  fit = readRDS(paste("n",neuron,"_b10ms.rds",sep = ""))
  #which(fit$pval.corr < 0.001)
  which(fit$pval.corr < 0.05)
}

# for(neuron in seq(1,totalNumberOfNeurons)){
#   cat("Neuron",neuron,": ",coef.significant(neuron),"\n",sep="")
# }

# returns -1 if inhibitory connection, +1 if excitatory, 0 else
inhibitoryORexcitatory = function(edge){ # edge is a vector of length 2, describing the relation edge[1] -> edge[2]
  neuronFrom = edge[1]
  neuronTo = edge[2]
  
  if(k == 1)
    setwd(paste("/Volumes/work/harisf/session",session,"/lassoFit",sep=""))
  if(k == 2)
    setwd(paste("/Volumes/work/harisf/session",session,"/lassoFit_leftTrials",sep=""))
  if(k == 3)
    setwd(paste("/Volumes/work/harisf/session",session,"/lassoFit_rightTrials",sep=""))
  
  fit = readRDS(paste("n",neuronTo,"_b1ms.rds",sep = ""))
  
  nBases_history = 10
  nBases_connectivity = 4
  deg = 5
  
  getBasis2 = function(nBases,binSize){
    #b = binSize*5
    #peaks = c(binSize,binSize*50)
    b = binSize*nBases
    peaks = c(binSize,binSize*10*nBases)
    #peaks = c(binSize,binSize*5*nBases)
    
    # nonlinearity for stretching x axis (and its inverse)
    nlin = function(x){log(x+1e-20)}
    invnl = function(x){exp(x)-1e-20}
    
    # Generate basis of raised cosines
    yrange = nlin(peaks+b)
    db = diff(yrange)/(nBases-1)
    centers = seq(yrange[1],yrange[2],db)
    maxt = invnl(yrange[2]+2*db)-b
    iht = seq(binSize,maxt,binSize)
    nt = length(iht)
    
    raisedCosineBasis = function(x,c,dc){
      (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
    }
    
    ihbasis = matrix(NA,nrow = nt,ncol = nBases)
    for(i in seq(1,nt)){
      for(j in seq(1,length(centers))){
        ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
      }
    }
    #matplot(ihbasis,type="b",pch=seq(1,5))
    #str(ihbasis)
    
    # for plotting model coefficients
    lags = invnl(centers)-b
    
    library(pracma)
    ihbas = orth(ihbasis) # orthogonal bases
    
    return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
  }
  bas_connect = getBasis2(nBases_connectivity,binSize = 0.001)$bas_orth
  
  namesOfNeighbouringCoefs = dimnames(coef(fit, s = "lambda.min"))[[1]][(nBases_history+2):(length(coef(fit, s = "lambda.min"))-deg)]
  indexOfNeuronFrom = which(as.numeric(unname(sapply(namesOfNeighbouringCoefs,function(x){substr(x,start = 2,stop = regexpr("k",x) - 2)}))) == neuronFrom) + (nBases_history+1)
  coeff_neuronFrom = coef(fit, s = "lambda.min")[indexOfNeuronFrom]
  
  connectivityEffect = bas_connect %*% coeff_neuronFrom
  
  trapezoid = function(y){
    s  = 0
    if(length(y) == 1 || length(y) == 0)
      s
    else {
      for(i in seq(2,length(y))){
        s = s + (y[i] + y[i-1]) / 2
      }
      s
    }
  }
  
  # seq(0,3): common input
  # seq(3,15): direct input
  # seq(15,100): indirect input
  connectivityInterval = seq(3,15) # ms
  
  overBaseline.curve = connectivityEffect[connectivityInterval][which(connectivityEffect[connectivityInterval] >= 0)]
  underBaseline.curve = connectivityEffect[connectivityInterval][which(connectivityEffect[connectivityInterval] <= 0)]
  
  overBaseline.area = trapezoid(overBaseline.curve)
  underBaseline.area = trapezoid(abs(underBaseline.curve))
  
  areaDiff = overBaseline.area-underBaseline.area
  connection = sign(areaDiff)
  
  #return(list(connection = connection, arrowSize = abs(areaDiff)))
  return(c(connection,abs(areaDiff)))
}

EDGES = c()
EDGES.hist = c()
isLickOnsetSignificant_allNeurons = as.logical(rep(0,totalNumberOfNeurons))

for(neuron in seq(1,totalNumberOfNeurons)){
  fileName = paste("n",neuron,"_b10ms.rds",sep = "")
  if(file.exists(fileName)){
    
    namesOfSignifCoefs = names(coef.significant(neuron))
    
    isLickOnsetSignificant = is.element(TRUE,grepl("poly",namesOfSignifCoefs))
    if(isLickOnsetSignificant){
      namesOfSignifCoefs = namesOfSignifCoefs[!grepl("poly",namesOfSignifCoefs)] # namesOfSignifCoefs no longer contains coefficients of lickOnset
      isLickOnsetSignificant_allNeurons[neuron] = TRUE
    }
    
    indexesOfNeurons = lapply(regexpr("k",namesOfSignifCoefs) - 2,function(x) c(2,x))
    
    if(length(namesOfSignifCoefs) > 0){
      neighbours = c()
      for(i in seq(1,length(namesOfSignifCoefs)))
        neighbours = c(neighbours,substr(namesOfSignifCoefs[i],start=indexesOfNeurons[[i]][1],stop=indexesOfNeurons[[i]][2]))
      neighbours = unique(as.numeric(neighbours))
      
      isHistorySignificant = is.element(neuron,neighbours)
      if(isHistorySignificant){
        EDGES.hist = c(EDGES.hist,neuron,neuron)
        neighbours = neighbours[-match(neuron,neighbours)]
      }
      
      if(length(neighbours) > 0){
        for(i in seq(1,length(neighbours))){
          EDGES = c(EDGES,neighbours[i],neuron)
          #EDGES = c(EDGES, neuron,neighbours[i])
        }
      }
    }
  }
}

graph.withHist = make_graph(c(EDGES,EDGES.hist), directed = TRUE)
graph = make_graph(EDGES, directed = TRUE)

EDGESmat = matrix(EDGES, ncol = 2, byrow = T)
connection.list = apply(EDGESmat,MARGIN = 1,inhibitoryORexcitatory)
connection = connection.list[1,]
arrowSize = connection.list[2,]
EDGESmat = cbind(EDGESmat,connection)
colnames(EDGESmat) = c("from","to","connection")
connection_copy = connection
connection_copy[connection < 0] = 0

# for session 3:
#connection_copy = rep(3,length(EDGES)/2)


# plot graphs
neuronColorIndex = as.numeric(isLickOnsetSignificant_allNeurons)+1
neuronColorIndex[neuronsProducingErrors] = 3
neuronColorIndex.label = rep(1,totalNumberOfNeurons)
neuronColorIndex.label[neuronsProducingErrors] = 2

# gg_color_hue <- function(n) {
#   hues = seq(15, 375, length = n + 1)
#   hcl(h = hues, l = 65, c = 100)[1:n]
# }
# 
# color.inhibit = gg_color_hue(18)[1]
# color.excite = gg_color_hue(18)[7]
# color.signTuning = gg_color_hue(18)[12]

if(k == 1)
  plotFileName = paste("/Volumes/work/harisf/figures/graphs/area_directinput/newColors/session",session,".pdf",sep="")
if(k == 2)
  plotFileName = paste("/Volumes/work/harisf/figures/graphs/area_directinput/newColors/session",session,"_left.pdf",sep="")
if(k == 3)
  plotFileName = paste("/Volumes/work/harisf/figures/graphs/area_directinput/newColors/session",session,"_right.pdf",sep="")
pdf(file= plotFileName,
    width = dev.size()[1]+0.8,height = dev.size()[2])
set.seed(2)
plot(graph.withHist,main=paste("Session ",session,sep = ""),
     edge.lty=c(rep(1,length(EDGES)/2),rep(2,length(EDGES.hist)/2)),
     edge.arrow.size = 0.5,
     edge.color = c("slateblue1","violetred1","darkgrey","black")[c(connection_copy+1,rep(3,length(EDGES.hist)/2))],
     #edge.color = c("blue","red","darkgrey","black")[c(connection_copy+1,rep(3,length(EDGES.hist)/2))],
     edge.curved = FALSE,
     edge.width = c(arrowSize*0.5 / mean(arrowSize),rep(1,length(EDGES.hist)/2)),
     edge.loop.angle = c(rep(0,length(EDGES)/2),rep(2*pi,length(EDGES.hist)/2)),
     # vertex.color = c("gray","turquoise2","black")[neuronColorIndex],
     vertex.color = c("gray40","gray","black")[neuronColorIndex],
     vertex.label.color = c("black","white")[neuronColorIndex.label],
     layout = layout_in_circle) #layout_nicely (DEFAULT)/layout_with_fr, layout_in_circle, layout.grid, layout_components, layout_on_sphere, layout_randomly
if(k ==  2 || k == 3)
  mtext(trialType)
if(neuronsProducingErrors[1] == 0){
  legend("bottomleft",
         legend = c("inhibitory","excitatory","signif. tuningCurve","non-signif. tuningCurve"),
         pch = c(NA,NA,19,19), lty = c(1,1,NA,NA), 
         # col = c("slateblue1","violetred1","turquoise2","gray"),
         col = c("slateblue1","violetred1","gray","gray40"),
         bty = "n",
         cex = 0.7)
} else {
  legend("bottomleft",
         legend = c("inhibitory","excitatory","signif. tuningCurve","non-signif. tuningCurve","error: few obs."),
         pch = c(NA,NA,19,19,19), lty = c(1,1,NA,NA,NA), 
         # col = c("slateblue1","violetred1","turquoise2","gray","black"),
         col = c("slateblue1","violetred1","gray","gray40","black"),
         bty = "n",
         cex = 0.7)
}
dev.off()

# pdf(file=paste("/Volumes/work/harisf/figures/graphs/session",session,"withoutHist.pdf"),
#     width = dev.size()[1],height = dev.size()[2])
# set.seed(2)
# plot(graph,main=paste("Session ",session,sep = ""),
#      edge.lty=rep(1,length(EDGES)/2),
#      edge.arrow.size = 0.5,
#      edge.color = c("slateblue1","violetred1")[connection_copy+1],
#      vertex.color = c("gray","turquoise2","black")[neuronColorIndex],
#      vertex.label.color = c("black","white")[neuronColorIndex.label])
# if(neuronsProducingErrors[1] == 0){
#   legend("bottomleft",
#          legend = c("inhibitory","excitatory","signif. lickOnset","non-signif. lickOnset"),
#          pch = c(NA,NA,19,19), lty = c(1,1,NA,NA), col = c("slateblue1","violetred1","turquoise2","gray"),
#          bty = "n")
# } else {
#   legend("bottomleft",
#          legend = c("inhibitory","excitatory","signif. lickOnset","non-signif. lickOnset","error: few obs."),
#          pch = c(NA,NA,19,19,19), lty = c(1,1,NA,NA,NA), col = c("slateblue1","violetred1","turquoise2","gray","black"),
#          bty = "n")
# }
# dev.off()
# these are the old colors
# legend("bottomleft",
#        legend = c("inhibitory","excitatory","signif. lickOnset","non-signif. lickOnset"),
#        pch = c(NA,NA,19,19), lty = c(1,1,NA,NA), col = c("blue","red","orange","gray"),
#        bty = "n")



#plot(make_ring(10, directed = TRUE, mutual = TRUE))
