library(R.matlab)
library(glmnet)

setwd("/Volumes/harisf/master/data")
#setwd("/home/shomea/h/harisf/master/data")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130702.mat")
totalNumberOfNeurons = length(data$obj[[12]][[1]])

getBasis2 = function(nBases,binSize){
  #b = binSize*5
  #peaks = c(binSize,binSize*50)
  b = binSize*nBases
  peaks = c(binSize,binSize*10*nBases)
  #peaks = c(binSize,binSize*5*nBases)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  #str(ihbasis)
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}
invLink = function(x){exp(x)/(1+exp(x))}
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

binSize = 0.001
nBases_history = 10
nBases_connectivity = 4
deg = 5 # degree of lickonset polynomial

bas_list_hist = getBasis2(nBases_history,binSize)
bas_hist = bas_list_hist$bas_orth
tau_N_hist = bas_list_hist$tau_N
bas_list_connect = getBasis2(nBases_connectivity,binSize)
bas_connect = bas_list_connect$bas_orth
tau_N_connect = bas_list_connect$tau_N

# plotWidth = dev.size()[1]
# plotHeight = dev.size()[2]
plotWidth = 4
plotHeight = 4.456
tau_N_xlim = c(tau_N_hist,tau_N_connect)[as.numeric(tau_N_connect > tau_N_hist) + 1]

startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials.good]),na.rm=TRUE)
startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials.good]),na.rm=TRUE)
startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE) # aka lickOnset
lickOnset = rep(seq(binSize,5,binSize) - startOfResponseEpoch,length(trials.good))


setwd("/Volumes/work/harisf/session2/lassoFit_rightTrials")

#responseNeuron = 3
for(responseNeuron in seq(1,totalNumberOfNeurons)){
#for(responseNeuron in seq(5,5)){
  fit = readRDS(paste("n",responseNeuron,"_b1ms.rds",sep=""))
  
  mainDir = "/Volumes/work/harisf/figures/effects session 2 rightTrials"
  subDir = paste("n",responseNeuron,sep="")
  if(!dir.exists(file.path(mainDir, subDir)))
    dir.create(file.path(mainDir, subDir))
  filePathName = paste(file.path(mainDir, subDir),"/",sep="")
  
  coeff_intercept = coef(fit, s = "lambda.min")[1]
  coeff_history = coef(fit, s = "lambda.min")[2:(nBases_history+1)]
  coeff_connectivity = coef(fit, s = "lambda.min")[(nBases_history+2):(length(coef(fit, s = "lambda.min"))-deg)]
  coeff_lickOnset = coef(fit,s="lambda.min")[seq(-deg+1,0)+length(coef(fit,s="lambda.min"))]
  
  ###################
  # save history plot
  ###################
  pdf(file=paste(filePathName,"history.pdf",sep=""),width=plotWidth,height=plotHeight)
  plot(seq(binSize,tau_N_hist,binSize)*1000,invLink(bas_hist %*% coeff_history+coeff_intercept),type="l",
       xlab="lag (ms)",ylab = paste("firing prob. n",responseNeuron,sep=""),main=paste("history n",responseNeuron,sep=""),
       ylim = c(0,max(invLink(bas_hist %*% coeff_history + coeff_intercept))),xlim=c(0,tau_N_xlim*1000))
  abline(h=invLink(coeff_intercept),lty=2)
  dev.off()

  #########################
  # save connectivity plots
  #########################
  otherNeurons = dimnames(coef(fit, s = "lambda.min"))[[1]][-seq(1,(nBases_history+1))]
  for(j in seq(1,(totalNumberOfNeurons-1)*nBases_connectivity,nBases_connectivity)){
    currentNeuron = substring(otherNeurons[j],2,gregexpr("k",otherNeurons[j])[[1]][1]-2)

    pdf(file=paste(filePathName,"connectivity_n",currentNeuron,".pdf",sep=""),width=plotWidth,height=plotHeight)
    plot(seq(binSize,tau_N_connect,binSize)*1000,invLink(bas_connect %*% coeff_connectivity[seq(j,j+nBases_connectivity-1)]+coeff_intercept),type="l",
         xlab="lag (ms)",ylab = paste("firing prob. n",responseNeuron,sep=""),main=paste("n",responseNeuron," <- n",currentNeuron,sep=""),
         ylim = c(0,max(invLink(bas_hist %*% coeff_history+coeff_intercept))),xlim=c(0,tau_N_xlim*1000))
    abline(h=invLink(coeff_intercept),lty=2)
    dev.off()
  }
  
  ######################
  # save lick onset plot
  ######################
  lickOnsetPoly_full = poly(lickOnset,deg) %*% coeff_lickOnset
  
  pdf(file=paste(filePathName,"lickOnset.pdf",sep=""),width=plotWidth,height=plotHeight)
  plot(lickOnset[seq(1,5/binSize)],invLink(lickOnsetPoly_full[seq(1,5/binSize)]+coeff_intercept),type="l",xlab="lickOnset (s)",ylab=paste("firing prob. n",responseNeuron,sep=""),
       main=paste("n",responseNeuron," poly(lickOnset)",sep=""))
  abline(h=invLink(coeff_intercept),lty=2)
  abline(v=startOfSampleEpoch-startOfResponseEpoch,lty=3,col="gray")
  abline(v=startOfDelayEpoch-startOfResponseEpoch,lty=3,col="gray")
  abline(v=startOfResponseEpoch-startOfResponseEpoch,lty=3,col="gray")
  dev.off()
}




