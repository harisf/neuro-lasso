library(R.matlab)
# library(foreach)
# library(doParallel)
# library(parallel)
library(Matrix)

# read data
setwd("/home/shomea/h/harisf/master/data")
#setwd("/Volumes/harisf/master/data")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

rm(list=setdiff(ls(), c("data")))

binSize = 0.001
responseNeuron = 1

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
# trials_correctR = which(data$obj[[8]][1,] == 1)
# trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# # get trials where there was a correct LEFT lick 
# trials_correctL = which(data$obj[[8]][2,] == 1)
# trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]


# discretizeSpikeData = function(neuron,TRIALS,binSize=0.01,tau_N=NA){
#   eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
#   eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
#   lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)
# 
#   #timeInterval = seq(0,5.4,binSize)
#   timeInterval = seq(0,5,binSize)
# 
#   mat = NULL
#   mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
# 
#   if(!is.na(tau_N)){
#     M = floor(tau_N / binSize) # number of bins we go back
#     mat_j = cbind(mat_j,matrix(NA,nrow=dim(mat_j)[1],ncol=M))
#   }
# 
#   for(trial_j in TRIALS){
#     trialStartTime_j = data$obj[[7]][1,trial_j]
#     eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
# 
#     mat_j[,1] = rep(trial_j,length(timeInterval)-1)
#     mat_j[,2] = timeInterval[2:length(timeInterval)]-lickOnset
#     mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
# 
#     if(!is.na(tau_N)){
#       for(m in seq(1,M)){
#         mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
#         #mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
#       }
#     }
# 
#     mat = rbind(mat,mat_j)
#   }
# 
#   if(!is.na(tau_N)){
#     cnames = c()
#     for(m in seq(1,M)){
#       cnames = c(cnames,paste("spikeCountj",neuron,"m",m,sep = ""))
#     }
#     colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""),cnames)
#   } else
#     colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""))
#   df = as.data.frame(mat)
#   return(df)
# }

pdiscretizeSpikeData = function(neuron,TRIALS,binSize){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  #mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  no_cores = detectCores()-1
  registerDoParallel(no_cores)
  mat = foreach(trial_j = TRIALS,.combine = rbind) %dopar% {
    #mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
    
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]-lickOnset
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    mat_j
  }
  stopImplicitCluster()
  
  colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""))
  mat = as.data.frame(mat)
  return(mat)
}

# discretizeAndAlignSpikeData = function(mainNeuron,TRIALS,binSize=0.01){
#   spikeData_mainNeuron = discretizeSpikeData(mainNeuron,TRIALS,binSize)
# 
#   otherNeurons = setdiff(seq(1,30),mainNeuron)
#   spikeData_otherNeurons = matrix(NA,nrow=dim(spikeData_mainNeuron)[1],ncol=29)
# 
#   colnamesTxt = NULL
#   timeInterval = seq(0,5,binSize)
#   for(i in seq(1,29)){
#     neuron = otherNeurons[i]
#     eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
#     eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
# 
#     for(trial_j in unique(spikeData_mainNeuron$trialId)){
#       trialStartTime_j = data$obj[[7]][1,trial_j]
#       eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
# 
#       spikeData_otherNeurons[which(spikeData_mainNeuron$trialId == trial_j),i] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
# 
#     }
#     colnamesTxt = c(colnamesTxt,paste("spikeCountj",neuron,sep = ""))
#   }
#   colnames(spikeData_otherNeurons) = colnamesTxt
# 
#   return(as.data.frame(cbind(spikeData_mainNeuron,spikeData_otherNeurons)))
# 
# }

pdiscretizeAndAlignSpikeData = function(mainNeuron,TRIALS,binSize=0.01){
  # listCombine = function(...){
  #   list(...)
  # }
  
  spikeData_mainNeuron = pdiscretizeSpikeData(mainNeuron,TRIALS,binSize)
  
  otherNeurons = setdiff(seq(1,30),mainNeuron)
  #spikeData_otherNeurons = matrix(NA,nrow=dim(spikeData_mainNeuron)[1],ncol=29)
  
  timeInterval = seq(0,5,binSize)
  
  no_cores = detectCores()-1
  registerDoParallel(no_cores)
  spikeData_otherNeurons = foreach(i = seq(1,29),.combine = cbind) %dopar% {
    neuron = otherNeurons[i]
    eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
    eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
    
    no_cores = detectCores()-1
    registerDoParallel(no_cores)
    spikesInTrial = foreach(trial_j = unique(spikeData_mainNeuron$trialId), .combine = list) %dopar% {
      trialStartTime_j = data$obj[[7]][1,trial_j]
      eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
      spikevector = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    }
    stopImplicitCluster()
    #rownames(spikesInTrial) = as.character(unique(spikeData_mainNeuron$trialId))
    
    spikeData_neuron = unlist(spikesInTrial)
  }
  stopImplicitCluster()
  
  colnamesTxt = NULL
  for(i in seq(1,29))
    colnamesTxt = c(colnamesTxt,paste("spikeCountj",otherNeurons[i],sep = ""))
  colnames(spikeData_otherNeurons) = colnamesTxt
  
  as.data.frame(cbind(spikeData_mainNeuron,spikeData_otherNeurons))
  
  
  
  # for(i in seq(1,29)){
  #   neuron = otherNeurons[i]
  #   eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  #   eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  #   
  #   no_cores = detectCores()-1
  #   registerDoParallel(no_cores)
  #   otherSpikesList = foreach(trial_j = unique(spikeData_mainNeuron$trialId),
  #           .combine = rbind, .multicombine = FALSE) %dopar% {
  #     trialStartTime_j = data$obj[[7]][1,trial_j]
  #     eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
  #     
  #      list(spikevector = as.vector(table(cut(eventTimes_j,breaks=timeInterval))), trial_j = trial_j)
  #     
  #           }
  #   stopImplicitCluster()
  #   
  #   # no_cores <- detectCores() - 1
  #   # cl <- makeCluster(no_cores)
  #   # clusterExport(cl, list("spikeData_otherNeurons","spikeData_mainNeuron","i"),
  #   #               envir = environment())
  #   # spikeData_otherNeurons = parApply(cl,otherSpikesList,1,function(x){
  #   #   spikeData_otherNeurons[which(spikeData_mainNeuron$trialId == x$trial_j),i] = x$spikevector})
  #   # stopCluster(cl)
  #   for(j in seq(1,dim(otherSpikesList)[1]))
  #     spikeData_otherNeurons[which(spikeData_mainNeuron$trialId == otherSpikesList[j,]$trial_j),i] = otherSpikesList[j,]$spikevector
  #   
  #   colnamesTxt = c(colnamesTxt,paste("spikeCountj",neuron,sep = ""))
  # }
  # colnames(spikeData_otherNeurons) = colnamesTxt
  # 
  # return(as.data.frame(cbind(spikeData_mainNeuron,spikeData_otherNeurons)))
  
}

getBasis2 = function(nBases,binSize){
  b = binSize*5
  peaks = c(binSize,binSize*50)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}

weightedSpikeData = function(spikeData,nBases_history,nBases_connectivity,binSize=0.01){
  bas_hist = getBasis2(nBases_history,binSize)$bas_orth
  bas_connect = getBasis2(nBases_connectivity,binSize)$bas_orth
  
  #history
  basisWeights = matrix(NA,nrow=dim(spikeData)[1]-1,ncol=nBases_history)
  for(k in seq(1,dim(bas_hist)[2])){
    basisWeights[,k] = convolve(c(0,spikeData[,3]),rev(bas_hist[,k]),type="open")[2:dim(spikeData)[1]]
  }
  
  txt=NULL
  for(k in seq(1,nBases_history)){
    txt = c(txt,paste(sub("spikeCount","",colnames(spikeData)[3]),".k",k,sep=""))
  }
  colnames(basisWeights) = txt
  
  spikeData_basis = cbind(spikeData[-1,seq(1,3)],basisWeights) #when using convolution
  colnames(spikeData_basis)[1:3] = colnames(spikeData)[1:3]
  spikeData_basis = as.data.frame(spikeData_basis)
  
  #connectivity
  for(j in seq(4,dim(spikeData)[2])){
    basisWeights = matrix(NA,nrow=dim(spikeData)[1]-1,ncol=nBases_connectivity)
    for(k in seq(1,dim(bas_connect)[2])){
      basisWeights[,k] = convolve(c(0,spikeData[,j]),rev(bas_connect[,k]),type="open")[2:dim(spikeData)[1]]
    }
    
    txt=NULL
    for(k in seq(1,nBases_connectivity)){
      txt = c(txt,paste(sub("spikeCount","",colnames(spikeData)[j]),".k",k,sep=""))
    }
    colnames(basisWeights) = txt
    
    spikeData_basis = cbind(spikeData_basis,basisWeights)
    
  }
  
  return(spikeData_basis)
  
}

binSize = 0.001

system.time(spikeData <- pdiscretizeAndAlignSpikeData(mainNeuron = 1,trials.good,binSize))
#str(spikeData)

system.time(spikeData_basis <- weightedSpikeData(spikeData,
                                    nBases_history = 10,
                                    nBases_connectivity = 4,binSize))

deg = 5
predMat = cbind(spikeData_basis[,-c(1,2,3)],poly(spikeData_basis$lickOnset,degree = deg))
txtPolyname = NULL
for(i in seq(1,deg))
  txtPolyname = c(txtPolyname,paste("poly(lickOnset)",i,sep = ""))
colnames(predMat)[seq(dim(predMat)[2]-deg+1,dim(predMat)[2])] = txtPolyname

# save data
evaluatedData = cbind(spikeData_basis[,3],predMat)
setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
#saveRDS(evaluatedData,"n1_b1ms_2.rds")

library(Matrix)
tol = 1e-10
for(i in seq(2,dim(evaluatedData)[2])){
  evaluatedData[which(abs(evaluatedData[,i]) < tol),i] = 0
}
evaluatedData = Matrix(evaluatedData,sparse = TRUE)
saveRDS(evaluatedData,"n1_b1ms_2.rds")


