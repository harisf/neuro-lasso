#setwd("/Volumes/harisf/master/data/variables")
setwd("/home/shomea/h/harisf/master/data/variables")
lassoData = readRDS("lassoData.rds")

library(glmnet)
require(doMC)
registerDoMC(cores=10)
x = as.matrix(lassoData[,-1])
y = as.factor(lassoData[,1])

#system.time(cv.glmnet(x,y,family = "binomial",alpha = 1,nfolds = 10))

print(system.time(cv.glmnet(x,y,family = "binomial",alpha = 1,nfolds = 10,parallel=TRUE)))
