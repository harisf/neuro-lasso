library(Matrix)
#library(doParallel)
#library(doMC)
library(parallel)
library(hdi)
library(glmnet)

#setwd("/Volumes/work/harisf/modelMatrix10ms")
#setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
#setwd("/Volumes/harisf/master/data/variables/modelMatrix")

# modelMatrix.Mat = Matrix(as.matrix(modelMatrix))
# x = modelMatrix.Mat[,-1]
# y = modelMatrix.Mat[,1]

# x = as.matrix(modelMatrix[,-1])
# y = as.matrix(modelMatrix[,1])

# y[which(y > 1)] = 1
# y = as.factor(y)

# tol = 1e-10
# for(i in seq(1,dim(x)[2])){
#   x[which(abs(x[,i]) < tol),i] = 0
# }

#y.sparsed = Matrix(y,sparse = TRUE)
#x = Matrix(x,sparse = TRUE) # reduces x by 55 Mb. I.e. x is 172 Mb, and x.sparsed is 117 Mb
#y = Matrix(y,sparse = TRUE)

#registerDoParallel(10)
# model_lasso_cv = cv.glmnet(x,y,family="binomial",alpha=1,
#                            nfolds = 10,parallel = T)

#system.time(fit <- lasso.proj(x,y,family = "binomial",parallel = TRUE,ncores = 10,suppress.grouptesting = F))
# startTime = Sys.time()
# fit <- lasso.proj(x,y,family = "binomial",parallel = TRUE,ncores = 10,suppress.grouptesting = T)
# Sys.time() - startTime
#stopImplicitCluster()

lasso.cv.lambda.min = function (x, y, nfolds = 10, grouped = nrow(x) > 3 * nfolds, 
                                ...){
  suppressMessages(library(doMC))
  registerDoMC(cores=10)
  #library(doParallel)
  #registerDoParallel(cores = 10)
  fit.cv <- cv.glmnet(x, y, nfolds = nfolds, grouped = grouped, parallel = TRUE,
                      ...)
  #cat("   cross-validation completed... ",sep="")
  sel <- predict(fit.cv, type = "nonzero", s = "lambda.min")
  sel[[1]]
}

glm.pval.x.as.matrix = function (x, y, family = "binomial", verbose = FALSE, ...){
  fit.glm <- glm(y ~ as.matrix(x), family = family, ...)
  #cat("and glm fitted.")
  fit.summary <- summary(fit.glm)
  if (!fit.glm$converged & verbose) {
    #print(fit.summary)
    #cat(" glm.fit: algorithm did not converge.\n")
  }
  #cat("\n")
  pval.sel <- coef(fit.summary)[-1, 4]
  names(pval.sel) <- colnames(x)
  pval.sel
}

# for loop
#for(neuron in c(2,seq(4,30))){
#for(neuron in seq(16,30)){
for(neuron in seq(13,13)){
  setwd("/global/work/harisf/modelMatrix10ms")
  fileName = paste("n",neuron,"_b10ms.rds",sep="")
  
  modelMatrix = readRDS(fileName)
  
  y = modelMatrix[,1]
  y[which(y > 1)] = 1
  
  x = modelMatrix[,-1]
  
  startTime = Sys.time()
  fit <- multi.split(x,y, ci = FALSE, B = 50,
                     classical.fit = glm.pval.x.as.matrix, #args.classical.fit = list(verbose = TRUE),
                     model.selector = lasso.cv.lambda.min, args.model.selector = list(family = "binomial"),
                     parallel = TRUE, ncores = 10,
                     return.selmodels = FALSE, verbose = FALSE)
  
  endTime = Sys.time() - startTime
  
  cat("Multisplit done for neuron ",neuron,". Time used: ",endTime," ",attr(endTime,"units"),". \n",sep="")
  
  # no_cores = detectCores() - 1
  #no_cores = 10
  #registerDoParallel(no_cores)
  #registerDoMC(cores = no_cores)
  #system.time(pval <- lasso.proj(x,y,family = "binomial",parallel = TRUE,ncores = 10)$pval)
  #stopImplicitCluster()
  
  # lasso.proj_parallel = function(data){
  #   x = data[,-1]
  #   y = data[,1]
  #   lasso.proj(x,y,family = "binomial",parallel = T,ncores = 10)
  # }
  # 
  # res <- mclapply(lassoData.Mat,lasso.proj_parallel,mc.cores = no_cores)
  
  #saveRDS(res,"res_lasso_proj.rds")
  setwd("/global/work/harisf/multisplit10ms")
  saveRDS(fit,fileName)
}
#saveRDS(pval,"pval.rds")

# x <- matrix(rnorm(100*20), nrow = 1000, ncol = 10)
# y <- x[,1] + x[,2] + rnorm(1000)
# # system.time(fit.lasso <- lasso.proj(x, y))
# system.time(fit.lasso_par <- lasso.proj(x, y,parallel = T,ncores = 3))


# library(doParallel)
# registerDoParallel(cores = 10)
# system.time(fit <- cv.glmnet(x,y,parallel = TRUE))









