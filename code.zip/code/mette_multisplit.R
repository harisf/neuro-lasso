library(Matrix)
library(doParallel)
library(parallel)
library(hdi)
library(glmnet)

# read model matrix
setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
modelMatrix = readRDS("n1_b1ms.rds")

y = modelMatrix[,1]
x = modelMatrix[,-1]

# my model selector.
# Note: parallel in cv.glmnet, and lambda.min in predict
lasso.cv.lambda.min = function (x, y, nfolds = 10, grouped = nrow(x) > 3 * nfolds, 
                                ...){
  library(doParallel)
  registerDoParallel(cores = 10)
  fit.cv <- cv.glmnet(x, y, nfolds = nfolds, grouped = grouped, parallel = TRUE,
                      ...)
  #cat("   cross-validation completed... ")
  sel <- predict(fit.cv, type = "nonzero", s = "lambda.min")
  sel[[1]]
}

# my classical fit. 
# Note: as.matrix(x) in glm, since glm does not handle variables of class dgCMatrix, 
# and screen output whenever glm does not converge (because there are too few observations = 1)
glm.pval.x.as.matrix = function (x, y, family = "binomial", verbose = FALSE, ...){
  fit.glm <- glm(y ~ as.matrix(x), family = family, ...)
  #cat("and glm fitted.")
  fit.summary <- summary(fit.glm)
  if (!fit.glm$converged & verbose) {
    #print(fit.summary)
    cat("   glm.fit: algorithm did not converge.")
  }
  cat("\n")
  pval.sel <- coef(fit.summary)[-1, 4]
  names(pval.sel) <- colnames(x)
  pval.sel
}

startTime = Sys.time()
fit <- multi.split(x,y, ci = FALSE, B = 50,
                   classical.fit = glm.pval.x.as.matrix, args.classical.fit = list(verbose = TRUE),
                   model.selector = lasso.cv.lambda.min, args.model.selector = list(family = "binomial"),
                   #parallel = TRUE, ncores = 20, parallellizing here does not work..
                   return.selmodels = FALSE, verbose = TRUE)
Sys.time() - startTime


# save fit variable
setwd("/home/shomea/h/harisf/master/data/variables/hdi")
saveRDS(fit,"fitMultisplit_n1_b1ms.rds")










