# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

rm(list=setdiff(ls(), c("data")))

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
# trials_correctR = which(data$obj[[8]][1,] == 1)
# trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# # get trials where there was a correct LEFT lick 
# trials_correctL = which(data$obj[[8]][2,] == 1)
# trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]

# startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials.good]),na.rm=TRUE)
# startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials.good]),na.rm=TRUE)
# startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE) # aka lickOnset


discretizeSpikeData = function(neuron,TRIALS,binSize=0.01,tau_N=NA){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  if(!is.na(tau_N)){
    M = tau_N / binSize # number of bins we go back
    mat_j = cbind(mat_j,matrix(NA,nrow=dim(mat_j)[1],ncol=M))
  }
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]-lickOnset
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    if(!is.na(tau_N)){
      for(m in seq(1,M)){
        mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
        #mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
      }
    }
    
    mat = rbind(mat,mat_j)
  }
  
  if(!is.na(tau_N)){
    cnames = c()
    for(m in seq(1,M)){
      cnames = c(cnames,paste("spikeCountj",neuron,"m",m,sep = ""))
    }
    colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""),cnames)
  } else
    colnames(mat) = c("trialId","lickOnset","spikeCount")
  df = as.data.frame(mat)
  return(df)
}

getBasis = function(nBases,tau_N,binSize=0.01){
  t = seq(0,tau_N,tau_N/1000)
  a = 1
  
  if(nBases == 4){
    b = tau_N/8 # works for nBases = 4
  }
  if(nBases == 10){
    b = tau_N/150 # works for nBases = 10
  }
  
  varphiStart = log(b)*pi
  varphi = seq(varphiStart,varphiStart+(nBases-1)*pi/2,pi/2)
  #varphi = seq(varphiStart,varphiStart+(nBases-1)*pi,pi) # for tiling
  
  bas = matrix(NA,ncol=length(t),nrow = nBases)
  for(j in seq(1,nBases)){
    for(i in seq(1,length(t))){
      x = max(-pi, min(pi,pi*a*log(t[i]+b)-varphi[j]))
      bas[j,i] = (cos(x) + 1)/2
    }
  }
  
  t_new = seq(0,tau_N,binSize)
  
  indexes = list()
  indexes[[1]] = which(t <= t_new[2])
  for(k in seq(2,length(t_new)-1)){
    indexes[[k]] = intersect(which(t <= t_new[k+1]),which(t > t_new[k]))
  }
  
  bas_new = matrix(NA,ncol = length(indexes),nrow = nBases)
  for(j in seq(1,nBases)){
    for(k in seq(1,length(indexes))){
      #bas_new[j,k] = median(bas[j,indexes[[k]]])
      bas_new[j,k] = mean(bas[j,indexes[[k]]])
    }
  }
  
  return(bas_new)
}

getBasis_tile = function(nBases,tau_N,binSize=0.01,logtime = TRUE){
  t = seq(0,tau_N,tau_N/1000)
  #t = seq(tau_N/1000,tau_N,tau_N/1000)
  a = 1
  
  if(nBases == 4){
    b = tau_N/8 # works for nBases = 4
  }
  if(nBases == 10){
    b = tau_N/150 # works for nBases = 10
  }
  
  nt = log(t+b)
  if(logtime){
    cStart = nt[1]
    cEnd = nt[length(nt)]
  } else {
    #cStart = t[1] + binSize # to center first basis at second bin
    cStart = t[1]
    cEnd = t[length(t)]
  }
  db = (cEnd - cStart) / (nBases-1)
  c = seq(cStart,cEnd,db)
  
  bas = matrix(NA,nrow = nBases,ncol = length(t))
  for(i in seq(1,nBases)){
    for(j in seq(1,length(t))){
      if(logtime){
        x = (nt[j]-c[i])*pi/db 
      } else {
        x = (t[j]-c[i])*pi/db
      }
      bas[i,j] = (cos(max(-pi, min(pi,x))) + 1) / 2
    }
  }
  
  t_new = seq(0,tau_N,binSize)
  
  indexes = list()
  indexes[[1]] = which(t <= t_new[2])
  for(k in seq(2,length(t_new)-1)){
    indexes[[k]] = intersect(which(t <= t_new[k+1]),which(t > t_new[k]))
  }
  
  bas_new = matrix(NA,ncol = length(indexes),nrow = nBases)
  for(j in seq(1,nBases)){
    for(k in seq(1,length(indexes))){
      bas_new[j,k] = median(bas[j,indexes[[k]]])
      #bas_new[j,k] = mean(bas[j,indexes[[k]]])
    }
  }
  
  # t_new = seq(0,tau_N,binSize)
  # #t_new = seq(binSize,tau_N,binSize)
  # bas_new = matrix(NA,ncol = length(t_new),nrow = nBases)
  # for(j in seq(1,nBases)){
  #   bas_new[j,] = c(bas[j,1],bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)+1])
  #   #bas_new[j,] = c(bas[j,1],bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)]) # What affect does this have? Must test..
  # }
  # 
  lags = c() # for plotting
  for(i in seq(1,nBases))
    lags = c(lags,t[which.max(bas[i,])])
  #lags = c(lags,t[which.max(bas[i,2:length(t)])+1])
  # 
  # #return(list(bas=bas_new[-1,],lags=lags)) #dont need the first basis
  return(list(bas=bas_new,lags=lags)) #include the first basis
}

binSize = 0.01
tau_N = 0.24
spikes_n1 = discretizeSpikeData(1,trials.good,binSize,tau_N)
spikes_n2 = discretizeSpikeData(2,trials.good,binSize,tau_N)
#spikes_n1_mat = as.matrix(spikes_n1)
#head(spikes_n1_mat)

bas_list = getBasis_tile(10,tau_N,binSize,logtime = F)
bas = bas_list$bas
bas_lags = bas_list$lags # for plotting

#bas = getBasis(10,tau_N,binSize)

str(bas)

basisWeights = matrix(NA,ncol=dim(bas)[1],nrow=dim(spikes_n1)[1])
for(j in seq(1,dim(bas)[1])){
  basisWeights[,j] = bas[j,1:dim(bas)[2]] %*% t(spikes_n1[,4:dim(spikes_n1)[2]])
}
txt=NULL
for(j in seq(1,dim(bas)[1])){
  txt = c(txt,paste("k",j,sep=""))
}
colnames(basisWeights) = txt
spikes_n1_basis = cbind(spikes_n1[,3],basisWeights)
colnames(spikes_n1_basis)[1] = colnames(spikes_n1)[3]
spikes_n1_basis = as.data.frame(spikes_n1_basis)
# 
# history effects neuron 1, using basis functions
model_history_n1_basis = glm(formula = spikeCountj1 ~ .,
                             data = spikes_n1_basis, family = "poisson")
summary(model_history_n1_basis)
plot(c(-binSize,bas_lags),exp(coefficients(model_history_n1_basis)),type="b")


printContingencyTable = function(resp, pred){
  contingencyTable = matrix(NA,nrow=length(unique(resp)),ncol=length(unique(pred)))
  for(i in seq(1,length(unique(resp)))){
    for(j in seq(1,length(unique(pred)))){
      if(is.na(unique(pred)[j])){
        contingencyTable[i,j] = length(which(resp[which(is.na(pred))] == unique(resp)[i]))
      } else {
        contingencyTable[i,j] = length(which(resp[which(pred == unique(pred)[j])] == unique(resp)[i]))
      }
    }
  }
  colnames(contingencyTable) = as.character(unique(pred))
  rownames(contingencyTable) = as.character(unique(resp))
  
  contingencyTable
}
printContingencyTable(spikes_n1_basis$spikeCountj1,spikes_n1_basis$k1)

# history effects neuron 1
model_history_n2 = glm(formula = spikeCountj2 ~ . -lickOnset - trialId,
                             data = spikes_n2, family = "poisson")
summary(model_history_n2)
plot(coefficients(model_history_n1),type="b")




observationsLargerThanZero = c()
observationsZero = c()
for(m in seq(4,dim(spikes_n1)[2])){
  observationsLargerThanZero = c(observationsLargerThanZero,length(which(spikes_n1[,m] > 0)))
  observationsZero = c(observationsZero,length(which(spikes_n1[,m] == 0)))
}
plot(seq(binSize,tau_N,binSize),observationsLargerThanZero/observationsZero)
plot(seq(binSize,tau_N,binSize),observationsZero/dim(spikes_n1)[1])



# expanding spikes_n1
t = seq(0,tau_N,tau_N/1000)
t_new = seq(0,tau_N,binSize)

indexes = list()
indexes[[1]] = which(t <= t_new[2])
for(k in seq(2,length(t_new)-1)){
  indexes[[k]] = intersect(which(t <= t_new[k+1]),which(t > t_new[k]))
}

y_m = as.matrix(spikes_n1)[,-c(1,2,3)]
y_new = matrix(NA,nrow=dim(y_m)[1],ncol=Reduce(sum,lapply(indexes,length)))

for(i in seq(1,length(indexes)))
  y_new[,indexes[[i]]] = rep(y_m[,i],as.numeric(lapply(indexes[i],length)))

#str(bas)
#str(y_new)
baseval = y_new %*% t(bas)
#str(baseval)


txt=NULL
for(j in seq(1,dim(bas)[1])){
  txt = c(txt,paste("k",j,sep=""))
}
colnames(baseval) = txt

spikes_n1_basis = cbind(spikes_n1[,3],baseval)
colnames(spikes_n1_basis)[1] = colnames(spikes_n1)[3]
spikes_n1_basis = as.data.frame(spikes_n1_basis)

# history effects neuron 1, using basis functions
model_history_n1_basis = glm(formula = spikeCountj1 ~ .,
                             data = spikes_n1_basis, family = "poisson")
summary(model_history_n1_basis)

plot(exp(coefficients(model_history_n1_basis))[-1],type="b")

























lags = c()
for(i in seq(1,nBases))
  lags = c(lags,t[which.max(bas[i,])])
#lags = c(lags,t[which.max(bas[i,2:length(t)])+1])


t_new = seq(0,tau_N,binSize)
bas_new = matrix(NA,ncol = length(t_new),nrow = nBases)
for(j in seq(1,nBases)){
  bas_new[j,] = c(bas[j,1],bas[j,which(as.vector(table(cut(log(t_new),breaks=log(t)))) == 1)+1])
  #bas_new[j,] = c(NA,bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)+1])
}
#lags = t[which(as.vector(table(cut(t_new,breaks=t))) == 1)+1]
#colSums(bas_new[-1,])

#pdf(file="/Volumes/harisf/master/figures/bases/evaluated_tile2.pdf",width=dev.size()[1],height=dev.size()[2])
#par(mfrow=c(3,1))
par(mfrow=c(2,1))
plot(NULL,xlim=c(0,tau_N),ylim=c(0,1),xlab="t",ylab="")
for(i in seq(1,nBases)){
  lines(t,bas[i,],type="l",col=i)
  #lines(t[which(bas[i,] > 0)],bas[i,which(bas[i,] > 0)],type="l",col=i)
}

plot(NULL,xlim=c(0,tau_N),ylim=c(0,1),xlab="t",ylab="")#,main="bin size 10 ms")
for(i in seq(1,nBases)){
  lines(t_new,bas_new[i,],type="b",col=i,pch=i)
  #lines(t[which(bas[i,] > 0)],bas[i,which(bas[i,] > 0)],type="l",col=i)
}
# 
# t_new = seq(0,tau_N,binSize/10)
# bas_new = matrix(NA,ncol = length(t_new),nrow = nBases)
# for(j in seq(1,nBases)){
#   bas_new[j,] = c(bas[j,1],bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)+1])
#   #bas_new[j,] = c(NA,bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)+1])
# }
# plot(NULL,xlim=c(0,tau_N),ylim=c(0,1),xlab="t",ylab="",main="bin size 1 ms")
# for(i in seq(1,nBases)){
#   lines(t_new,bas_new[i,],type="b",col=i,pch=i)
#   #lines(t[which(bas[i,] > 0)],bas[i,which(bas[i,] > 0)],type="l",col=i)
# }
#dev.off()

#colSums(bas)

#plot(bas[1,],type="l")
