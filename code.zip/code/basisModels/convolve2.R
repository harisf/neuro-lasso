# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

rm(list=setdiff(ls(), c("data")))

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()


discretizeSpikeData = function(neuron,TRIALS,binSize=0.01,tau_N=NA){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  if(!is.na(tau_N)){
    M = floor(tau_N / binSize) # number of bins we go back
    mat_j = cbind(mat_j,matrix(NA,nrow=dim(mat_j)[1],ncol=M))
  }
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]-lickOnset
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    if(!is.na(tau_N)){
      for(m in seq(1,M)){
        mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
        #mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
      }
    }
    
    mat = rbind(mat,mat_j)
  }
  
  if(!is.na(tau_N)){
    cnames = c()
    for(m in seq(1,M)){
      cnames = c(cnames,paste("spikeCountj",neuron,"m",m,sep = ""))
    }
    colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""),cnames)
  } else
    colnames(mat) = c("trialId","lickOnset","spikeCount")
  df = as.data.frame(mat)
  return(df)
}

getBasis2 = function(nBases,binSize){
  b = binSize*5
  peaks = c(binSize,binSize*50)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  return(list(bas=ihbasis,lags=lags,tau_N = maxt))
}

binSize = 0.01
#tau_N = 0.12
#spikes_n2 = discretizeSpikeData(2,trials.good,binSize)

bas_list = getBasis2(10,binSize)
bas = bas_list$bas
lags = bas_list$lags
tau_N = bas_list$tau_N
#matplot(bas,type="b",pch=seq(1,5))

spikes_n1 = discretizeSpikeData(1,trials.good,binSize,tau_N)
spikes_n2 = discretizeSpikeData(2,trials.good,binSize,tau_N)

# plot(NULL,xlim=c(0,tau_N),ylim=c(0,1),xlab="lag (s)",ylab="")#,main="pillow bases, bin size 1 ms")
# for(j in seq(1,10)){
#   lines(seq(binSize,tau_N,binSize),bas[,j],type="b",col=j,pch=j)
# }

# pdf(file="/Volumes/harisf/master/figures/bases/pillowbases/10msAND1ms.pdf",width=dev.size()[1],height=dev.size()[2])
# par(mfrow=c(2,1))
# plot(NULL,xlim=c(0,tau_N_10ms),ylim=c(0,1),xlab="lag (s)",ylab="",main="pillow bases, bin size 10 ms")
# for(j in seq(1,10)){
#   lines(seq(0.01,tau_N_10ms,0.01),bas_10ms[,j],type="b",col=j,pch=j)
# }
# plot(NULL,xlim=c(0,tau_N_1ms),ylim=c(0,1),xlab="lag (s)",ylab="",main="pillow bases, bin size 1 ms")
# for(j in seq(1,10)){
#   lines(seq(0.001,tau_N_1ms,0.001),bas_1ms[,j],type="b",col=j,pch=j)
# }
# dev.off()


# HISTORY MODEL NEURON 1
basisWeights = matrix(NA,ncol=dim(bas)[2],nrow=dim(spikes_n1)[1])
for(j in seq(1,dim(bas)[2])){
  basisWeights[,j] = t(bas[,j]) %*% t(spikes_n1[,4:dim(spikes_n1)[2]])
}
# # using convolution
# basisWeights = matrix(NA,ncol=dim(bas)[2],nrow=dim(spikes_n1)[1]-1)
# for(j in seq(1,dim(bas)[2])){
#   basisWeights[,j] = convolve(c(0,spikes_n1$spikeCount),rev(bas[,j]),type="open")[2:length(spikes_n1$spikeCount)]
# }

txt=NULL
for(j in seq(1,dim(bas)[2])){
  txt = c(txt,paste("k",j,sep=""))
}
colnames(basisWeights) = txt
spikes_n1_basis = cbind(spikes_n1[,3],basisWeights)
#spikes_n1_basis = cbind(spikes_n1[-1,3],basisWeights) #when using convolution
colnames(spikes_n1_basis)[1] = colnames(spikes_n1)[3]
spikes_n1_basis = as.data.frame(spikes_n1_basis)
str(spikes_n1_basis)

model_history_n1 = glm(formula = spikeCountj1 ~ .,
                             data = spikes_n1_basis, family = "poisson")
summary(model_history_n1)

#pdf(file="/Volumes/harisf/master/figures/bases/pillowbases/n1history.pdf",width=dev.size()[1],height=dev.size()[2])
#par(mfrow=c(1,2))
plot(c(0,lags),coefficients(model_history_n1),type="b",
     xlab="lag (s)",ylab="coefficients",main="neuron 1 history")
plot(c(0,lags),exp(coefficients(model_history_n1)),type="b",
     xlab="lag (s)",ylab="exp(coefficient)")
#dev.off()
#plot(coefficients(model_history_n1_basis),type="b")
#plot(exp(coefficients(model_history_n1_basis)),type="b")



# HISTORY MODEL NEURON 2
basisWeights = matrix(NA,ncol=dim(bas)[2],nrow=dim(spikes_n1)[1])
for(j in seq(1,dim(bas)[2])){
  basisWeights[,j] = t(bas[,j]) %*% t(spikes_n2[,4:dim(spikes_n2)[2]])
}

txt=NULL
for(j in seq(1,dim(bas)[2])){
  txt = c(txt,paste("k",j,sep=""))
}
colnames(basisWeights) = txt
spikes_n2_basis = cbind(spikes_n2[,3],basisWeights)
colnames(spikes_n2_basis)[1] = colnames(spikes_n2)[3]
spikes_n2_basis = as.data.frame(spikes_n2_basis)

model_history_n2 = glm(formula = spikeCountj2 ~ .,
                       data = spikes_n2_basis, family = "poisson")
summary(model_history_n2)


# FUNCTIONAL CONNECTIVY N1N2
basisWeights = matrix(NA,ncol=dim(bas)[2],nrow=dim(spikes_n1)[1])
for(j in seq(1,dim(bas)[2])){
  basisWeights[,j] = t(bas[,j]) %*% t(spikes_n2[,4:dim(spikes_n2)[2]])
}
txt=NULL
for(j in seq(1,dim(bas)[2])){
  txt = c(txt,paste("k",j,"j2",sep=""))
}
colnames(basisWeights) = txt
spikes_n1n2_basis = cbind(spikes_n1_basis,basisWeights)
spikes_n1n2_basis = as.data.frame(spikes_n1n2_basis)
#str(spikes_n1n2_basis)

model_connectivity_n1n2 = glm(formula = spikeCountj1 ~ .,
                             data = spikes_n1n2_basis, family = "poisson")
summary(model_connectivity_n1n2)
# plot(lags,coefficients(model_connectivity_n1n2_basis)[12:21],type="b",
#      xlab="lag (s)",ylab="coefficients",main="connectivity n1 <- n2 ")


# FUNCTIONAL CONNECTIVY N2N1
basisWeights = matrix(NA,ncol=dim(bas)[2],nrow=dim(spikes_n1)[1])
for(j in seq(1,dim(bas)[2])){
  basisWeights[,j] = t(bas[,j]) %*% t(spikes_n1[,4:dim(spikes_n1)[2]])
}
txt=NULL
for(j in seq(1,dim(bas)[2])){
  txt = c(txt,paste("k",j,"j1",sep=""))
}
colnames(basisWeights) = txt
spikes_n2n1_basis = cbind(spikes_n2_basis,basisWeights)
spikes_n2n1_basis = as.data.frame(spikes_n2n1_basis)
str(spikes_n2n1_basis)

model_connectivity_n2n1 = glm(formula = spikeCountj2 ~ .,
                                    data = spikes_n2n1_basis, family = "poisson")
summary(model_connectivity_n1n2_basis)



# plot 2 x 2 plots of history of neuron 1 and 2, and their functional connectivities
pdf(file="/Volumes/harisf/master/figures/bases/pillowbases/n1n2.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(2,2))
plot(c(0,lags),coefficients(model_history_n1),type="b",
     xlab="lag (s)",ylab="coefficients",main="history n1",
     ylim=c(-6,2.2))
abline(h=0,lty=2)
plot(lags,coefficients(model_connectivity_n1n2)[12:21],type="b",
     xlab="",ylab="",main="connectivity n1 <- n2 ",ylim=c(-6,2.2))
abline(h=0,lty=2)
plot(lags,coefficients(model_connectivity_n2n1)[12:21],type="b",
     xlab="",ylab="",main="connectivity n2 <- n1 ",ylim=c(-6,2.2))
abline(h=0,lty=2)
plot(c(0,lags),coefficients(model_history_n2),type="b",
     xlab="",ylab="",main="history n2",ylim=c(-6,2.2))
abline(h=0,lty=2)
dev.off()

summary(model_history_n2)
summary(model_connectivity_n2n1)

# plot 2 x 2 plots of history of neuron 1 and 2, and their functional connectivities.
# THESE PLOTS ARE SMOOTHED, BY USING THE BASIS FUNCTIONS
pdf(file="/Volumes/harisf/master/figures/bases/pillowbases/n1n2_basisSmoothed_lambda_intercept.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(2,2))
plot(c(0,seq(binSize,tau_N,binSize)),exp(c(coefficients(model_history_n1)[1],bas %*% coefficients(model_history_n1)[-1])),type="l",
     xlab="lag (s)",ylab="lambda",main="history n1",
     ylim=c(0,6))
abline(h=1,lty=2)
plot(c(0,seq(binSize,tau_N,binSize)),exp(c(coefficients(model_connectivity_n1n2)[1],bas %*% coefficients(model_connectivity_n1n2)[12:21])),type="l",
     xlab="",ylab="",main="connectivity n1 <- n2 ",ylim=c(0,6))
abline(h=1,lty=2)
plot(c(0,seq(binSize,tau_N,binSize)),exp(c(coefficients(model_connectivity_n2n1)[1],bas %*% coefficients(model_connectivity_n2n1)[12:21])),type="l",
     xlab="",ylab="",main="connectivity n2 <- n1 ",ylim=c(0,6))
abline(h=1,lty=2)
plot(c(0,seq(binSize,tau_N,binSize)),exp(c(coefficients(model_history_n2)[1],bas %*% coefficients(model_history_n2)[-1])),type="l",
     xlab="",ylab="",main="history n2",ylim=c(0,6))
abline(h=1,lty=2)
dev.off()




par(mfrow=c(1,1))
plot(seq(binSize,tau_N,binSize),exp(bas %*% coefficients(model_history_n2)[-1]),type="l")
plot(seq(binSize,tau_N,binSize),exp(bas %*% coefficients(model_connectivity_n1n2)[12:21]),type="l")
