# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

rm(list=setdiff(ls(), c("data")))

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
# trials_correctR = which(data$obj[[8]][1,] == 1)
# trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# # get trials where there was a correct LEFT lick 
# trials_correctL = which(data$obj[[8]][2,] == 1)
# trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]

# startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials.good]),na.rm=TRUE)
# startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials.good]),na.rm=TRUE)
# startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE) # aka lickOnset


discretizeSpikeData = function(neuron,TRIALS,binSize=0.01,tau_N=NA){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  if(!is.na(tau_N)){
    M = tau_N / binSize # number of bins we go back
    mat_j = cbind(mat_j,matrix(NA,nrow=dim(mat_j)[1],ncol=M))
  }
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]-lickOnset
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    #mat_j[,3] = as.vector(table(cut(log(eventTimes_j+0.12/150),breaks=log(timeInterval+0.12/150))))
    
    if(!is.na(tau_N)){
      for(m in seq(1,M)){
        mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
        #mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
      }
    }
    
    mat = rbind(mat,mat_j)
  }
  
  if(!is.na(tau_N)){
    cnames = c()
    for(m in seq(1,M)){
      cnames = c(cnames,paste("spikeCountj",neuron,"m",m,sep = ""))
    }
    colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""),cnames)
  } else
    colnames(mat) = c("trialId","lickOnset","spikeCount")
  df = as.data.frame(mat)
  return(df)
}

getBasis = function(nBases,tau_N,binSize=0.01){
  t = seq(0,tau_N,tau_N/1000)
  a = 1
  
  if(nBases == 4){
    b = tau_N/8 # works for nBases = 4
  }
  if(nBases == 10){
    b = tau_N/150 # works for nBases = 10
  }
  
  varphiStart = log(b)*pi
  varphi = seq(varphiStart,varphiStart+(nBases-1)*pi/2,pi/2)
  #varphi = seq(varphiStart,varphiStart+(nBases-1)*pi,pi) # for tiling
  
  bas = matrix(NA,ncol=length(t),nrow = nBases)
  for(j in seq(1,nBases)){
    for(i in seq(1,length(t))){
      x = max(-pi, min(pi,pi*a*log(t[i]+b)-varphi[j]))
      bas[j,i] = (cos(x) + 1)/2
    }
  }
  
  t_new = seq(0,tau_N,binSize)
  bas_new = matrix(NA,ncol = length(t_new),nrow = nBases)
  for(j in seq(1,nBases)){
    bas_new[j,] = c(bas[j,1],bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)+1])
  }
  
  return(bas_new)
}

getBasis_tile = function(nBases,tau_N,binSize=0.01,logtime = TRUE){
  t = seq(0,tau_N,tau_N/1000)
  #t = seq(tau_N/1000,tau_N,tau_N/1000)
  a = 1
  
  if(nBases == 4){
    b = tau_N/8 # works for nBases = 4
  }
  if(nBases == 10){
    b = tau_N/150 # works for nBases = 10
  }
  
  nt = log(t+b)
  if(logtime){
    cStart = nt[1]
    cEnd = nt[length(nt)]
  } else {
    #cStart = t[1] + binSize # to center first basis at second bin
    cStart = t[1]
    cEnd = t[length(t)]
  }
  db = (cEnd - cStart) / (nBases-1)
  c = seq(cStart,cEnd,db)
  
  bas = matrix(NA,nrow = nBases,ncol = length(t))
  for(i in seq(1,nBases)){
    for(j in seq(1,length(t))){
      if(logtime){
        x = (nt[j]-c[i])*pi/db 
      } else {
        x = (t[j]-c[i])*pi/db
      }
      bas[i,j] = (cos(max(-pi, min(pi,x))) + 1) / 2
    }
  }
  
  t_new = seq(0,tau_N,binSize)
  #t_new = seq(binSize,tau_N,binSize)
  bas_new = matrix(NA,ncol = length(t_new),nrow = nBases)
  for(j in seq(1,nBases)){
    bas_new[j,] = c(bas[j,1],bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)+1])
    #bas_new[j,] = c(bas[j,1],bas[j,which(as.vector(table(cut(t_new,breaks=t))) == 1)]) # What affect does this have? Must test..
  }
  
  lags = c() # for plotting
  for(i in seq(1,nBases))
    lags = c(lags,t[which.max(bas[i,])])
  #lags = c(lags,t[which.max(bas[i,2:length(t)])+1])
  
  #return(list(bas=bas_new[-1,],lags=lags)) #dont need the first basis
  return(list(bas=bas_new,lags=lags)) #include the first basis
}

binSize = 0.01
tau_N = 0.12
spikes_n1 = discretizeSpikeData(1,trials.good,binSize,tau_N)
spikes_n2 = discretizeSpikeData(2,trials.good,binSize,tau_N)
#spikes_n3 = discretizeSpikeData(3,trials.good,binSize,tau_N)
#spikes_n1_mat = as.matrix(spikes_n1)
#spikes_n2_mat = as.matrix(spikes_n2)
#spikes_n2 = discretizeSpikeData(4,trials.good,binSize,tau_N)

#bas_list = getBasis_tile(10,tau_N,binSize,logtime = T)
#bas = bas_list$bas
#bas_lags = bas_list$lags # for plotting
bas = getBasis(10,tau_N,binSize)
#bas # the first column is evaluated at t = 0, and the last at t = tau_N
#matplot(t(bas),type="b",pch=seq(1,4))

basisWeights = matrix(NA,ncol=dim(bas)[1],nrow=dim(spikes_n1)[1])
for(j in seq(1,dim(bas)[1])){
  basisWeights[,j] = bas[j,2:dim(bas)[2]] %*% t(spikes_n1[,4:dim(spikes_n1)[2]])
}
txt=NULL
for(j in seq(1,dim(bas)[1])){
  txt = c(txt,paste("k",j,sep=""))
}
colnames(basisWeights) = txt
#spikes_n1_basis = cbind(spikes_n1[,3],basisWeights)
colnames(spikes_n1_basis)[1] = colnames(spikes_n1)[3]
spikes_n1_basis = as.data.frame(spikes_n1_basis)
# 
# history effects neuron 1, using basis functions
model_history_n1_basis = glm(formula = spikeCountj1 ~ .,
                             data = spikes_n1_basis, family = "poisson")
summary(model_history_n1_basis)
# 
plot(c(0,bas_lags),coefficients(model_history_n1_basis),type="b")
#plot(coefficients(model_history_n1_basis)-log(mean(spikes_n1_basis$spikeCountj1)),type="l")
# abline(h=0,lty=2)

basisWeights = matrix(NA,ncol=dim(bas)[1],nrow=dim(spikes_n2)[1])
for(j in seq(1,dim(bas)[1])){
  basisWeights[,j] = bas[j,2:dim(bas)[2]] %*% t(spikes_n2[,4:dim(spikes_n2)[2]])
}
txt=NULL
for(j in seq(1,dim(bas)[1])){
  txt = c(txt,paste("k",j,sep=""))
}
colnames(basisWeights) = txt
spikes_n2_basis = cbind(spikes_n2[,3],basisWeights)
colnames(spikes_n2_basis)[1] = colnames(spikes_n2)[3]
spikes_n2_basis = as.data.frame(spikes_n2_basis)

#head(as.matrix(spikes_n2_basis))


#par(bg="white")
#image(as.matrix(spikes_n1_basis))
#image(basisWeights,col = gray.colors(3))


# history effects neuron 2, using basis functions
model_history_n2_basis = glm(formula = spikeCountj2 ~ .,
                             data = spikes_n2_basis, family = "poisson")
summary(model_history_n2_basis)

plot(c(0,bas_lags),coefficients(model_history_n2_basis),type="b")
plot(coefficients(model_history_n2_basis),type="b")
abline(h=0,lty=2)



#test = alias(model_history)
#test$Complete #when the (i,j)th element of this matrix is e.g. 1, it means that covariate i is highly correlated with covariate j http://www.markhneedham.com/blog/2014/10/18/r-linear-models-with-the-lm-function-na-values-and-collinearity/
#cor(spikes_n1_basis) #what does NA mean?






par(mfrow=c(1,2))

# history effects neuron 1
model_history_n1 = glm(formula = spikeCountj1 ~ . - trialId - lickOnset,
                       data = spikes_n1, family = "poisson")
summary(model_history_n1)
plot(seq(0,tau_N,binSize),coefficients(model_history_n1),type = "l",
     main="neuron 1 history",ylab="alpha",xlab="lag (s)")
#lines(seq(0,tau_N,binSize),coefficients(model_history) + 2*sqrt(diag(summary(model_history)$cov.unscaled)),lty=2)
#lines(seq(0,tau_N,binSize),coefficients(model_history) - 2*sqrt(diag(summary(model_history)$cov.unscaled)),lty=2)
abline(h=0,lty=2)

# history effects neuron 2
model_history_n2 = glm(formula = spikeCountj2 ~ . - trialId - lickOnset,
                       data = spikes_n2, family = "poisson")
summary(model_history_n2)
plot(seq(0,tau_N,binSize),coefficients(model_history_n2),type = "l",
     main="neuron 2 history",ylab="alpha",xlab="lag (s)")
abline(h=0,lty=2)

# model_history_n3 = glm(formula = spikeCountj3 ~ . - trialId - lickOnset,
#                        data = spikes_n3, family = "poisson")
# summary(model_history_n3)
# plot(seq(0,tau_N,binSize),coefficients(model_history_n3),type = "l",
#      main="neuron 3 history",ylab="alpha",xlab="lag (s)")
# abline(h=0,lty=2)


spikes_n1n2 = cbind(spikes_n1,spikes_n2[,-c(1,2,3)])
#colnames(spikes_n1n2)[1] = colnames(spikes_n1)[3]
spikes_n2n1 = cbind(spikes_n2,spikes_n1[,-c(1,2,3)])


# functional connectivity n1n2
model_connect_n1n2 = glm(formula = spikeCountj1 ~ . - trialId - lickOnset,
                         data = spikes_n1n2, family = "poisson")
summary(model_connect_n1n2)
plot(seq(0,tau_N,binSize),coefficients(model_connect_n1n2)[c(1,9:15)],type = "b",
     main="connectivity neuron 1 <- neuron 2",ylab="alpha",xlab="lag (s)")
abline(h=0,lty=2)

# functional connectivity n2n1
model_connect_n2n1 = glm(formula = spikeCountj2 ~ . - trialId - lickOnset,
                         data = spikes_n2n1, family = "poisson")
summary(model_connect_n2n1)
plot(seq(0,tau_N,binSize),coefficients(model_connect_n2n1)[14:26],type = "b",
     main="connectivity neuron 2 <- neuron 1",ylab="alpha",xlab="lag (s)")
abline(h=0,lty=2)



printContingencyTable = function(resp, pred){
  contingencyTable = matrix(NA,nrow=length(unique(resp)),ncol=length(unique(pred)))
  for(i in seq(1,length(unique(resp)))){
    for(j in seq(1,length(unique(pred)))){
      if(is.na(unique(pred)[j])){
        contingencyTable[i,j] = length(which(resp[which(is.na(pred))] == unique(resp)[i]))
      } else {
        contingencyTable[i,j] = length(which(resp[which(pred == unique(pred)[j])] == unique(resp)[i]))
      }
    }
  }
  colnames(contingencyTable) = as.character(unique(pred))
  rownames(contingencyTable) = as.character(unique(resp))
  
  contingencyTable
}

printContingencyTable(spikes_n1n2$spikeCountj1,spikes_n1n2$spikeCountj2m4)
printContingencyTable(spikes_n2n1$spikeCountj2,spikes_n2n1$spikeCountj1m10)



# plot history model of neuron 1 and 2, comparing model with constant and model with basis functions
#pdf(file="/Volumes/harisf/master/figures/bases/n1n2_constantVSbasis_minusk1.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(2,3))
plot(seq(0,tau_N,binSize),coefficients(model_history_n1),type = "b",
     main="neuron 1 history",ylab="alpha11_m",xlab="lag (s)")
abline(h=0,lty=2)
plot(c(0,bas_lags),coefficients(model_history_n1_basis),type="b",
     main="neuron 1 history, basis",ylab="alpha11_k",xlab="lag (s)")
abline(h=0,lty=2)
plot(c(0,bas_lags[-1]),coefficients(model_history_n1_basis_minusk1),type="b",
     main="neuron 1 history, basis (-k1)",ylab="alpha11_k",xlab="lag (s)")
abline(h=0,lty=2)
plot(seq(0,tau_N,binSize),coefficients(model_history_n2),type = "b",
     main="neuron 2 history",ylab="alpha22_m",xlab="lag (s)")
abline(h=0,lty=2)
plot(c(0,bas_lags),coefficients(model_history_n2_basis),type="b",
     main="neuron 2 history, basis",ylab="alpha22_k",xlab="lag (s)")
abline(h=0,lty=2)
plot(c(0,bas_lags[-1]),coefficients(model_history_n2_basis_minusk1),type="b",
     main="neuron 2 history, basis (-k1)",ylab="alpha11_k",xlab="lag (s)")
abline(h=0,lty=2)
#dev.off()

# plot history model of neuron 1 and 2, comparing model with constant and model with basis functions
pdf(file="/Volumes/harisf/master/figures/bases/n1n2_constantVSbasis_k1centeredAtSecondBin.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(2,2))
plot(seq(0,tau_N,binSize),coefficients(model_history_n1),type = "b",
     main="neuron 1 history",ylab="alpha11_m",xlab="lag (s)")
abline(h=0,lty=2)
plot(c(0,bas_lags),coefficients(model_history_n1_basis),type="b",
     main="basis k1 centered at 2.bin",ylab="alpha11_k",xlab="lag (s)")
abline(h=0,lty=2)
plot(seq(0,tau_N,binSize),coefficients(model_history_n2),type = "b",
     main="neuron 2 history",ylab="alpha22_m",xlab="lag (s)")
abline(h=0,lty=2)
plot(c(0,bas_lags),coefficients(model_history_n2_basis),type="b",
     main="basis k1 centered at 2.bin",ylab="alpha22_k",xlab="lag (s)")
abline(h=0,lty=2)
dev.off()











