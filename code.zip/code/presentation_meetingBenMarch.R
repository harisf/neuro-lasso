# SHOWING BASES

getBasis2 = function(nBases,binSize){
  b = binSize*5
  peaks = c(binSize,binSize*50)
  
  # nonlinearity for stretching x axis (and its inverse)
  nlin = function(x){log(x+1e-20)}
  invnl = function(x){exp(x)-1e-20}
  
  # Generate basis of raised cosines
  yrange = nlin(peaks+b)
  db = diff(yrange)/(nBases-1)
  centers = seq(yrange[1],yrange[2],db)
  maxt = invnl(yrange[2]+2*db)-b
  iht = seq(binSize,maxt,binSize)
  nt = length(iht)
  
  raisedCosineBasis = function(x,c,dc){
    (cos(max(-pi,min(pi,(x-c)*pi/dc/2)))+1)/2
  }
  
  ihbasis = matrix(NA,nrow = nt,ncol = nBases)
  for(i in seq(1,nt)){
    for(j in seq(1,length(centers))){
      ihbasis[i,j] = raisedCosineBasis(nlin(iht+b)[i],centers[j],db)
    }
  }
  #matplot(ihbasis,type="b",pch=seq(1,5))
  
  # for plotting model coefficients
  lags = invnl(centers)-b
  
  library(pracma)
  ihbas = orth(ihbasis) # orthogonal bases
  
  return(list(bas=ihbasis,bas_orth=ihbas,lags=lags,tau_N=maxt))
}

pdf(file="/Volumes/harisf/master/figures/bases/pillowbases/histANDconnect.pdf",
    width = dev.size()[1],height = dev.size()[2])
binSize = 0.01
par(mfrow=c(1,2))
h = getBasis2(10,binSize)
plot(1,type="n",xlab="lag (s)",ylab="",xlim=c(binSize,h$tau_N),ylim=c(-0.42,0.42),
     main=expression(paste("10 orth. history bases ",Delta,"t = 10 ms",sep="")))
for(i in seq(1,10))
  lines(seq(binSize,h$tau_N,binSize),h$bas_orth[,i],col=i)

c = getBasis2(4,binSize)
plot(1,type="n",xlab="lag (s)",ylab="",xlim=c(binSize,c$tau_N),ylim=c(-0.42,0.42),
     main=expression(paste("4 orth. connectivity bases ",Delta,"t = 10 ms",sep="")))
for(i in seq(1,4))
  lines(seq(binSize,c$tau_N,binSize),c$bas_orth[,i],col=i)
dev.off()



# FITTING LASSO MODEL USING CV
# AND PLOTTING RESULTS
setwd("/Volumes/harisf/master/data/variables/modelMatrix")
data10ms = readRDS("n1_b10ms.rds")
#data100ms = readRDS("n1_b100ms.rds")

library(Matrix)
library(glmnet)
library(doMC)

y = as.factor(data10ms[,1])
x = as.matrix(data10ms[,-1])
tol = 1e-10
for(i in seq(1,dim(x)[2])){
  x[which(abs(x[,i]) < tol),i] = 0
}
x = Matrix(x,sparse = TRUE)

registerDoMC(cores=3)
model_lasso = cv.glmnet(x,y,family = "binomial",alpha = 1, parallel = TRUE)

