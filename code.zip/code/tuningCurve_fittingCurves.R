# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
trials_correctR = which(data$obj[[8]][1,] == 1)
trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# get trials where there was a correct LEFT lick 
trials_correctL = which(data$obj[[8]][2,] == 1)
trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]

startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials_correctL],data$obj[[9]][[3]][[1]][[1]][trials_correctR]),na.rm=TRUE)
startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials_correctL],data$obj[[9]][[3]][[2]][[1]][trials_correctR]),na.rm=TRUE)
startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials_correctL],data$obj[[9]][[3]][[3]][[1]][trials_correctR]),na.rm=TRUE)
# aka lickOnset

neuron = 12

getData_lick = function(neuron, TRIALS,binSize=0.01){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]

  #binSize = 0.01
  timeInterval = seq(0,5.4,binSize)

  data_lick = NULL
  data_lick_j = matrix(0,ncol=3,nrow=length(timeInterval)-1)
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    data_lick_j[,1] = timeInterval[2:length(timeInterval)]
    data_lick_j[,2] =  as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    data_lick_j[,3] = rep(trial_j,length(timeInterval)-1)
    
    data_lick = rbind(data_lick,data_lick_j)
  }
  
  colnames(data_lick) = c("trialTime","spikeCount","trialId")
  dataFrame_lick = as.data.frame(data_lick)
  #head(dataFrame_lickL)
  return(dataFrame_lick)
}

dataFrame_lickL = getData_lick(neuron,TRIALS = trials_correctL)
dataFrame_lickR = getData_lick(neuron,TRIALS = trials_correctR)

# fit gam tuning curves
library(gam)
model_L = gam(spikeCount~s(trialTime),data=dataFrame_lickL,family = "poisson")
model_R = gam(spikeCount~s(trialTime),data=dataFrame_lickR,family = "poisson")
#library(mgcv)
#plot.gam(model_R,se=T,trans=exp)


# get empirical tuning curves
binSize = 0.1
timeInterval = seq(0,5.4,binSize)
getFiringRate = function(neuron,TRIALS){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  
  spikeCount = vector(mode="numeric",length=length(timeInterval)-1)
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    spikeCount = spikeCount + as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
  }
  #firingRate = spikeCount/(binSize*length(spikeCount))
  #spikesPerBin = spikeCount/(length(spikeCount))
  spikesPerTrial = spikeCount/(length(TRIALS))
  return(spikesPerTrial)
}
firingRate_L = getFiringRate(neuron,trials_correctL)
firingRate_R = getFiringRate(neuron,trials_correctR)


# plot tuning curves 
pdf(file="/Volumes/harisf/master/gamSpline.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(2,2))
plot(timeInterval[-1],firingRate_L,type="p",col="red",main=paste("Neuron ",neuron,", lick L",sep = ""),
     xlab = "Trial time (s)", ylab = "Firing Rate (Hz)")
lines(timeInterval[-1],firingRate_L,lwd=0.2,col="red")
plot(timeInterval[-1],firingRate_R,type="p",col="blue",main=paste("Neuron ",neuron,", lick R",sep = ""),
          xlab = "Trial time (s)", ylab = "Firing Rate (Hz)")
lines(timeInterval[-1],firingRate_R,lwd=0.2,col="blue")
plot(model_L,se=T,rug=F)
plot(model_R,se=T,rug=F)
dev.off()



pdf(file="/Volumes/harisf/master/gamSpline_logscale.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(1,2))
plot(model_L,se=T,rug=F,ylim=c(min(log(firingRate_L)-log(mean(firingRate_L))),max(log(firingRate_L))-log(mean(firingRate_L))),
     xlab="trial time (s)",ylab="log(firing rate)",main="Neuron 12, lick L")
points(timeInterval[-1],log(firingRate_L)-log(mean(firingRate_L)),col="red")
abline(v=startOfSampleEpoch,lty=2)
abline(v=startOfDelayEpoch,lty=2)
abline(v=lickOnset,lty=2)
plot(model_R,se=T,rug=F,ylim=c(min(log(firingRate_R)-log(mean(firingRate_R))),max(log(firingRate_R))-log(mean(firingRate_R))),
     xlab="trial time (s)",ylab="log(firing rate)",main="Neuron 12, lick R")
points(timeInterval[-1],log(firingRate_R)-log(mean(firingRate_R)),col="blue")
abline(v=startOfSampleEpoch,lty=2)
abline(v=startOfDelayEpoch,lty=2)
abline(v=startOfResponseEpoch,lty=2)
dev.off()


# NEXT aggregate dataFrame_lickR w.r.t. time, such that we only have (length(timeInterval)-1) rows,
# so spikeCount is a sum over all trials. That is, we want gam to fit the tuning curve on the same
# scale as in the article by Li et al (2015)





