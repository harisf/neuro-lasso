library(R.matlab)
library(foreach)
library(STAR)

# read data
#setwd("/Volumes/harisf/master/data")
#ANIMALS = c("ANM210862","ANM210863","ANM214427")
#ANIMALS = c("ANM214429","ANM214430")
ANIMALS = "ANM218693"
for(animal in ANIMALS){
  #setwd(paste("/Volumes/harisf/master/data/data_structure_",animal,sep=""))
  setwd(paste("/home/shomea/h/harisf/master/data/data_structure_",animal,sep=""))
  
  sessionFileNames = list.files()
  
  #plot_mainDir = "/Volumes/harisf/master/figures/cellActivity"
  plot_mainDir = "/home/shomea/h/harisf/master/figures/cellActivity"
  plot_subDir = paste("mouse",animal,sep="")
  if(!dir.exists(file.path(plot_mainDir, plot_subDir)))
    dir.create(file.path(plot_mainDir, plot_subDir))
  
  #DATA = c(data1,data2,data3)
  for(session in seq(1,length(sessionFileNames))){
    data = readMat(sessionFileNames[session])
    #data = DATA[session]
    totalNumberOfNeurons = length(data$obj[[12]][[1]])
    
    eventTimesLIST = foreach(neuron = seq(1,totalNumberOfNeurons)) %do% {
      data$obj[[12]][[3]][[neuron]][[1]][[2]]
    }
    
    
    pdf(file=paste(file.path(plot_mainDir, plot_subDir),"/session",session,".pdf",sep=""),
        width = 5.245614,height = 6.245614)
        #width = dev.size()[1],height = dev.size()[2])
    plot(as.repeatedTrain(eventTimesLIST),ylab="Cell",xlab="Session time (s)",pch="|",
         main=paste("Session ",session,sep=""))
    dev.off()
  }
}




# getGoodTrials = function(){
#   trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
#   trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
#   trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
#   return(trials.good)
# }
# trials.good = getGoodTrials()