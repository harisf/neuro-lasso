library(glmnet)
#library(doParallel)
library(doMC)
library(Matrix)

#setwd("/home/shomea/h/harisf/master/data/variables/modelMatrix")
#setwd("/Volumes/harisf/master/data/variables/modelMatrix")

for(neuron in seq(1,16)){
#for(neuron in seq(5,12)){
  setwd("/global/work/harisf/session2/modelMatrix_rightTrials")
  fileName = paste("n",neuron,"_b1ms.rds",sep="")
  
  modelMatrix = readRDS(fileName)
  
  y = modelMatrix[,1]
  x = modelMatrix[,-1]
  #y = as.factor(y)
  
  # x = as.matrix(lassoData[,-1])
  # tol = 1e-10
  # for(i in seq(1,dim(x)[2])){
  #   x[which(abs(x[,i]) < tol),i] = 0
  # }
  # x = Matrix(x,sparse = TRUE)
  
  
  # fit cv.glmnet model
  startTime = Sys.time()
  
  #no_cores = detectCores() 
  #no_cores = 10
  #registerDoParallel(no_cores)
  registerDoMC(cores = 10)
  model_lasso_cv = cv.glmnet(x,y,
                             family = "binomial",alpha = 1, nfolds = 10,
                             parallel = TRUE)
  #stopImplicitCluster()
  endTime = Sys.time() - startTime
  
  cat("Lasso model fitted for neuron ",neuron,". Time used: ",endTime," ",attr(endTime,"units"),". \n",sep="")
  
  
  setwd("/global/work/harisf/session2/lassoFit_rightTrials")
  #setwd("/home/shomea/h/harisf/master/data/variables/modelFit")
  #setwd("/Volumes/harisf/master/data/variables/modelFit")
  saveRDS(model_lasso_cv,fileName)
}
