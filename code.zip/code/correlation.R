setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

rm(list=setdiff(ls(), c("data")))

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# neuron = 1
# #eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
# eventTimes = data$obj[[12]][[3]][[1]][[neuron]][[2]]

discretizeSpikeData = function(neuron,TRIALS,binSize=0.01,tau_N=NA){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  lickOnset = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE)
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  mat = NULL
  mat_j = matrix(NA,ncol=3,nrow=length(timeInterval)-1)
  
  if(!is.na(tau_N)){
    M = tau_N / binSize # number of bins we go back
    mat_j = cbind(mat_j,matrix(NA,nrow=dim(mat_j)[1],ncol=M))
  }
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    mat_j[,1] = rep(trial_j,length(timeInterval)-1)
    mat_j[,2] = timeInterval[2:length(timeInterval)]-lickOnset
    mat_j[,3] = as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    
    if(!is.na(tau_N)){
      for(m in seq(1,M)){
        mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
        #mat_j[seq(m+1,length(timeInterval)-1),m+3] = mat_j[seq(1,length(timeInterval)-1-m),3]
      }
    }
    
    mat = rbind(mat,mat_j)
  }
  
  if(!is.na(tau_N)){
    cnames = c()
    for(m in seq(1,M)){
      cnames = c(cnames,paste("spikeCountj",neuron,"m",m,sep = ""))
    }
    colnames(mat) = c("trialId","lickOnset",paste("spikeCountj",neuron,sep=""),cnames)
  } else
    colnames(mat) = c("trialId","lickOnset","spikeCount")
  df = as.data.frame(mat)
  return(df)
}

# pdf(file="/Volumes/harisf/master/figures/correlation/acf_n5n1n12_discretized_aggregated.pdf",width=dev.size()[1],height=dev.size()[2])
# par(mfrow=c(1,3))
# neurons = c(5,1,12)
# for(neuron in neurons){
#   spikes = discretizeSpikeData(neuron,trials.good,binSize = 0.01)
#   
#   spikeCount_aggregated = aggregate(spikes,list(spikes$lickOnset),sum)$spikeCount
#   acf(spikeCount_aggregated,lag.max = 1000,
#       main=paste("aggregated spikes neuron",neuron))
# }
# dev.off()

# pdf(file="/Volumes/harisf/master/figures/correlation/acf_n12_discretized_trials.pdf",width=dev.size()[1],height=dev.size()[2])
# neuron = 12
# spikes = discretizeSpikeData(neuron,trials.good,binSize = 0.01)
# par(mfrow=c(2,2))
# for(i in seq(1,4)){
#   acf(spikes$spikeCount[which(spikes$trialId == trials.good[i])],lag.max = 500,
#       main=paste("trial",trials.good[i]))
# }
# dev.off()

# spikes_n1 = discretizeSpikeData(1,trials.good,0.001)
# spikes_n5 = discretizeSpikeData(5,trials.good)
# spikes_n12 = discretizeSpikeData(12,trials.good)
# 
# library(forecast)
# #pdf(file="/Volumes/harisf/master/figures/correlation/acf_n5n1n12_discretized.pdf",width=dev.size()[1],height=dev.size()[2])
# par(mfrow=c(2,3))
# acf(spikes_n5$spikeCount,main=paste("spikes neuron",5))
# acf(spikes_n1$spikeCount,main=paste("spikes neuron",1))
# acf(spikes_n12$spikeCount,main=paste("spikes neuron",12))
# 
# Acf(spikes_n5$spikeCount,main="")
# Acf(spikes_n1$spikeCount,main="")
# Acf(spikes_n12$spikeCount,main="")
# #dev.off()






# #pdf(file="/Volumes/harisf/master/figures/correlation/acf_n5n1n12.pdf",width=dev.size()[1],height=dev.size()[2])
# eventTimes_1 = data$obj[[12]][[3]][[1]][[1]][[2]]
# eventTimes_12 = data$obj[[12]][[3]][[12]][[1]][[2]]
# eventTimes_5 = data$obj[[12]][[3]][[5]][[1]][[2]]
# par(mfrow=c(1,3))
# acf(eventTimes_5,lag.max = 1000,main=paste("eventTimes neuron",5))
# acf(eventTimes_1,lag.max = 1000,main=paste("eventTimes neuron",1))
# acf(eventTimes_12,lag.max = 100000,main=paste("eventTimes neuron",12))
# #dev.off()

# cross correlation, neuron 1 and 2
# eventTimes_1 = data$obj[[12]][[3]][[1]][[1]][[2]]
# eventTimes_2 = data$obj[[12]][[3]][[2]][[1]][[2]]
# ccf(eventTimes_1[,1],eventTimes_2[,1],lag.max = 1000,main="Cross-corr. n1 n2")


spikes1 = discretizeSpikeData(1,trials.good,binSize = 0.01)
spikes1_aggregated = aggregate(spikes1,list(spikes1$lickOnset),sum)$spikeCount
spikes2 = discretizeSpikeData(2,trials.good,binSize = 0.01)
spikes2_aggregated = aggregate(spikes2,list(spikes2$lickOnset),sum)$spikeCount

pdf(file="/Volumes/harisf/master/figures/correlation/acfANDccf_n1n2.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(1,3))
acf(spikes1_aggregated,lag.max = 1000,main="Auto-corr. n1")
acf(spikes2_aggregated,lag.max = 1000,main="Auto-corr. n2")
ccf(spikes1_aggregated,spikes2_aggregated,lag.max = 1000,main="Cross-corr. n1n2")
dev.off()


