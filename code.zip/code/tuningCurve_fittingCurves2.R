# read data
setwd("/Volumes/harisf/master/data")
library("R.matlab")
data = readMat("data_structure_ANM210861/data_structure_ANM210861_20130701.mat")

# get trials that should be analyzed
getGoodTrials = function(){
  trials.good = which(data$obj[[9]][[3]][[4]][[1]] == 1) # trials where mice are performing (should be tested)
  trials.photostimConfig = which(is.nan(data$obj[[9]][[3]][[5]][[1]])) # trials where photostimulation configuration is tested (should NOT be tested)
  trials.good = trials.good[!is.element(trials.good,trials.photostimConfig)] # trials where mice are performing, AND we've taken out trials where photostimulation configuration is tested
  return(trials.good)
}
trials.good = getGoodTrials()

# get trials where there was a correct RIGHT lick
trials_correctR = which(data$obj[[8]][1,] == 1)
trials_correctR = trials_correctR[is.element(trials_correctR,trials.good)]
# get trials where there was a correct LEFT lick 
trials_correctL = which(data$obj[[8]][2,] == 1)
trials_correctL = trials_correctL[is.element(trials_correctL,trials.good)]

startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials.good]),na.rm=TRUE)
startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials.good]),na.rm=TRUE)
startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials.good]),na.rm=TRUE) # aka lickOnset


discretizeSpikeData = function(neuron,TRIALS,binSize=0.01){
  eventTrials = data$obj[[12]][[3]][[neuron]][[1]][[3]]
  eventTimes = data$obj[[12]][[3]][[neuron]][[1]][[2]]
  
  #timeInterval = seq(0,5.4,binSize)
  timeInterval = seq(0,5,binSize)
  
  data_lick = NULL
  data_lick_j = matrix(0,ncol=3,nrow=length(timeInterval)-1)
  
  for(trial_j in TRIALS){
    trialStartTime_j = data$obj[[7]][1,trial_j]
    eventTimes_j = eventTimes[which(eventTrials == trial_j)] - trialStartTime_j
    
    data_lick_j[,1] = timeInterval[2:length(timeInterval)]
    data_lick_j[,2] =  as.vector(table(cut(eventTimes_j,breaks=timeInterval)))
    data_lick_j[,3] = rep(trial_j,length(timeInterval)-1)
    
    data_lick = rbind(data_lick,data_lick_j)
  }
  
  colnames(data_lick) = c("trialTime","spikeCount","trialId")
  dataFrame_lick = as.data.frame(data_lick)
  return(dataFrame_lick)
}

neuron = 16


spikes_lickL = discretizeSpikeData(neuron,TRIALS = trials_correctL)
spikes_lickR = discretizeSpikeData(neuron,TRIALS = trials_correctR)

#library(gam)
gam_L = gam(spikeCount~as.factor(trialId) + s(trialTime),data = spikes_lickL,family = "poisson")
gam_R = gam(spikeCount~as.factor(trialId) + s(trialTime),data = spikes_lickR,family = "poisson")

#gam_L_aggregate = gam(spikeCount~s(trialTime),data = spikes_lickL,family = "poisson")
#gam_R_aggregate = gam(spikeCount~s(trialTime),data = spikes_lickR,family = "poisson")

pdf(file=paste("/Volumes/harisf/master/figures/tuningCurves/trialIds_neuron",neuron,".pdf",sep = ""),width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(2,2))
plot(gam_L,se=T,main=paste("neuron",neuron,"lick L"))
plot(gam_R,se=T,main=paste("neuron",neuron,"lick R"))
dev.off()

pdf(file="/Volumes/harisf/master/figures/tuningCurves/compareTrialIds_asfactor.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(2,3))
plot(gam_L,se=T,rug=F)
plot(gam_L_sum,se=T,rug=F,main="aggregated")
plot(gam_R,se=T,rug=F)
plot(gam_R_sum,se=T,rug=F,main="aggregated")
dev.off()

anova(gam_L_aggregate,gam_L,test="Chisq")
anova(gam_R_aggregate,gam_R,test="Chisq")









# aggregate spikeCounts over trialIds (but dont really need to do this)
spikes_lickL_sum = data.frame(trialTime = unique(spikes_lickL$trialTime),spikeCount = aggregate(spikes_lickL$spikeCount,by=list(spikes_lickL$trialTime),FUN = sum)$x)
spikes_lickR_sum = data.frame(trialTime = unique(spikes_lickR$trialTime),spikeCount = aggregate(spikes_lickR$spikeCount,by=list(spikes_lickR$trialTime),FUN = sum)$x)

#plot(dataFrame_lickL_sum,col="red")
#plot(dataFrame_lickR_sum,col="blue")




#pdf(file="/Volumes/harisf/master/gamSpline_countScale_neuron1.pdf",width=dev.size()[1],height=dev.size()[2])
par(mfrow=c(1,2))
plot(dataFrame_lickL_sum,col="darkgray",main=paste("Neuron ",neuron," Lick L",sep=""))
lines(dataFrame_lickL_sum$trialTime,fitted.values(gam_L))
#lines(dataFrame_lickL_sum$trialTime,fitted.values(gam_L)+2*exp(sqrt(gam_L$var)),lty=2)
#lines(dataFrame_lickL_sum$trialTime,fitted.values(gam_L)-2*exp(sqrt(gam_L$var)),lty=2)
startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials_correctL]),na.rm=TRUE)
startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials_correctL]),na.rm=TRUE)
startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials_correctL]),na.rm=TRUE) # aka lickOnset
abline(v=startOfSampleEpoch,lty=2)
abline(v=startOfDelayEpoch,lty=2)
abline(v=startOfResponseEpoch,lty=2)


plot(dataFrame_lickR_sum,col="darkgray",main=paste("Neuron ",neuron," Lick R",sep=""))
lines(dataFrame_lickR_sum$trialTime,fitted.values(gam_R))
#lines(dataFrame_lickR_sum$trialTime,fitted.values(gam_R)+exp(sqrt(gam_R$var)),lty=2)
#lines(dataFrame_lickR_sum$trialTime,fitted.values(gam_R)-exp(sqrt(gam_R$var)),lty=2)
startOfSampleEpoch = mean(c(data$obj[[9]][[3]][[1]][[1]][trials_correctR]),na.rm=TRUE)
startOfDelayEpoch = mean(c(data$obj[[9]][[3]][[2]][[1]][trials_correctR]),na.rm=TRUE)
startOfResponseEpoch = mean(c(data$obj[[9]][[3]][[3]][[1]][trials_correctR]),na.rm=TRUE) # aka lickOnset
abline(v=startOfSampleEpoch,lty=2)
abline(v=startOfDelayEpoch,lty=2)
abline(v=startOfResponseEpoch,lty=2)
#dev.off()











